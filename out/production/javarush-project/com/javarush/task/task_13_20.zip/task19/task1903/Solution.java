package com.javarush.task.task19.task1903;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* 
Адаптация нескольких интерфейсов
public class Solution {
    public static Map<String, String> countries = new HashMap<String, String>();

    static {
        countries.put("UA", "Ukraine");
        countries.put("RU", "Russia");
        countries.put("CA", "Canada");
    }

    public static void main(String[] args) {

    }

    public static class IncomeDataAdapter implements Customer, Contact {
        private IncomeData data;

        public IncomeDataAdapter(IncomeData data) {
            this.data = data;
        }

        @Override
        public String getName() {
            return data.getContactLastName() + ", " + data.getContactFirstName();
        }

        @Override
        public String getPhoneNumber() {
            String res = String.format("+%d(%2$s)%3$s-%4$s-%5$s", data.getCountryPhoneCode(),
                    String.format("%010d", data.getPhoneNumber()).substring(0, 3),
                    String.format("%010d", data.getPhoneNumber()).substring(3, 6),
                    String.format("%010d", data.getPhoneNumber()).substring(6, 8),
                    String.format("%010d", data.getPhoneNumber()).substring(8));

            return res;
        }


        @Override
        public String getCompanyName() {
            return data.getCompany();
        }

        @Override
        public String getCountryName() {
            return countries.get(data.getCountryCode());
        }
    }

    public interface IncomeData {
        String getCountryCode();        //For example: UA

        String getCompany();            //For example: JavaRush Ltd.

        String getContactFirstName();   //For example: Ivan

        String getContactLastName();    //For example: Ivanov

        int getCountryPhoneCode();      //For example: 38

        int getPhoneNumber();           //For example1: 501234567, For example2: 71112233
    }

    public interface Customer {
        String getCompanyName();        //For example: JavaRush Ltd.

        String getCountryName();        //For example: Ukraine
    }

    public interface Contact {
        String getName();               //For example: Ivanov, Ivan

        String getPhoneNumber();        //For example1: +38(050)123-45-67, For example2: +38(007)111-22-33
    }
}

Давай представим ситуацию, что с одной стороны у нас есть некая база данных, в которой хранятся данные. База данных имеет стандартный набор команд (методов) для предоставления данных, они описаны в интерфейсе IncomeData. Примеры представления данных приведены в комментариях около каждого метода. С другой стороны есть пользователи, которые хотят получать данные из этой базы, но в каком-то другом (конкретном) формате. Запросы от пользователей представлены методами в интерфейсах Customer и Contact. Там же (в комментариях около каждого метода) есть примеры представления информации в том виде, в котором пользователи хотят ее получать из базы данных.

Твоя задача: написать логику класса адаптера IncomeDataAdapter, который будет по запросам методов из интерфейсов Customer и Contact, обращаться в базу (методы интерфейса IncomeData), получать данные, обрабатывать их, при необходимости изменять представление, и возвращать в виде результата.

Инициализируй countries перед началом выполнения программы. Соответствие кода страны и названия:
UA Ukraine
RU Russia
CA Canada

При необходимости дополни начало телефонного номера (без кода страны) нулями до 10 цифр (смотри примеры в комментарии к соответствующему методу). Обрати внимание на формат вывода телефона, фамилии и имени человека (смотри примеры в комментарии к соответствующему методу).

Требования:
•	Класс Solution должен содержать public static поле countries типа Map<String, String>.
•	В статическом блоке класса Solution инициализируй поле countries тестовыми данными согласно заданию.
•	Класс IncomeDataAdapter должен реализовывать интерфейсы Customer и Contact.
•	Класс IncomeDataAdapter должен содержать приватное поле data типа IncomeData.
•	Класс IncomeDataAdapter должен содержать конструктор с параметром IncomeData.
•	В классе IncomeDataAdapter реализуй методы интерфейсов Customer и Contact используя подсказки в виде комментариев в интерфейсах.


*/

public class Solution {
    public static Map<String, String> countries = new HashMap<String, String>();
    static {
        countries.put("UA", "Ukraine");
        countries.put("RU", "Russia");
        countries.put("CA", "Canada");

    }
    public static void main(String[] args) {
        /*
        String phoneNumber = "38501234567";
        String one = phoneNumber.substring(0, 2);
        String two = phoneNumber.substring(2, phoneNumber.length());
        while (two.length() < 10) {// || phoneNumber.length() > 12) {
            two = "0" + two;
        }
        //Поострока работает так: первый индекс вклчается, второй Не включается
        String phoneNumberOut = "+" + one +
                "(" + two.substring(0, 3) + ")" + two.substring(3,6)+"-" + two.substring(6,8) +"-"
                + two.substring(8,10);

        System.out.println(phoneNumberOut);
        // вывод +38(050)123-45-67


        String res = String.format("+%d(%2$s)%3$s-%4$s-%5$s", 38,
                String.format("%010d", 501234567).substring(0, 3),
                String.format("%010d", 501234567).substring(3, 6),
                String.format("%010d", 501234567).substring(6, 8),
                String.format("%010d", 501234567).substring(8));
        System.out.println(res);
        //вывод +38(050)123-45-67

         */
    }

    public static class IncomeDataAdapter implements Customer, Contact  {
        // Методы интерфейса IncomeData - который оборачиваем
        private IncomeData data;
        // Канструктор
        public IncomeDataAdapter(IncomeData mydatas) {
            this.data = mydatas;
        }

        // Методы интерфейса Contact

        @Override
        public String getName() {
            return this.data.getContactLastName() + ", " +
                    this.data.getContactFirstName();
        }

//        @Override
//        public String getPhoneNumber(){
//            String phoneNumber = String.valueOf(this.data.getCountryPhoneCode()) +
//                    String.valueOf(this.data.getPhoneNumber());
//            String one = phoneNumber.substring(0, 2);
//            String two = phoneNumber.substring(2, phoneNumber.length());
//            while (two.length() < 10) {// || phoneNumber.length() > 12) {
//                two = "0" + two;
//            }
//            //Поострока работает так: первый индекс вклчается, второй Не включается
//            String phoneNumberOut = "+" + one +
//                    "(" + two.substring(0, 3) + ")" + two.substring(3,6)+"-" + two.substring(6,8) +"-"
//                    + two.substring(8,10);
//            return phoneNumberOut;
//        }

        @Override
        public String getPhoneNumber() {
            String res = String.format("+%d(%2$s)%3$s-%4$s-%5$s", data.getCountryPhoneCode(),
                    String.format("%010d", data.getPhoneNumber()).substring(0, 3),
                    String.format("%010d", data.getPhoneNumber()).substring(3, 6),
                    String.format("%010d", data.getPhoneNumber()).substring(6, 8),
                    String.format("%010d", data.getPhoneNumber()).substring(8));

            return res;
        }

        // Методы интерфейса Customer
        @Override
        public String getCompanyName() {
            return this.data.getCompany();
        }

        @Override
        public String getCountryName() {
            String country = countries.get(this.data.getCountryCode());
            return country;
//            return "";
        }

    }


    public interface IncomeData {
        String getCountryCode();        //For example: UA

        String getCompany();            //For example: JavaRush Ltd.

        String getContactFirstName();   //For example: Ivan

        String getContactLastName();    //For example: Ivanov

        int getCountryPhoneCode();      //For example: 38

        int getPhoneNumber();           //For example1: 501234567, For example2: 71112233
    }

    public interface Customer {
        String getCompanyName();        //For example: JavaRush Ltd.

        String getCountryName();        //For example: Ukraine
    }

    public interface Contact {
        String getName();               //For example: Ivanov, Ivan

        String getPhoneNumber();        //For example1: +38(050)123-45-67, For example2: +38(007)111-22-33
    }
}

/*

public static String formatPhoneNumber(String phoneNumber) {
            String one = phoneNumber.substring(0, 2);
            String two = phoneNumber.substring(2, phoneNumber.length());
            while (two.length() < 10) {// || phoneNumber.length() > 12) {
                two = "0" + two;
            }
            //Поострока работает так: первый индекс вклчается, второй Не включается
           String phoneNumberOut = "+" + one +
                    "(" + two.substring(0, 3) + ")" + two.substring(3,6)+"-" + two.substring(6,8) +"-"
                    + two.substring(8,10);

            return phoneNumberOut;
        }

 // Форматируем номер по шаблону +XX (XXX) XXX-XX-XX
            // Для украинских номеров: +38 (XXX) XXX-XX-XX
//            Pattern pattern = Pattern.compile("^(\\d{2})(\\d{3})(\\d{3})(\\d{2})(\\d{2})$");
//            Matcher matcher = pattern.matcher(phoneNumber.substring(phoneNumber.length() - 10));

            if (matcher.matches()) {
                phoneNumber = "+" + phoneNumber.substring(0, phoneNumber.length() - 10) +
                        "(" + matcher.group(2) + ")" +
                        matcher.group(3) + "-" + matcher.group(4) + "-" + matcher.group(5);
                System.out.println(phoneNumber);
                return phoneNumber;
            } else {
                System.out.println(phoneNumber + " orig");
                return phoneNumber;

            }

this.data.getCountryCode();
            this.data.getCompany();
//
//            @Override
//            public String getCountryCode () {
//                return "";
//            }
//
//            @Override
//            public String getCompany () {
//                return "";
//            }
//
//            @Override
//            public String getContactFirstName () {
//                return "";
//            }
//
//            @Override
//            public String getContactLastName () {
//                return "";
//            }
//
//            @Override
//            public int getCountryPhoneCode () {
//                return 0;
//            }

 @Override
        public String getCountryCode() {
            return "";
        }

        @Override
        public String getCompany() {
            return "";
        }

        @Override
        public String getContactFirstName() {
            return "";
        }

        @Override
        public String getContactLastName() {
            return "";
        }

        @Override
        public int getCountryPhoneCode() {
            return 0;
        }

//        @Override
//        public int getPhoneNumber() {
//            return 0;
//        }
 */