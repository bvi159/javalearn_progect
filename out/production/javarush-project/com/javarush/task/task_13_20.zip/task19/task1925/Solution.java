package com.javarush.task.task19.task1925;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/* 
Длинные слова
public class Solution {
    public static void main(String[] args) {
        String fileName1 = args[0];
        String fileName2 = args[1];
        String input;

        ArrayList<String> fileContent = new ArrayList<String>();

        try (BufferedReader fileReader = new BufferedReader(new FileReader(fileName1))) {
            while ((input = fileReader.readLine()) != null)
                fileContent.add(input);
        } catch (IOException ignore) {
            // NOP //
        }

StringBuffer sbLine = new StringBuffer();
        for (String line : fileContent) {
String[] splitedLine = line.split(" ");
            for (String word : splitedLine) {
        if (word.length() > 6)

        sbLine.append(word).append(" ");
            }
                    }

String resultLine = sbLine.toString().trim().replaceAll(" ", ",");
        try (FileWriter fileWriter = new FileWriter(fileName2)) {
        fileWriter.write(resultLine);
        } catch (IOException ignore) {
        // NOP //
        }
        }
        }
В метод main первым параметром приходит путь к файлу1, вторым - путь к файлу2.
Файл1 содержит слова, разделенные пробелом или переводом строки (в файле может быть несколько строк).
Все, что не относится к пробелу или переводу строки, разделителем не считать.
Записать в одну строку через запятую в Файл2 слова, длина которых строго больше 6.
В конце файла2 запятой не должно быть.
Закрыть потоки.

Пример выходных данных в файл2:
длинное,короткое,аббревиатура

Требования:
•	Программа НЕ должна считывать данные с консоли.
•	Программа должна считывать содержимое первого файла (используй FileReader c конструктором String).
•	Поток чтения из файла (FileReader) должен быть закрыт.
•	Программа должна записывать через запятую во второй файл все слова из первого файла длина которых строго больше 6(используй FileWriter).
•	Поток записи в файл (FileWriter) должен быть закрыт.

*/


public class Solution {
    public static void main(String[] args) throws IOException {
        String file1 = args[0];
        String file2 = args[1];
        BufferedReader reader = new BufferedReader(new FileReader(file1));
        BufferedWriter writer = new BufferedWriter(new FileWriter(file2));

        List<String> words6 = new ArrayList<>();
        String line;
        while ((line = reader.readLine()) != null) {
            String[] words = line.split("\\s+");
            for (String word : words) {
//                System.out.println(word);
                if (word.length() > 6) {
                    words6.add(word);
//                    System.out.print(word + ",");
//                    writer.write(word + ",");
                }
            }
        }
        reader.close();
//        while (!words6.isEmpty()) {
//            writer.write(words6.get(0));
        if (!words6.isEmpty()) {
            // Записываем первое слово
            writer.write(words6.get(0));

            // Записываем остальные слова с запятой перед ними
            for (int i = 1; i < words6.size(); i++) {
                writer.write("," + words6.get(i));
            }
        }
        writer.close();
    }


}

