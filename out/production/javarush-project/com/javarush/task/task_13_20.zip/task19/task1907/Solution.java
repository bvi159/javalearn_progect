package com.javarush.task.task19.task1907;

import java.io.*;

/* 
Считаем слово
public class Solution {
    private static int counter = 0;

    public static void main(String[] args) throws IOException {

        String fileName;

        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            fileName = br.readLine();
        }

        StringBuilder text = new StringBuilder();
        try (FileReader reader = new FileReader(fileName)) {
            char currentChar;
            while (reader.ready()) {
                currentChar = (char) reader.read();
                text.append(currentChar);

            }
        }

        String replacedString = text.toString().replaceAll("\\p{P}", " ").replaceAll("\\s", " ");

        for (String x : replacedString.split(" ")) {
            if (x.equals("world")) {
                counter++;
            }
        }

        System.out.println(counter);

    }
}

Считать с консоли имя файла.
Файл содержит слова, разделенные знаками препинания.
Вывести в консоль количество слов "world", которые встречаются в файле.
Закрыть потоки.

Требования:
•	Программа должна считывать имя файла с консоли (используй BufferedReader).
•	BufferedReader для считывания данных с консоли должен быть закрыт.
•	Программа должна считывать содержимое файла (используй FileReader c конструктором принимающим String).
•	Поток чтения из файла (FileReader) должен быть закрыт.
•	Программа должна выводить в консоль количество слов "world", которые встречаются в файле.





*/

public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        String file1 = bufferedReader.readLine();
//        String file2 = bufferedReader.readLine();
        bufferedReader.close();
//        FileReader reader = new FileReader(file1);
//        FileWriter writer = new FileWriter(file2);
//        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {

        // Похоже BufferedReader считывает по строкам из файла или с консоли
        BufferedReader reader = new BufferedReader(new FileReader(file1));
        String targetWord = "world";
        int count = 0;
        String line;

        while ((line = reader.readLine()) != null) {
//            String[] words = line.split("\\s+");
            String[] words = line.split("[\\s\\p{Punct}]+");
            for (String word : words) {
                if (word.equals(targetWord)) {
                    count++;
                }
            }
        }

        //закрываем потоки после использования
        reader.close();
//        writer.close();
        System.out.println(count);
    }
}
