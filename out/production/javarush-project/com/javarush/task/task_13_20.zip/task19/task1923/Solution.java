package com.javarush.task.task19.task1923;

import java.io.*;

/* 
Слова с цифрами
public class Solution {
    public static void main(String[] args) {
        try (BufferedReader fileReader = new BufferedReader(new FileReader(args[0]));
             FileWriter fileWriter = new FileWriter(args[1])) {
            String fileReadLine;
            String[] splitedLine;
            while ((fileReadLine = fileReader.readLine()) != null) {
                splitedLine = fileReadLine.split(" ");
                for (String word : splitedLine) {
                    if (word.matches(".*[0-9].*")) {
                        fileWriter.write(word + " ");
                    }
                }
            }
        } catch (IOException ignored) {
        }
    }
}
В метод main первым параметром приходит имя файла1, вторым - файла2.
Файл1 содержит строки со словами, разделенными пробелом.
Записать через пробел в Файл2 все слова, которые содержат цифры, например, а1, abc3d или 564.
Закрыть потоки.

Требования:
•	Программа НЕ должна считывать данные с консоли.
•	Программа должна считывать содержимое первого файла (используй FileReader c конструктором String).
•	Поток чтения из файла (FileReader) должен быть закрыт.
•	Программа должна записывать во второй файл все слова из первого файла которые содержат цифры (используй FileWriter).
•	Поток записи в файл (FileWriter) должен быть закрыт.

*/

public class Solution {
    public static void main(String[] args) throws IOException {
        String fail1 = args[0];
        String fail2 = args[1];

        BufferedReader reader = new BufferedReader(new FileReader(fail1));
        BufferedWriter writer = new BufferedWriter(new FileWriter(fail2));

        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(" ");
            for (String word : parts) {
                if(word.matches(".*\\d.*")){
                  writer.write(word + " ");
                }
            }

        }
        reader.close();
        writer.close();

    }
}
