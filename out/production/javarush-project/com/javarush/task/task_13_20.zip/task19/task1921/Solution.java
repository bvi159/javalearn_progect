package com.javarush.task.task19.task1921;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;

/* 
Хуан Хуанович
public class Solution {
    public static final List<Person> PEOPLE = new ArrayList<>();

    public static void main(String[] args) {
        String fileName = args[0];

        ArrayList<String> fileContent = new ArrayList<>();
        try (BufferedReader fileReader = new BufferedReader(new FileReader(fileName))) {
            String fileLine;
            while ((fileLine = fileReader.readLine()) != null)
                fileContent.add(fileLine);

        } catch (IOException ignore) {
            // NOP //
        }

                for (String fileLine : fileContent) {
String[] stringArray = fileLine.split(" ");
StringBuffer name = new StringBuffer();

            for (int i = 0; i < stringArray.length - 3; i++) {
        name.append(stringArray[i]).append(" ");
            }

int year = Integer.parseInt(stringArray[stringArray.length - 1]);
int month = Integer.parseInt(stringArray[stringArray.length - 2]) - 1; //January == 0.
int day = Integer.parseInt(stringArray[stringArray.length - 3]);
Calendar birthDay = new GregorianCalendar(year, month, day);

            PEOPLE.add(new Person(name.toString().trim(), birthDay.getTime()));
        }
        }
        }

В метод main первым параметром приходит имя файла.
В этом файле каждая строка имеет следующий вид:
имя день месяц год
где [имя] - может состоять из нескольких слов, разделенных пробелами, и имеет тип String.
[день] - int, [месяц] - int, [год] - int
данные разделены пробелами.

Заполнить список PEOPLE используя данные из файла.
Закрыть потоки.

Пример входного файла:
Иванов Иван Иванович 31 12 1987
Вася 15 5 2013

Требования:
•	Класс Solution должен содержать публичную константу PEOPLE типа List<Person>, которая должна быть сразу проинициализирована.
•	Программа НЕ должна считывать данные с консоли.
•	Программа должна считывать содержимое файла (используй FileReader).
•	Поток чтения из файла (FileReader) должен быть закрыт.
•	Программа должна заполнить список PEOPLE данными из файла.
•	Программа должна правильно работать с двойными именами, например Анна-Надежда.
*/

public class Solution {
    public static final List<Person> PEOPLE = new ArrayList<Person>();

    public static void main(String[] args) throws IOException, ParseException {
        String filePath = args[0];
        BufferedReader reader = new BufferedReader(new FileReader(filePath));

        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(" ");

            // Последние 3 элемента — дата (день, месяц, год)
//            int day = Integer.parseInt(parts[parts.length - 3]);
//            int month = Integer.parseInt(parts[parts.length - 2]);
//            int year = Integer.parseInt(parts[parts.length - 1]);
//            LocalDate birthDate = LocalDate.of(year, month, day);

            // Собираем дату в формате "dd MM yyyy"
            String dateStr = parts[parts.length - 3] + " " +
                    parts[parts.length - 2] + " " +
                    parts[parts.length - 1];

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd MM yyyy");
            dateFormat.setLenient(false); // Запрещаем "автокоррекцию" дат (например, 31.02 → 03.03)

            Date birthDate = dateFormat.parse(dateStr);

            // Остальные элементы — имя
            String name = String.join(" ", Arrays.copyOf(parts, parts.length - 3));
//            parseNameAndDate(line);
            Person mylPerson = new Person(name, birthDate);

            PEOPLE.add(mylPerson);
            System.out.println(mylPerson.getName() + " " + mylPerson.getBirthDate());
        }
        reader.close();
    }

}
/*
 public static void parseNameAndDate(String input) {
        String[] parts = input.split(" ");

        // Последние 3 элемента — дата (день, месяц, год)
        int day = Integer.parseInt(parts[parts.length - 3]);
        int month = Integer.parseInt(parts[parts.length - 2]);
        int year = Integer.parseInt(parts[parts.length - 1]);
//        LocalDate birthDate = LocalDate.of(year, month, day);
        LocalDate birthDate = LocalDate.of(year, month, day);

        // Остальные элементы — имя
        String name = String.join(" ", Arrays.copyOf(parts, parts.length - 3));

        System.out.println("Имя: " + name + ", Дата рождения: " + birthDate);
    }
 */