package com.javarush.task.task19.task1922;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Solution {
    public static List<String> words = new ArrayList<String>();

    static {
//        words.add("файл");
//        words.add("вид");
//        words.add("В");
                words.add("яблоко");
        words.add("банан");
        words.add("апельсин");
    }

    public static void main(String[] args) {
        String file1 = null;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            file1 = reader.readLine();

        } catch (IOException ignore) {
            /* NOP */
        }

        try (BufferedReader in = new BufferedReader(new FileReader(file1))) {
            while (in.ready()) {
                String readedString = in.readLine();
                String[] splitedReadedString = readedString.split(" ");

                int wordCount = 0;
                for (String s : splitedReadedString) {
                    if (words.contains(s)) {
                        wordCount++;
                    }
                }

                if (wordCount == 2)
                    System.out.println(readedString);
            }
        } catch (IOException ignore) {
            /* NOP */
        }
    }
}

/* 
Ищем нужные строки
 public static void main(String[] args) {
        String file1 = null;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            file1 = reader.readLine();

        } catch (IOException ignore) {
            // NOP /
        }

                try (BufferedReader in = new BufferedReader(new FileReader(file1))) {
        while (in.ready()) {
String readedString = in.readLine();
String[] splitedReadedString = readedString.split(" ");

int wordCount = 0;
                for (String s : splitedReadedString) {
        if (words.contains(s)) {
wordCount++;
        }
        }

        if (wordCount == 2)
        System.out.println(readedString);
            }
                    } catch (IOException ignore) {
        // NOP
        }
        }
        }

*/


/*

public class Solution {
    public static List<String> words = new ArrayList<String>();

    static {
        words.add("файл");
        words.add("вид");
        words.add("В");
//        words.add("яблоко");
//        words.add("банан");
//        words.add("апельсин");
    }

    public static void main(String[] args) throws IOException {
        BufferedReader buffRead = new BufferedReader(new InputStreamReader(System.in));
        String filePath = buffRead.readLine();
        buffRead.close();

        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] splitedReadedString = line.split(" ");
            int wordCount = 0;
            for (String s : splitedReadedString) {
                if (words.contains(s)) {
                    wordCount++;
                }
            }

            if (wordCount == 2)
                System.out.println(line);
        }

        reader.close();
    }

}



 // Произвольные строки для проверки
        List<String> inputStrings = new ArrayList<>();
        while ((line = reader.readLine()) != null) {
            inputStrings.add(line);
        }

        // Фильтруем строки и получаем результат
        List<String> result = filterStrings(inputStrings, words);

        // Выводим результат
//        System.out.println("Строки, содержащие ровно два слова из списка:");
        result.forEach(System.out::println);

 */
/**
 * Фильтрует строки, оставляя только те, где есть ровно два слова из списка.
 *
 * @param strings     Список строк для проверки.
 * @param targetWords Список слов, которые должны встречаться.
 * @return Список строк, удовлетворяющих условию.
 */
/*
public static List<String> filterStrings(List<String> strings, List<String> targetWords) {
        List<String> result = new ArrayList<>();

        for (String str : strings) {
            // Разбиваем строку на слова
            String[] words = str.split("\\s+");

            // Считаем, сколько слов из списка есть в строке
            long count = Arrays.stream(words)
                    .filter(targetWords::contains)
                    .count();

            // Если ровно два — добавляем строку в результат
            if (count == 2) {
                result.add(str);
            }
        }

        return result;
    }
 */