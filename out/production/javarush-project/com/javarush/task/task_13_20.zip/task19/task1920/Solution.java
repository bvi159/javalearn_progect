package com.javarush.task.task19.task1920;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/* 
Самый богатый
*/

public class Solution {
    public static void main(String[] args) throws IOException {
        String filePath = args[0];
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
//        List<String> data = new ArrayList<>(
//                Files.readAllLines(Paths.get(filePath))
//        );
        List<String> data = new ArrayList<>();
        String line1;
        while ((line1 = reader.readLine()) != null) {
            data.add(line1);
        }
        reader.close();

        // Используем TreeMap для автоматической сортировки
        Map<String, Double> sums = new TreeMap<>();
        Double currentValue;

        for (String line : data) {
            // Удаляем лишние пробелы и разделяем строку
            line = line.trim();
            String[] parts = line.split("\\s+"); // Разделяем по любому количеству пробелов

            String surname = parts[0];

            try {
                // Заменяем запятую на точку для корректного парсинга
                String numberStr = parts[1].replace(',', '.');
//                double value = Double.parseDouble(parts[1]);
                double value = Double.parseDouble(numberStr);

                // Суммируем значения
//                sums.merge(surname, value, Double::sum);
                sums.merge(surname, value, (oldValue, newValue) -> oldValue + newValue);

            } catch (NumberFormatException e) {
                System.err.println("Ошибка в строке: " + line);
            }
        }
        double max = 0;
        String bigName = "";
        for (Map.Entry<String, Double> entry : sums.entrySet()) {
            if (entry.getValue() > max){
                max = entry.getValue();
//                bigName = entry.getKey();
            }
    //      System.out.println(entry.getKey() + " " + entry.getValue());
        }

        // Собираем фамилии с максимальной суммой
        // По моей версии сразу печатаем.
//        List<String> maxSurnames = new ArrayList<>();
        for (Map.Entry<String, Double> entry : sums.entrySet()) {
            if (entry.getValue() == max) {
                System.out.println(entry.getKey());
//                maxSurnames.add(entry.getKey());
            }
        }
    }

}
