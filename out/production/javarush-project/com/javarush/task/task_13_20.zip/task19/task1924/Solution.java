package com.javarush.task.task19.task1924;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* 
Замена чисел
*/

public class Solution {
    public static Map<Integer, String> map = new HashMap<Integer, String>();
    static {
        map.put(0, "ноль");
        map.put(1, "один");
        map.put(2, "два");
        map.put(3, "три");
        map.put(4, "четыре");
        map.put(5, "пять");
        map.put(6, "шесть");
        map.put(7, "семь");
        map.put(8, "восемь");
        map.put(9, "девять");
        map.put(10, "десять");
        map.put(11, "одиннадцать");
        map.put(12, "двенадцать");
    }
    public static void main(String[] args) throws IOException {
        BufferedReader file1 = new BufferedReader(new InputStreamReader(System.in));
        String myFile = file1.readLine();
        file1.close();

//        BufferedReader reader = new BufferedReader(new FileReader(myFile));

        String fileLine;

        try (BufferedReader in = new BufferedReader(new FileReader(myFile))) {
            while ((fileLine = in.readLine()) != null) {
                for (Map.Entry<Integer, String> entry : map.entrySet()) {
                    fileLine = fileLine.replaceAll("\\b" + entry.getKey() + "\\b", entry.getValue());
//                    fileLine = fileLine.replaceAll("\\b(0|1|2|3|4|5|6|7|8|9|10|11|12)\\b", entry.getValue());
                }
                System.out.println(fileLine);
            }
        } catch (IOException ignore) {
            /* NOP */
        }

    }
}

/*
public class Solution {
    public static Map<Integer, String> map = new HashMap<Integer, String>();
    static {
        map.put(0, "ноль");
        map.put(1, "один");
        map.put(2, "два");
        map.put(3, "три");
        map.put(4, "четыре");
        map.put(5, "пять");
        map.put(6, "шесть");
        map.put(7, "семь");
        map.put(8, "восемь");
        map.put(9, "девять");
        map.put(10, "десять");
        map.put(11, "одиннадцать");
        map.put(12, "двенадцать");
    }
    public static void main(String[] args) throws IOException {
        BufferedReader file1 = new BufferedReader(new InputStreamReader(System.in));
        String myFile = file1.readLine();
        file1.close();

        BufferedReader reader = new BufferedReader(new FileReader(myFile));

        String fileLine;
}


String line;
int number;
String newWord;

        while((line = reader.readLine()) != null){
String[] parts = line.split("\\s+");

            for (String word : parts) {

        if (word.matches("\\b(0|1|2|3|4|5|6|7|8|9|10|11|12)\\.?(?![\\d])")) {
newWord = word.replace(".", "");
number = Integer.parseInt(newWord);
newWord = map.get(number);
                    System.out.print(newWord + " ");
                }else{
                        System.out.print(word + " ");
                }

                        System.out.println("");
        }

                reader.close();

    }
            }
 */