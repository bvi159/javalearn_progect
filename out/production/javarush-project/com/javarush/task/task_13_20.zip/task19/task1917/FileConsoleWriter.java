package com.javarush.task.task19.task1917;

import java.io.*;
import java.nio.charset.Charset;
import java.util.Arrays;

/* 
Свой FileWriter

public class FileConsoleWriter {

    private FileWriter fileWriter;

    public FileConsoleWriter(String fileName) throws IOException {
        fileWriter = new FileWriter(fileName);
    }

    public FileConsoleWriter(String fileName, boolean append) throws IOException {
        fileWriter = new FileWriter(fileName, append);
    }

    public FileConsoleWriter(File file) throws IOException {
        fileWriter = new FileWriter(file);
    }

    public FileConsoleWriter(File file, boolean append) throws IOException {
        fileWriter = new FileWriter(file, append);
    }

    public FileConsoleWriter(FileDescriptor fd) {
        fileWriter = new FileWriter(fd);
    }

    public void write(char[] cbuf, int off, int len) throws IOException {
        fileWriter.write(cbuf, off, len);
        System.out.println(new String(cbuf).substring(off, off + len));
    }

    public void write(int c) throws IOException {
        fileWriter.write(c);
        System.out.println((char) c);
    }

    public void write(String str) throws IOException {
        fileWriter.write(str);
        System.out.println(str);
    }

    public void write(String str, int off, int len) throws IOException {
        fileWriter.write(str, off, len);
        System.out.println(str.substring(off, off + len));
    }

    public void write(char[] cbuf) throws IOException {
        fileWriter.write(cbuf);
        System.out.println(new String(cbuf));
    }

    public void close() throws IOException {
        fileWriter.close();
    }

    public static void main(String[] args) {

    }
}

Реализуй логику FileConsoleWriter.
Класс FileConsoleWriter должен содержать приватное поле FileWriter fileWriter.
Класс FileConsoleWriter должен содержать все конструкторы, которые инициализируют fileWriter для записи.
Класс FileConsoleWriter должен содержать пять методов write и один метод close:

public void write(char[] cbuf, int off, int len) throws IOException
public void write(int c) throws IOException
public void write(String str) throws IOException
public void write(String str, int off, int len) throws IOException
public void write(char[] cbuf) throws IOException
public void close() throws IOException
При записи данных в файл, должен дублировать эти данные на консоль.

Важно: нужно использовать 8-й уровень языка (java language level)!

Требования:
•	Класс FileConsoleWriter должен содержать приватное поле FileWriter fileWriter, которое не должно быть сразу проинициализировано.
•	Класс FileConsoleWriter должен иметь пять конструкторов которые инициализируют fileWriter для записи.
•	Класс FileConsoleWriter должен содержать метод write(char[] cbuf, int off, int len) throws IOException, в котором данные для записи должны записываться в fileWriter и дублироваться в консоль.
•	Класс FileConsoleWriter должен содержать метод write(int c) throws IOException, в котором данные для записи должны записываться в fileWriter и дублироваться в консоль.
•	Класс FileConsoleWriter должен содержать метод write(String str) throws IOException, в котором данные для записи должны записываться в fileWriter и дублироваться в консоль.
•	Класс FileConsoleWriter должен содержать метод write(String str, int off, int len) throws IOException, в котором данные для записи должны записываться в fileWriter и дублироваться в консоль.
•	Класс FileConsoleWriter должен содержать метод write(char[] cbuf) throws IOException, в котором данные для записи должны записываться в fileWriter и дублироваться в консоль.
•	Класс FileConsoleWriter должен содержать метод close() throws IOException, в котором должен вызываться такой же метод поля fileWriter.



*/

public class FileConsoleWriter {  //extends FileWriter
    private FileWriter fileWriter;

    // Конструкторы
    public FileConsoleWriter(String fileName) throws IOException {
        this.fileWriter = new FileWriter(fileName);
    }

    public FileConsoleWriter(String fileName, boolean append) throws IOException {
        this.fileWriter = new FileWriter(fileName, append);
    }

    public FileConsoleWriter(java.io.File file) throws IOException {
        this.fileWriter = new FileWriter(file);
    }

    public FileConsoleWriter(java.io.File file, boolean append) throws IOException {
        this.fileWriter = new FileWriter(file, append);
    }

    public FileConsoleWriter(FileDescriptor fd)
    {
        this.fileWriter = new FileWriter(fd);
    }


    // Методы write
    public void write(char[] cbuf, int off, int len) throws IOException {
        fileWriter.write(cbuf, off, len);
        System.out.print(new String(cbuf, off, len));
    }

    public void write(int c) throws IOException {
        fileWriter.write(c);
        System.out.print((char) c);
    }

    public void write(String str) throws IOException {
        fileWriter.write(str);
        System.out.print(str);
    }

    public void write(String str, int off, int len) throws IOException {
        fileWriter.write(str, off, len);
        System.out.print(str.substring(off, off + len));
    }

    public void write(char[] cbuf) throws IOException {
        fileWriter.write(cbuf);
        System.out.print(new String(cbuf));
    }

    // Метод close
    public void close() throws IOException {
        fileWriter.close();
    }




    public static void main(String[] args) throws IOException {
        FileConsoleWriter writer = new FileConsoleWriter("D:\\ASProject\\Java_learning\\25_02_2025.txt");
            writer.write("Hello, ");
            writer.write("world!\n");
            writer.write(new char[]{'T', 'e', 's', 't'});
            writer.write( "\n");
            writer.write("Вы все есть придурки!!!",12,11);
        writer.close();
    }


}

/*

 public FileConsoleWriter (char[] cbuf, int off, int len) throws IOException {
        super("D:\\ASProject\\Java_learning\\25_02_2025.txt");
        fileWriter = new FileConsoleWriter(cbuf, off, len);
//        fileWriter.write(cbuf, off, len);
    }
    public FileConsoleWriter (int c) throws IOException {
        super("D:\\ASProject\\Java_learning\\25_02_2025.txt");
        fileWriter = new FileConsoleWriter(c);
//        fileWriter.write(c);
    }
    public FileConsoleWriter(String str) throws IOException {
        super("D:\\ASProject\\Java_learning\\25_02_2025.txt");
        fileWriter = new FileWriter(str);
//        fileWriter.write(str);
    }

    public FileConsoleWriter(String str, int off, int len) throws IOException {
        super("D:\\ASProject\\Java_learning\\25_02_2025.txt");
        fileWriter = new FileConsoleWriter(str, off, len);
//        fileWriter.write(str, off, len);

    }
    public FileConsoleWriter (char[] cbuf) throws IOException {
        super("D:\\ASProject\\Java_learning\\25_02_2025.txt");
        fileWriter = new FileConsoleWriter(cbuf);
//        fileWriter.write(cbuf);
    }

    public void write(char[] cbuf, int off, int len) throws IOException {

        this.write(cbuf, off, len);
    }
    public void write(int c) throws IOException {

        this.write(c);
    }
    public void write(String str) throws IOException {

        fileWriter.write(str);
    }
    public void write(String str, int off, int len) throws IOException {

        this.write(str, off, len);
    }

    public void write(char[] cbuf) throws IOException {

        this.write(cbuf);
    }

    public void close() throws IOException {
//        super(close());
        fileWriter.close();
    }

 */