package com.javarush.task.task19.task1910;

import java.io.*;
import java.util.ArrayList;

/* 
Пунктуация
public class Solution {
    public static void main(String[] args) throws IOException {
        String inputFileName;
        String outputFileName;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            inputFileName = reader.readLine();
            outputFileName = reader.readLine();
        }

        ArrayList<String> fileContent = new ArrayList<>();
        try (BufferedReader inputFileReader = new BufferedReader(new FileReader(inputFileName))) {
            while (inputFileReader.ready()) {
                fileContent.add(inputFileReader.readLine());
            }
        }

        try (BufferedWriter outputFileWriter = new BufferedWriter(new FileWriter(outputFileName))) {
            for (String s : fileContent) {
                outputFileWriter.write(s.replaceAll("\\p{P}", ""));
            }
        }
    }
}

Считать с консоли 2 имени файла.
Первый Файл содержит текст.
Считать содержимое первого файла, удалить все знаки пунктуации, включая символы новой строки.

Результат вывести во второй файл.

Закрыть потоки.

Требования:
•	Программа должна считывать имена файлов с консоли (используй BufferedReader).
•	BufferedReader для считывания данных с консоли должен быть закрыт.
•	Программа должна считывать содержимое первого файла (используй BufferedReader c конструктором FileReader).
•	Поток чтения из файла (BufferedReader) должен быть закрыт.
•	Программа должна записывать во второй файл содержимое первого файла, где удалены все знаки пунктуации, включая символы новой строки (Для записи в файл используй BufferedWriter с конструктором FileWriter).
•	Поток записи в файл (BufferedWriter) должен быть закрыт.

*/

public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader mybufferedR = new BufferedReader(new InputStreamReader(System.in));
        String myFileInput = mybufferedR.readLine();
        String myFileOutput = mybufferedR.readLine();
        mybufferedR.close();

        BufferedReader reader = new BufferedReader(new FileReader(myFileInput));
        BufferedWriter writer = new BufferedWriter(new FileWriter(myFileOutput));

        String line;

        while ((line = reader.readLine()) != null) {

            // Удаляем пунктуацию и пробельные символы
            String newContent = line.replaceAll("[\\p{Punct}\\r]+", "");
//            Пример из правильного ответа
//            outputFileWriter.write(s.replaceAll("\\p{P}", ""));

            writer.write(newContent);
//            writer.newLine();

        }
        //закрываем потоки после использования
        reader.close();
        writer.close();
    }
}
