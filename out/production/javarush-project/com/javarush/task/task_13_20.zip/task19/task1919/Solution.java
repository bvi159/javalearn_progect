package com.javarush.task.task19.task1919;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

/* 
Считаем зарплаты
public class Solution {
    public static void main(String[] args) {
        TreeMap<String, Double> salary = new TreeMap<>();

        String fileName = args[0];

        try (BufferedReader rd = new BufferedReader(new FileReader(fileName))) {
            String[] splitedLine;
            String line;
            Double currentValue;

            while ((line = rd.readLine()) != null) {
                splitedLine = line.split(" ");
                String name = splitedLine[0];
                double value = Double.parseDouble(splitedLine[1]);

                if (salary.containsKey(name)) {
                    currentValue = salary.get(name);
                    salary.put(name, value + currentValue);
                } else {
                    salary.put(name, value);
                }
            }
        } catch (IOException ignore) {
//            NOP
        }

                for (String key : salary.keySet()) {
        System.out.println(key + " " + salary.get(key));
        }
   }
}

Иванов 1.35
Петров 3.1

Пример вывода:
Иванов 1.35
Петров 5.1
Сидоров 6.0

Требования:
•	Программа НЕ должна считывать данные с консоли.
•	Программа должна считывать содержимое файла (используй FileReader).
•	Поток чтения из файла (FileReader) должен быть закрыт.
•	Программа должна выводить в консоль каждое имя и сумму всех его значений, все данные должны быть отсортированы в возрастающем порядке по имени.

*/



public class Solution {
    public static void main(String[] args) throws IOException {
        String filePath = args[0];
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
//        List<String> data = new ArrayList<>(
//                Files.readAllLines(Paths.get(filePath))
//        );
        List<String> data = new ArrayList<>();
        String line1;
        while ((line1 = reader.readLine()) != null) {
            data.add(line1);
        }
        reader.close();

        // Используем TreeMap для автоматической сортировки
        Map<String, Double> sums = new TreeMap<>();
        Double currentValue;

        for (String line : data) {
            // Удаляем лишние пробелы и разделяем строку
            line = line.trim();
            String[] parts = line.split("\\s+"); // Разделяем по любому количеству пробелов

            String surname = parts[0];

            try {
                // Заменяем запятую на точку для корректного парсинга
                String numberStr = parts[1].replace(',', '.');
//                double value = Double.parseDouble(parts[1]);
                double value = Double.parseDouble(numberStr);

                // Суммируем значения
//                sums.merge(surname, value, Double::sum);
                sums.merge(surname, value, (oldValue, newValue) -> oldValue + newValue);

            } catch (NumberFormatException e) {
                System.err.println("Ошибка в строке: " + line);
            }
        }

        for (Map.Entry<String, Double> entry : sums.entrySet()) {
//            System.out.printf("%-10s: %6.2f%n", entry.getKey(), entry.getValue());
//            System.out.printf("%s %6.2f%n", entry.getKey(), entry.getValue());
            System.out.println(entry.getKey() + " " + entry.getValue());
        }
    }
}
