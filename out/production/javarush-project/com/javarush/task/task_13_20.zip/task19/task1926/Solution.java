package com.javarush.task.task19.task1926;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

/* 
Перевертыши
public class Solution {
    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
             BufferedReader fileIn = new BufferedReader(new FileReader(reader.readLine()))) {
            while (fileIn.ready()) {
                String line = fileIn.readLine();
                System.out.println(new StringBuffer(line).reverse().toString());
            }
        } catch (IOException ignore) {
            // NOP //
        }
                }
                }
1. Считать с консоли имя файла. Считать содержимое файла.
2. Для каждой строки в файле:
2.1. переставить все символы в обратном порядке.
2.2. вывести на экран.
3. Закрыть потоки.

Пример тела входного файла:
я - программист.
Амиго

Пример результата:
.тсиммаргорп - я
огимА

Требования:
•	Программа должна считывать имя файла с консоли (используй BufferedReader).
•	BufferedReader для считывания данных с консоли должен быть закрыт.
•	Программа должна считывать содержимое файла (используй FileReader).
•	Поток чтения из файла (FileReader) должен быть закрыт.
•	Программа должна выводить в консоль все символы из файла в обратном порядке.

*/

public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader file1 = new BufferedReader(new InputStreamReader(System.in));
        String myFile = file1.readLine();
        file1.close();

        try (BufferedReader reader = new BufferedReader(new FileReader(myFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
//                System.out.println(line);
                char[] post = line.toCharArray();
                for (int i = post.length - 1; i >= 0; i--) {
                    System.out.print(post[i]);
                }
                System.out.print("\n");
            }
        } catch (IOException e) {
            // Обработка исключения
            System.err.println("Ошибка ввода-вывода: " + e.getMessage());
            e.printStackTrace(); // Вывод стека вызовов (опционально)
            /* NOP */
        }
        //D:\ASProject\Java_learning\25_02_2025_1925.txt

    }
}
