package com.javarush.task.task19.task1904;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;

/* 
И еще один адаптер
public class Solution {

    public static void main(String[] args) throws IOException, ParseException {
//        Scanner file = new Scanner(new File("D:\\ASProject\\Java_learning\\25_02_2025.txt"), "UTF-8");
        Scanner myfile = new Scanner(new File("D:\\ASProject\\Java_learning\\25_02_2025.txt"));
        PersonScanner ad = new PersonScannerAdapter (myfile);

        System.out.println(ad.read().toString());
    }

    public static class PersonScannerAdapter implements PersonScanner {

        private final Scanner fileScanner;

        public PersonScannerAdapter(Scanner scanner) {
            fileScanner = scanner;
        }

        @Override
        public Person read() throws IOException {

            String str = fileScanner.nextLine();
            String[] split = str.split(" ");

            Calendar calendar = new GregorianCalendar(Integer.parseInt(split[5]),
                    Integer.parseInt(split[4]) - 1, Integer.parseInt(split[3]));
            Date date = calendar.getTime();
            Person person = new Person(split[1], split[2], split[0], date);
            return person;

        }

        @Override
        public void close() throws IOException {
            fileScanner.close();
        }
    }
*/

public class Solution {

    public static void main(String[] args) throws IOException, ParseException {
        Scanner myfile = new Scanner(new File("D:\\ASProject\\Java_learning\\25_02_2025.txt"));
        PersonScanner ad = new PersonScannerAdapter (myfile);

        System.out.println(ad.read().toString());
    }

    public static class PersonScannerAdapter implements PersonScanner{
        final private Scanner fileScanner; // = new Scanner

        public PersonScannerAdapter(Scanner fileScanner) throws FileNotFoundException {
            this.fileScanner = fileScanner;
        }
        @Override
        public Person read() throws IOException, ParseException {
            //String[] split = str.split(" ");

            String  strFile = this.fileScanner.nextLine();
            String[] words = strFile.trim().split("\\s+");
            String firstname = words[0];
            String secondname = words[1];
            String thirdname = words[2];
            String birthdate = words[3] + words[4] + words[5];
            SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
            Date date = formatter.parse(birthdate);

            Person myPerson = new Person(firstname, secondname, thirdname, date);
            return myPerson;
        }

        @Override
        public void close() throws IOException {
            fileScanner.close();
        }
    }

}
