package com.javarush.task.task19.task1915;

import java.io.*;

/* 
Дублируем текст
public class Solution {
    public static TestString testString = new TestString();

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName = reader.readLine();
        reader.close();

        PrintStream realStream = System.out;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        PrintStream myStream = new PrintStream(byteArrayOutputStream);
        System.setOut(myStream);

        testString.printSomething();

        FileOutputStream fileOutputStream = new FileOutputStream(fileName);
        fileOutputStream.write(byteArrayOutputStream.toByteArray());
        fileOutputStream.close();

        System.setOut(realStream);
        System.out.println(byteArrayOutputStream.toString());

    }

    public static class TestString {
        public void printSomething() {
            System.out.println("it's a text for testing");
        }
    }
}
Считай с консоли имя файла.
В методе main подмени объект System.out написанной тобой ридер-оберткой по аналогии с лекцией.
Твоя ридер-обертка должна выводить весь текст и на консоль и в файл, имя которого ты считал.
Вызови готовый метод printSomething(), воспользуйся testString.
Верни переменной System.out первоначальный поток.
Закрой поток файла.

Пример вывода на экран:
it's a text for testing

Пример тела файла:
it's a text for testing

Требования:
•	Класс Solution должен содержать класс TestString.
•	Класс Solution должен содержать публичное статическое поле testString типа TestString, которое сразу проинициализировано.
•	Класс TestString должен содержать публичный void метод printSomething().
•	Метод printSomething() класса TestString должен выводить на экран строку "it's a text for testing".
•	В методе main(String[] args) программа должна считывать имена файлов с консоли (используй BufferedReader).
•	В методе main(String[] args) BufferedReader для считывания данных с консоли должен быть закрыт.
•	Метод main(String[] args) класса Solution должен создавать поток PrintStream (используй PrintStream c конструктором принимающим ByteArrayOutputStream).
•	Метод main(String[] args) класса Solution должен подменять и восстанавливать поток вывода в консоль объекта System.out.
•	Метод main(String[] args) класса Solution должен один раз вызвать метод printSomething() объекта testString.
•	Метод main(String[] args) класса Solution должен выводить и в консоль и в файл строку выведенную методом printSomething() (используй FileOutputStream).
•	Поток записи в файл (FileOutputStream) должен быть закрыт.

*/

public class Solution {
    public static TestString testString = new TestString();

    public static void main(String[] args) throws IOException {
        BufferedReader myBuffread = new BufferedReader(new InputStreamReader(System.in));
        String outFile = myBuffread.readLine();


        myBuffread.close();

        PrintStream out = System.out;

        ByteArrayOutputStream myByteArr = new ByteArrayOutputStream();

        PrintStream newSysout = new PrintStream(myByteArr);
        System.setOut(newSysout); // перенаправляем вывод
        testString.printSomething(); // вывод пришёл в myByteArr

        try (FileOutputStream fos = new FileOutputStream(outFile)) {
            myByteArr.writeTo(fos);
//            System.out.println("Данные записаны в файл");
        } catch (IOException e) {
            e.printStackTrace();
        }
//        String result = myByteArr.toString();
        System.setOut(out);
        System.out.println(myByteArr.toString());

    }

    public static class TestString {
        public void printSomething() {
            System.out.println("it's a text for testing");
        }
    }
}

