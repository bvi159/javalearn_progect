package com.javarush.task.task19.task1916;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/* 
Отслеживаем изменения
*/

public class Solution {
    public static List<LineItem> lines = new ArrayList<LineItem>();

    public static void main(String[] args) throws Exception {
        BufferedReader console = new BufferedReader(new InputStreamReader(System.in));
        String oldFileName = console.readLine();
        String newFileName = console.readLine();
        console.close();

        List<String> oldFileLines = readFileLines(oldFileName);
        List<String> newFileLines = readFileLines(newFileName);

        int oldFileLine = 0;
        int newFileLine = 0;

        while ((oldFileLine < oldFileLines.size()) && (newFileLine < newFileLines.size())) {

            if (oldFileLines.get(oldFileLine).equals(newFileLines.get(newFileLine))) {
                lines.add(new LineItem(Type.SAME, oldFileLines.get(oldFileLine)));
                oldFileLine++;
                newFileLine++;
            } else if ((newFileLine + 1 < newFileLines.size()) && oldFileLines.get(oldFileLine).equals(newFileLines.get(newFileLine + 1))) {
                lines.add(new LineItem(Type.ADDED, newFileLines.get(newFileLine)));
                newFileLine++;
            } else if ((oldFileLine + 1 < oldFileLines.size()) && oldFileLines.get(oldFileLine + 1).equals(newFileLines.get(newFileLine))) {
                lines.add(new LineItem(Type.REMOVED, oldFileLines.get(oldFileLine)));
                oldFileLine++;
            }
        }

        while (oldFileLine < (oldFileLines.size())) {
            lines.add(new LineItem(Type.REMOVED, oldFileLines.get(oldFileLine)));
            oldFileLine++;
        }
        while (newFileLine < (newFileLines.size())) {
            lines.add(new LineItem(Type.ADDED, newFileLines.get(newFileLine)));
            newFileLine++;
        }

        // Вывод результата
        for (LineItem myLine : lines) {
            System.out.println(myLine.type + " " + myLine.line);
        }
    }

    static List<String> readFileLines(String fileName) throws IOException {
        BufferedReader fReader = new BufferedReader(new FileReader(fileName));
        List<String> fileLines = new ArrayList<String>();
        String line;
        while ((line = fReader.readLine()) != null) {
            fileLines.add(line);
        }
        fReader.close();
        return fileLines;
    }

    public enum Type {
        ADDED,        //добавлена новая строка
        REMOVED,      //удалена строка
        SAME          //без изменений
    }

    public static class LineItem {
        public Type type;
        public String line;

        public LineItem(Type type, String line) {
            this.type = type;
            this.line = line;
        }
    }
}


/*

public static List<LineItem> lines = new ArrayList<LineItem>();

    public static void main(String[] args) throws IOException {
        BufferedReader mybufferedR = new BufferedReader(new InputStreamReader(System.in));
        String file1Path = mybufferedR.readLine();
        String file2Path = mybufferedR.readLine();
        mybufferedR.close();
//        List<String> lines = compareFiles(file1Path, file2Path);
        compareFiles(file1Path, file2Path);

        // Вывод результата
        for (LineItem myLine : lines) {
            System.out.println(myLine.type + " " + myLine.line);
        }

    }
    public static void compareFiles(String file1Path, String file2Path) {
//        public static List<String> compareFiles(String file1Path, String file2Path) {

        try (BufferedReader reader1 = new BufferedReader(new FileReader(file1Path));
             BufferedReader reader2 = new BufferedReader(new FileReader(file2Path))) {

            List<String> file1Lines = new ArrayList<>();
            List<String> file2Lines = new ArrayList<>();

            // Читаем все строки из обоих файлов
            String line;
            while ((line = reader1.readLine()) != null) {
                file1Lines.add(line);
            }
            while ((line = reader2.readLine()) != null) {
                file2Lines.add(line);
            }

            int i = 0, j = 0;
            while (i < file1Lines.size() && j < file2Lines.size()) {
                if (i < file1Lines.size() && j < file2Lines.size()
                        && file1Lines.get(i).equals(file2Lines.get(j))) {
                    // Строки совпадают
                    lines.add(new LineItem(Type.SAME, file1Lines.get(i)));
//                    lines.add(Type.SAME + file1Lines.get(i));
                    i++;
                    j++;
                } else {
                    // Обрабатываем удаленные строки (есть в file1, но нет в file2)
                    if (i < file1Lines.size() &&
                            (j >= file2Lines.size() ||
                                    (i+1 < file1Lines.size() && file1Lines.get(i+1).equals(file2Lines.get(j))))) {
//                        lines.add(Type.REMOVED + file1Lines.get(i));
                        lines.add(new LineItem(Type.REMOVED, file1Lines.get(i)));
                        i++;
                    }
                    // Обрабатываем добавленные строки (есть в file2, но нет в file1)
                    else if (j < file2Lines.size() &&
                            (i >= file1Lines.size() ||
                                    (j+1 < file2Lines.size() && file2Lines.get(j+1).equals(file1Lines.get(i))))) {
//                        lines.add(Type.ADDED + file2Lines.get(j));
                        lines.add(new LineItem(Type.ADDED, file1Lines.get(j)));
                        j++;
                    }
                    // Если ни одно из условий выше не выполнилось, просто продвигаемся дальше
                    else {
                        if (i < file1Lines.size()) i++;
                        if (j < file2Lines.size()) j++;
                    }
                }
            }

        } catch (IOException e) {
            System.err.println("Ошибка при чтении файлов: " + e.getMessage());
        }

//        return lines;
    }
 */