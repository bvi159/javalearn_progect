package com.javarush.task.task19.task1928;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/* 
Исправить ошибку. Классы и интерфейсы

if (result instanceof C) {
                C p = (C) result;
                System.out.println(p.getClass().getSimpleName());
}

А было так
if (result instanceof A) {
                C p = (C) result;
                System.out.println(p.getClass().getSimpleName());
}

Программа содержит всего 1 логическую ошибку.
Найди и исправь ее.

Требования:
•	Класс Solution должен содержать интерфейс Example.
•	Класс Solution должен содержать класс A который реализует интерфейс Example.
•	Класс Solution должен содержать класс B который реализует интерфейс Example.
•	Класс Solution должен содержать класс C который наследуется от класса A.
•	Исправь всего одну логическую ошибку.

*/

public class Solution {
    {
        System.out.println("This is the Solution class");
    }

    public static void main(String... args) throws IOException {
        try (
                FileOutputStream outputStream = new FileOutputStream(args[0]);
                InputStream is = Solution.class.getClassLoader().getResourceAsStream(args[1]); //args[1]
//                InputStream is = Solution.class.getResourceAsStream("25_02_2025_1925_01.txt"); //args[1]
        ) {
//            System.out.println(is.toString());
//            if (is != null) {
                byte[] b = new byte[is.available()];
                outputStream.write(is.read(b));
//            }

            int value = 123_456_789;
            System.out.println(value);

            Example result = null;
            String s = "a";
            switch (s) {
                case "a": {
                    result = new Solution().new A();
                    break;
                }
                case "b": {
                    result = new Solution().new B();
                    break;
                }
                case "c": {
                    result = new Solution().new C();
                    break;
                }
            }

            if (result instanceof C) {
                C p = (C) result;
                System.out.println(p.getClass().getSimpleName());
            }

        } catch (IOException e) {
        }
    }

    interface Example {
    }

    class A implements Example {
        {
            System.out.println("This is the A class");
        }
    }

    class B implements Example {
        {
            System.out.println("This is the B class");
        }
    }

    class C extends A {
        {
            System.out.println("This is the C class");
        }
    }
}
