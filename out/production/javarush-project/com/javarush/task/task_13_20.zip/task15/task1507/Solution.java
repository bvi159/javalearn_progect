package com.javarush.task.task15.task1507;

/* 
ООП - Перегрузка
public class Solution {
    public static void main(String[] args) {
        printMatrix(2, 3, "8");
    }

    public static void printMatrix(int m, int n, String value) {
        System.out.println("Заполняем объектами String");
        printMatrix(m, n, (Object) value);
    }

    public static void printMatrix(int m, int n, Integer value) {
        System.out.println("Заполняем объектами Integer");
        printMatrix(m, n, (Object) value);
    }

    public static void printMatrix(int m, int n, Double value) {
        System.out.println("Заполняем объектами Double");
        printMatrix(m, n, (Object) value);
    }

    public static void printMatrix(int m, int n, Float value) {
        System.out.println("Заполняем объектами Float");
        printMatrix(m, n, (Object) value);
    }

    public static void printMatrix(int m, int n, Long value) {
        System.out.println("Заполняем объектами Long");
        printMatrix(m, n, (Object) value);
    }

    public static void printMatrix(int m, int n, Boolean value) {
        System.out.println("Заполняем объектами Boolean");
        printMatrix(m, n, (Object) value);
    }

    public static void printMatrix(int m, int n, Short value) {
        System.out.println("Заполняем объектами Short");
        printMatrix(m, n, (Object) value);
    }

    public static void printMatrix(int m, int n, Character value) {
        System.out.println("Заполняем объектами Character");
        printMatrix(m, n, (Object) value);
    }

    public static void printMatrix(int m, int n, Byte value) {
        System.out.println("Заполняем объектами Byte");
        printMatrix(m, n, (Object) value);
    }

    public static void printMatrix(int m, int n, Object value) {
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(value);
            }
            System.out.println();
        }
    }
}
Перегрузи метод printMatrix() 8 различными способами, чтобы в итоге у тебя получилось 10 различных методов printMatrix().

Требования:
•	В классе Solution должны быть реализованы 10 методов printMatrix() с различными аргументами.
•	Класс Solution должен быть public.
•	Все методы класса Solution должны быть статическими.
•	Все методы класса Solution должны быть публичными.

*/

public class Solution {
    public static void main(String[] args) {
        printMatrix(2, 3, "8");
    }
    //1
    public static void printMatrix(int m, int n, String value) {
        System.out.println("Заполняем объектами String");
        printMatrix(m, n, (Object) value);
    }
    //2 работает метод 2
    public static void printMatrix(int m, int n, Object value) {
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(value);
            }
            System.out.println();
        }
    }
    //3
    public static void printMatrix(Object value, int m, int n) {
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(value);
            }
            System.out.println();
        }
    }
    //4
    public static void printMatrix(int m, String value, int n) {
        System.out.println("Заполняем объектами String");
        printMatrix(m, n, (Object) value);
    }
    //5
    public static void printMatrix(int m, String value) {
        System.out.println("Заполняем объектами String");
        printMatrix(m, 3, (Object) value);
    }
    //6
    public static void printMatrix(String value, int m) {
        System.out.println("Заполняем объектами String");
        printMatrix(m, 3, (Object) value);
    }
    //7
    public static void printMatrix(String value) {
        System.out.println("Заполняем объектами String");
        printMatrix(2, 3, (Object) value);
    }
    //8
    public static void printMatrix() {
        System.out.println("Заполняем объектами String");
        printMatrix(2, 3, (Object) "8");
    }
    //9
    public static void printMatrix(Object value) {
        System.out.println("Заполняем объектами String");
        printMatrix(3, 2, (Object) value);
    }
    //10
    public static void printMatrix(Object value, int m) {
        System.out.println("Заполняем объектами String");
        printMatrix(m, 2, (Object) value);
    }

}
