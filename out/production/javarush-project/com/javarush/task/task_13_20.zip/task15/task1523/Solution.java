package com.javarush.task.task15.task1523;

/* 
Перегрузка конструкторов
*/

public class Solution {
    public static void main(String[] args) {

    }
    Solution(){}
    private Solution(int fig){}
    protected Solution(String str){}
    public Solution(double fig){}
}

