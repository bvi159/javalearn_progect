package com.javarush.task.task15.task1522;

public class Sun implements Planet {

    private static Sun instance;    // Просто название переменной (никаой не метод)

    private Sun() {
    } // Конструктор

    public static Sun getInstance() { // Просто название метода
        if (instance == null) {        //если объект еще не создан
            instance = new Sun();    //создать новый объект
            //  LazyInitializedSingleton()
        }
        return instance;        // вернуть ранее созданный объект
    }
}

/*
public class Singleton {  //Пусть это будет овца Долли
    private static Singleton instance;
    private static String name;

    public static Singleton getInstance(String str) {
        if (instance == null) {
            instance = new Singleton();
        }
        setName(str);
        return instance;
    }
    public static void setName(String strName) {
        name = strName;
//        return name;
    }

    public String getName() {
        name = this.name;
        return name;
    }
    // Конструкторы
    private Singleton() {
    }
//    private Singleton(String name) {
//    }
}
 */