package com.javarush.task.task15.task1529;

public class Plane implements CanFly {
    private int passengers;

    @Override
    public void fly() {
        System.out.println("I can fly from Plane");
    }
    Plane (int passeners){

    }
    public int getPassengers(){
        passengers = this.passengers;
        return passengers;
    }
    public void setPassengers(){
        passengers = this.passengers;
//        return passengers;
    }
}
