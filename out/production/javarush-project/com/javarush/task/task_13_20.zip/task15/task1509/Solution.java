package com.javarush.task.task15.task1509;

/* 
Мужчина или женщина?
public class Solution {
    public static void main(String[] args) {
        Woman woman = new Woman();
        Man man = new Man();

        printName(man);
        printName(woman);
    }

    public static void printName(Human human) {

    }

    public static class Human {

    }

    public static class Man extends Human {

    }

    public static class Woman extends Human {

    }
}
Измени метод printName() так, чтобы он выполнялся для man и woman.
Реализация метода printName() должна быть одна.

Требования:
•	В классе Solution должен быть реализован только один метод printName().
•	Метод printName() должен принимать один параметр типа Human.
•	Класс Man должен быть потомком класса Human.
•	Класс Woman должен быть потомком класса Human.

*/

public class Solution {
    public static void main(String[] args) {
        Man man = new Man();
        Woman woman = new Woman();

        printName(man);
        printName(woman);
    }

    public static void printName(Human man) {
        if (man instanceof Man)
            System.out.println("Дядя Вася");
        if (man instanceof Woman)
            System.out.println("Тётя Маша");
    }

    public static class Human {
//        private String manName;
//
//        public void setManName(String manName) {
//            manName = this.manName;
//        }
    }

    public static class Man extends Human {
//        private String manName = "Дядя Вася";
//        public void setManName(String manName) {
//            this.manName = manName;
//        }
    }

    public static class Woman extends Human {
//        private String manName = "Тётя Маша";
//        public void setManName(String manName) {
//            this.manName = manName;
//        }
    }
}
/*
public class Solution {
    public static void main(String[] args) {
        Man man = new Man();
        Woman woman = new Woman();

        printName(man);
        printName(woman);
    }

    public static void printName(Man man) {

    }

    public static class Human {

    }

    public static class Man {

    }

    public static class Woman {

    }
}
 */