package com.javarush.task.task15.task1520;

/* 
Тренировка мозга
*/

public class Solution {
    public static void main(String[] args) {
        Duck myNewduck = new Duck();
        Util.fly(myNewduck);
        Util.move(myNewduck);
    }

    public static class Duck implements CanFly, CanMove {
        @Override
        public void doAction() {
            System.out.println("Flying");
        }
        @Override
        public void doAnotherAction() {
            System.out.println("Moving");
        }

    }

    public static class Util {
        static void fly(CanFly myDuck) {
            myDuck.doAction();
        }

        static void move(CanMove myDuck) {
            myDuck.doAnotherAction();
        }
    }

    public static interface CanFly {
        void doAction();
    }

    public static interface CanMove {
        void doAnotherAction();
    }
}
