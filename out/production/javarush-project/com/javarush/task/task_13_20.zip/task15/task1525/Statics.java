package com.javarush.task.task15.task1525;

public class Statics {
    public static String FILE_NAME = "D:\\ASProject\\Java_learning\\25_02_2025_old.txt"/* add the path to your source file here */;
}
