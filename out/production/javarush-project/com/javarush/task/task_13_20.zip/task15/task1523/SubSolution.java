package com.javarush.task.task15.task1523;

public class SubSolution extends Solution{
    SubSolution() {
    }
    protected SubSolution(String str){}
    public SubSolution(double fig){}
}
