package com.javarush.task.task15.task1522;

public class Moon implements Planet {
    private static Moon instance;    // Просто название переменной (никаой не метод)

    // Конструктор
    private Moon() {
    }

    public static Moon getInstance() { // Просто название метода
        if (instance == null) {        //если объект еще не создан
            instance = new Moon();    //создать новый объект
            //  LazyInitializedSingleton()
        }
        return instance;        // вернуть ранее созданный объект
    }
}
