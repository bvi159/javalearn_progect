package com.javarush.task.task15.task1516;

/* 
Значения по умолчанию
*/

import java.io.IOException;

public class Solution {
    public int intVar;
    public double doubleVar;
    public Double DoubleVar;
    public boolean booleanVar;
    public Object ObjectVar;
    public Exception ExceptionVar;
    public String StringVar;

//    public Solution() { super();
//
////        a = 5;
////        b = a + 1; //5+1 = 6
////        c = a * b; //5*6 = 30
////    }
////
////    {
//        intVar = 20;
//        doubleVar = 20d;
//        DoubleVar = 20d;
//        booleeanVar = true;
//        ObjectVAr = null;
//        EsceptionVar = null;
//        StringVar = "";
//    }


    public static void main(String[] args) {
        Solution mySolution = new Solution();
        System.out.println(mySolution.intVar);
        System.out.println(mySolution.doubleVar);
        System.out.println(mySolution.DoubleVar);
        System.out.println(mySolution.booleanVar);
        System.out.println(mySolution.ObjectVar);
        System.out.println(mySolution.ExceptionVar);
        System.out.println(mySolution.StringVar);
    }
}
