package com.javarush.task.task15.task1529;

public class Helicopter implements CanFly {
    @Override
    public void fly() {
        System.out.println("I can fly from Helicopter");
    }
    public int getPassengers(){

        return 4;
    }
}
