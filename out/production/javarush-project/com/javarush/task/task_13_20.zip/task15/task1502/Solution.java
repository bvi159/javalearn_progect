package com.javarush.task.task15.task1502;

/* 
ООП - Наследование животных
*/

public class Solution {
    public static void main(String[] args) {
//        Goose myBird = new Goose();
//        Dragon myAnimal = new Dragon();
        System.out.println(new Goose().getSize());
        System.out.println(new Dragon().getSize());
    }
    //добавьте классы Goose и Dragon тут
    public static class Goose extends SmallAnimal {
        public String getSize() {
            return "Гусь маленький, " + super.getSize();
        }
    }
    public static class Dragon extends BigAnimal {
        public String getSize() {
            return "Дракон большой, " + super.getSize();
        }
    }

    public static class BigAnimal {
        protected String getSize() {
            return "как динозавр";
        }
    }

    public static class SmallAnimal {
        String getSize() {
            return "как кошка";
        }
    }
}
