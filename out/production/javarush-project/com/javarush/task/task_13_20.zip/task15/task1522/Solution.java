package com.javarush.task.task15.task1522;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/* 
Закрепляем паттерн Singleton
*/

public class Solution {
    public static void main(String[] args) {

    }

    public static Planet thePlanet;

    //add static block here - добавьте статический блок тут
    static {
        try {
            readKeyFromConsoleAndInitPlanet();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void readKeyFromConsoleAndInitPlanet() throws IOException {
        // implement step #5 here - реализуйте задание №5 тут
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String key;
        key = reader.readLine();
        reader.close();
        switch (key) {
            case Planet.EARTH:
                thePlanet = Earth.getInstance();
                break;
            case Planet.MOON:
                thePlanet = Moon.getInstance();
                break;
            case Planet.SUN:
                thePlanet = Sun.getInstance();
                break;
            default:
                thePlanet = null;
                break;
        }
    }
}

/*
//        thePlanet = null;

        if (key == Planet.SUN) {
            thePlanet = Sun.getInstance();
        }
        if (key == Planet.EARTH) {
            thePlanet = Earth.getInstance();
        }
        if (key == Planet.MOON) {
            thePlanet = Moon.getInstance();
        }
//        else
//            thePlanet = null;

//        return thePlanet;
         // throw new RuntimeException(e);

---------------------
if (key == Planet.SUN || key == Planet.EARTH || key == Planet.MOON) {
            thePlanet = new Planet() {};
        }
  boolean contains = key.contains(".");
        double num = 0;
 BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));


//        Person person = null;
        String key;
        key = reader.readLine();
        while (!key.equals("exit")) {

            try {
                boolean contains = key.contains(".");
                double num = 0;
                if (contains == true) {
                    num = Double.parseDouble(key);
                    print(num);
                }
                Integer numInt = 0;
                short numShort = 0;
                if (contains != true) {
                    numInt = Integer.parseInt(key);
                    if (numInt <= 0 || numInt >= 128) {
                        print((Integer) numInt);
                    }
                    if (numInt > 0 && numInt < 128) {
                        numShort = Short.parseShort(key);
                        print((short) numShort);
                    }
                }

            } catch ( NumberFormatException e) {
                print(key);
//            throw new RuntimeException(e);
            }
            key = reader.readLine();
        }

 */