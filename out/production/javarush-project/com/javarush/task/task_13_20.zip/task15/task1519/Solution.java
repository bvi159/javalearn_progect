package com.javarush.task.task15.task1519;

import javax.swing.text.html.parser.Parser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/* 
Разные методы для разных типов



*/

public class Solution {
    public static void main(String[] args) throws IOException {
        //напиште тут ваш код
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

//        Person person = null;
        String key;
        key = reader.readLine();
        while (!key.equals("exit")) {

            try {
                boolean contains = key.contains(".");
                double num = 0;
                if (contains == true) {
                    num = Double.parseDouble(key);
                    print(num);
                }
                Integer numInt = 0;
                short numShort = 0;
                if (contains != true) {
                    numInt = Integer.parseInt(key);
                    if (numInt <= 0 || numInt >= 128) {
                        print((Integer) numInt);
                    }
                    if (numInt > 0 && numInt < 128) {
                        numShort = Short.parseShort(key);
                        print((short) numShort);
                    }
                }

            } catch ( NumberFormatException e) {
                print(key);
//            throw new RuntimeException(e);
            }
            key = reader.readLine();
        }

    }

    public static void print(Double value) {
        System.out.println("Это тип Double, значение " + value);
    }

    public static void print(String value) {
        System.out.println("Это тип String, значение " + value);
    }

    public static void print(short value) {
        System.out.println("Это тип short, значение " + value);
    }

    public static void print(Integer value) {
        System.out.println("Это тип Integer, значение " + value);
    }
}


/*
//            } else if (num != 0) {
//                    if (num > 0 && num < 128) {
//                        print((short) num);
//                    } else if (num <= 0 || num >= 128) {
//                        print(num);
//                    } else
//                        print(num);
//                } else
//                    print(key);

//            } else if ("player".equals(key)) {
//                print(key);
//            } else if ("dancer".equals(key)) {
//                print(key);
//            }
//            haveFun(person);
 */