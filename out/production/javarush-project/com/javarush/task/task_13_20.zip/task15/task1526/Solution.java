package com.javarush.task.task15.task1526;

/* 
Дебаг, дебаг, и еще раз дебаг
*/

public class Solution {
    public static void main(String[] args) {
        new B(6);
    }

    public static class A {
//        private int f1 = 7;
//          public A(int f1) {
//                this.f1 = f1;
//                initialize();
        private int fClassA = 7;
//        initialize();
        public A(int fClassA) {
            this.fClassA = fClassA;
            initialize();

        }

        private void initialize() {
//            System.out.println(f1);
            System.out.println(fClassA);
        }
    }

    public static class B extends A {
        private int fClassB = 3;

        public B(int f1) {
            super(f1);
            this.fClassB += f1;
            initialize();
        }

        protected void initialize() {
            System.out.println(fClassB);
        }
    }
}
