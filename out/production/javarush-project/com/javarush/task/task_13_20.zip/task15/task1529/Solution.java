package com.javarush.task.task15.task1529;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/* 
Осваивание статического блока
*/

public class Solution {
    public static void main(String[] args) {

    }

    static {
        //add your code here - добавьте код тут
        reset();
//        System.out.println("What is here?");

    }

    public static CanFly result;

    public static void reset() {
        //add your code here - добавьте код тут
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int howMuch = 0;
        try {
            String whatIsIt = reader.readLine();
            if (whatIsIt.equals("helicopter")) {
                result = new Helicopter();
                System.out.println(" " + result);
            }
            if(whatIsIt.equals("plane")){
                Plane result = new Plane(520);
               howMuch = result.getPassengers();
//                howMuch = result.p;
                        System.out.println(result.getPassengers());
            }


        } catch (IOException e) {
            System.out.println("Ошибка при вводе данных!");
            e.printStackTrace();
//            throw new RuntimeException(e);
        }
    }
}
