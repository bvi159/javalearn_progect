package com.javarush.task.task15.task1529;

public interface CanFly {
    void fly();
    default void Mymethod() {
        System.out.println("I can fly from interface CanFly");
    }

    int getPassengers();
}
