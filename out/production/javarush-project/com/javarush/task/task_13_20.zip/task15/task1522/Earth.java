package com.javarush.task.task15.task1522;

public class Earth implements Planet {
    private static Earth instance;    // Просто название переменной (никаой не метод)

    // Конструктор
    private Earth() {
    }

    public static Earth getInstance() { // Просто название метода
        if (instance == null) {        //если объект еще не создан
            instance = new Earth();    //создать новый объект
            //  LazyInitializedSingleton()
        }
        return instance;        // вернуть ранее созданный объект
    }
}
