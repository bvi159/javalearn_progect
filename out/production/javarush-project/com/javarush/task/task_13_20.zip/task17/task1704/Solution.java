package com.javarush.task.task17.task1704;

import java.util.ArrayList;
import java.util.List;

/* 
Синхронизированные заметки 2
*/

public class Solution {

    public static void main(String[] args) {

        new NoteThread().start();
        new NoteThread().start();


    }

    public static class Note {

        public static final List<String> notes = new ArrayList<String>();

        public static synchronized void addNote(int index, String note) {
            System.out.println("Сейчас будет добавлена заметка [" + note + "] На позицию " + index);
            notes.add(index, note);
            System.out.println("Уже добавлена заметка [" + note + "]");
        }

        public static synchronized void removeNote(int index) {
            System.out.println("Сейчас будет удалена заметка с позиции " + index);
            String note = notes.remove(index);
            System.out.println("Уже удалена заметка [" + note + "] с позиции " + index);
        }
    }

    public static class NoteThread extends Thread {
        @Override
        public void run() {
            for (int i = 0; i < 20; i++) {
                Note.addNote(i, "-Note" + i);
                try {
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Note.removeNote(i);
            }
            for (int i = 0; i < 20; i++) {
//                Solution.Note.addNote(i, "-Note" + i);
//                try {
//                    Thread.sleep(1);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
////                throw new RuntimeException(e);
//                }
//                Note.removeNote(i);
            }

        }
    }
}
