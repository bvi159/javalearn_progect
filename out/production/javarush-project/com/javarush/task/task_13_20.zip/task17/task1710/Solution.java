package com.javarush.task.task17.task1710;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

// CRUD

public class Solution {
    public static List<Person> allPeople = new ArrayList<Person>();

    static {
        allPeople.add(Person.createMale("Иванов Иван", new Date()));  //сегодня родился    id=0
        allPeople.add(Person.createMale("Петров Петр", new Date()));  //сегодня родился    id=1
    }

    static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
    static SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);


    public static void main(String[] args) throws Exception {
        if (args == null || args.length < 1) {
            throw new RuntimeException();
        }

        Date birthdayDate;
        Person person;
        switch (args[0]) {
            case "-c":
                birthdayDate = simpleDateFormat.parse(args[3]);

                if (args[2].equals("м")) {
                    person = Person.createMale(args[1], birthdayDate);
                } else {
                    person = Person.createFemale(args[1], birthdayDate);
                }

                allPeople.add(person);
                System.out.println(allPeople.size() - 1);
                break;
            case "-r":
                person = allPeople.get(Integer.parseInt(args[1]));
                if (person != null) {
                    System.out.println(person.getName() + " " + (person.getSex() == Sex.MALE ? "м" : "ж") + " " + simpleDateFormat2.format(person.getBirthDate()));
                }
                break;
            case "-u":
                birthdayDate = simpleDateFormat.parse(args[4]);
                int id = Integer.parseInt(args[1]);
                person = allPeople.get(id);
                if (person == null) {
                    throw new IllegalArgumentException();
                }
                person.setSex(getSex(args[3]));
                person.setBirthDate(birthdayDate);
                person.setName(args[2]);
                allPeople.set(id, person);
                break;
            case "-d":
                Person currentPerson = allPeople.get(Integer.parseInt(args[1]));
                currentPerson.setName(null);
                currentPerson.setSex(null);
                currentPerson.setBirthDate(null);
                break;
        }

    }

    private static Sex getSex(String sexParam) {
        return sexParam.equals("м") ? Sex.MALE : Sex.FEMALE;
    }
}
/*

public class Solution {
    public static List<Person> allPeople = new ArrayList<Person>();

    static {
        allPeople.add(Person.createMale("Иванов Иван", new Date()));  //сегодня родился    id=0
        allPeople.add(Person.createMale("Петров Петр", new Date()));  //сегодня родился    id=1
    }

    public static void main(String[] args) {

        //напишите тут ваш код
         String configName = args[0];

//        System.out.println("Программа запущена с конфигурацией: " + configName);
        switch (configName) {
            case "-c":
                // действия для d
//                allPeople.add(Person.createMale("Мухина Дарья Анисимовна", new Date()));
                String dateString = args[3];
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate localDate = LocalDate.parse(dateString, formatter);

                Date date = java.sql.Date.valueOf(localDate);

                allPeople.add(Person.createMale(args[1], date));
                System.out.println(allPeople.indexOf(args[1]));
                break;
            case "-r":
                // действия для prod
                // Получим индекс
                int number = Integer.parseInt(args[1]);
                Date myDate = allPeople.get(number).getBirthDate();
//                Date myDate = args[3];

                SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
                System.out.println(allPeople.get(number).getName() +
                             " " + allPeople.get(number).getSex() + " "
                                 + sdf.format(myDate));
                break;
            case "-u":
                // действия для dev
                String dateStr = args[4];
                int number1 = Integer.parseInt(args[1]);
                DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//                SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
                LocalDate localDate1 = LocalDate.parse(dateStr, formatter1);
                Date date1 = java.sql.Date.valueOf(localDate1);

                allPeople.get(number1).setName(args[2]);
                allPeople.get(number1).setSex(Sex.MALE);  // тута доработать
                allPeople.get(number1).setBirthDate(date1);

                SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
                System.out.println(allPeople.get(number1).getName() +
                        " " + allPeople.get(number1).getSex() + " "
                        + sdf1.format(date1));
                break;
            case "-d":
                int number2 = Integer.parseInt(args[1]);
                allPeople.get(number2).setName(null);
                allPeople.get(number2).setSex(null);
                allPeople.get(number2).setBirthDate(null);

                System.out.println(allPeople.get(number2).getName() +
                        " " + allPeople.get(number2).getSex() + " "
                        + allPeople.get(number2).getBirthDate());
                break;
            default:
                System.out.println("Неизвестная конфигурация: " + configName);
        }

    }
}




//        String configName = System.getenv("APP_CONFIG");
//        String configName = System.getProperty("app.config");

//        String configName = System.getProperty("app.config", System.getenv().getOrDefault("APP_CONFIG", "r"));

//                for (int i = 0; i < args.length; i++) {
//                    System.out.println(args[i]);
//                }

 */