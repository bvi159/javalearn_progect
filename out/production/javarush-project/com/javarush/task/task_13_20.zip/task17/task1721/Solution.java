package com.javarush.task.task17.task1721;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/* 
Транзакционность

public class Solution {
    public static List<String> allLines = new ArrayList<String>();
    public static List<String> forRemoveLines = new ArrayList<String>();

    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName1 = null;
        String fileName2 = null;
        try {
            fileName1 = reader.readLine();
            fileName2 = reader.readLine();
            reader.close();
            BufferedReader fReader1 = new BufferedReader(new FileReader(fileName1));
            String input;
            while ((input = fReader1.readLine()) != null)
                allLines.add(input);
            fReader1.close();
            BufferedReader fReader2 = new BufferedReader(new FileReader(fileName2));
            while ((input = fReader2.readLine()) != null)
                forRemoveLines.add(input);
            fReader2.close();
            new Solution().joinData();
        } catch (Exception ignore) {
        }

    }

    public void joinData() throws CorruptedDataException {
        if (allLines.containsAll(forRemoveLines))
            allLines.removeAll(forRemoveLines);
        else {
            allLines.clear();
            throw new CorruptedDataException();
        }

    }
}

Сделать метод joinData транзакционным, т.е. если произошел сбой, то данные не должны быть изменены.
1. Считать с консоли 2 имени файла.
2. Считать построчно данные из файлов. Из первого файла - в allLines, из второго - в forRemoveLines.
В методе joinData:
3. Если список allLines содержит все строки из forRemoveLines, то удалить из списка allLines все строки, которые есть в forRemoveLines.
4. Если условие из п.3 не выполнено, то:
4.1. очистить allLines от данных
4.2. выбросить исключение CorruptedDataException
Метод joinData должен вызываться в main. Все исключения обработайте в методе main.
Не забудь закрыть потоки.

Требования:
•	Класс Solution должен содержать public static поле allLines типа List<String>.
•	Класс Solution должен содержать public static поле forRemoveLines типа List<String>.
•	Класс Solution должен содержать public void метод joinData() который может бросать исключение CorruptedDataException.
•	Программа должна считывать c консоли имена двух файлов.
•	Программа должна считывать построчно данные из первого файла в список allLines.
•	Программа должна считывать построчно данные из второго файла в список forRemoveLines.
•	Метод joinData должен удалить в списке allLines все строки из списка forRemoveLines, если в allLines содержатся все строки из списка forRemoveLines.
•	Метод joinData должен очистить список allLines и выбросить исключение CorruptedDataException, если в allLines не содержатся все строки из списка forRemoveLines.
•	Метод joinData должен вызываться в main.


*/

public class Solution {
    public static List<String> allLines = new ArrayList<String>();
    public static List<String> forRemoveLines = new ArrayList<String>();

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
//        Scanner fileName2 = new Scanner(System.in);
        String fileName1 = scanner.nextLine();
        String fileName2 = scanner.nextLine();
        scanner.close();
//        String fileName = "test.txt";
        allLines = Files.readAllLines(Paths.get(fileName1));
        forRemoveLines = Files.readAllLines(Paths.get(fileName2));

        Solution solution = new Solution();
        solution.joinData();
    }

    public void joinData() throws CorruptedDataException {
        boolean allContains = allLines.containsAll(forRemoveLines);
        if (allContains) {
            allLines.removeAll(forRemoveLines);
        } else {
            allLines.clear();
//            throw new IllegalArgumentException("Data не может быть null");
//            try {
//                throw new CorruptedDataException("Что-то пошло не так!");
            throw new CorruptedDataException();
//            } catch (CorruptedDataException e) {
//                throw new RuntimeException(e);
//            }

        }

        // Вывод содержимого
//        allLines.forEach(System.out::println);
//        forRemoveLines.forEach(System.out::println);

    }
}
