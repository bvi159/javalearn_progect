package com.javarush.task.task17.task1714;

/* 
Comparable
Реализуй интерфейс Comparable<Beach> в классе Beach. Пляжи(Beach) будут использоваться нитями, поэтому позаботься, чтобы все методы были синхронизированы.
Реализуй метод compareTo так, чтобы при сравнении двух пляжей он выдавал:
– положительное число, если первый пляж лучше;
– отрицательное число, если второй пляж лучше;
– ноль, если пляжи одинаковые.
Сравни каждый критерий по отдельности, чтобы победителем был пляж с лучшими показателями по большинству критериев. Учти при сравнении, чем меньше расстояние к пляжу (distance), тем пляж лучше.

Требования:
•	Класс Beach должен содержать три поля: String name, float distance, int quality.
•	Класс Beach должен реализовывать интерфейс Comparable<Beach>.
•	Метод compareTo класса Beach должен учитывать качество пляжа (quality) и дистанцию (distance).
•	Все методы класса Beach, кроме метода main, должны быть синхронизированы.

*/

public class Beach implements Comparable<Beach> {
    private String name;      //название
    private float distance;   //расстояние
    private int quality;    //качество

    public Beach(String name, float distance, int quality) {
        this.name = name;
        this.distance = distance;
        this.quality = quality;
    }

    public synchronized String getName() {
        return name;
    }

    public synchronized void setName(String name) {
        this.name = name;
    }

    public synchronized float getDistance() {
        return distance;
    }

    public synchronized void setDistance(float distance) {
        this.distance = distance;
    }

    public synchronized int getQuality() {
        return quality;
    }

    public synchronized void setQuality(int quality) {
        this.quality = quality;
    }

    public static void main(String[] args) {

    }

    //    -------------------------------

    @Override
    public synchronized int compareTo(Beach obj) {
        int current = 0;
        int other = 0;
        float deltaDistance = distance - obj.getDistance();
        if(deltaDistance > 0) {
            other++;
        } else if(deltaDistance < 0) {
            current++;
        }
        int deltaQuality = quality - obj.getQuality();
        if(deltaQuality > 0) {
            current++;
        } else if(deltaQuality < 0) {
            other++;
        };
        return current - other;
    }


}
/*
 public synchronized int compareTo(Beach other) {
        // Сравниваем сначала по качеству
//        int ageComparison = Integer.compare(this.distance, other.distance);
        int qualComparison = Integer.compare(this.quality, other.quality);
        int distComparison = Float.compare(this.distance, other.distance);

        if (Float.compare(this.distance, other.distance) == - Float.compare(other.distance, this.distance)) {
            return 0;
        }

        if (qualComparison > 0 && distComparison <= 0) {
            return qualComparison;
        }

        if (qualComparison > 0 ) {
            return qualComparison;
        }

        if ((distComparison + qualComparison == 0) || (distComparison == 0 && qualComparison == 0)) {
            return 0;
        }

        if (qualComparison > 0 && distComparison <= 0) {
            return qualComparison;
        } else {
            return -1;
        }
        // Если качеством равны, сравниваем по расстоянию - чем меньше, тем лучше
//
//        if (distComparison != 0) {
//            return distComparison;
//        }
//
//
//        return 0;
    }



} else if () {

        }
 */