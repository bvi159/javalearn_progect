package com.javarush.task.task17.task1703;

import java.util.ArrayList;
import java.util.List;

/* 
Синхронизированные заметки
*/

public class Solution {
    public static int threadCount = 10;
    public static int[] testArray = new int[1000];
    public static List<String> notes = new ArrayList<String>();

    static {
        for (int i = 0; i < Solution.testArray.length; i++) {
            testArray[i] = i;
        }
    }

    public static void main(String[] args) {
        new NoteThread().start();
        new NoteThread().start();
    }

    public static class Note {

//        public final List<String> notes = new ArrayList<String>();

        public static void addNote(int index, String note) {
//            notes.add(0, note);
            System.out.println("Сейчас будет добавлена заметка [" + note + "] На позицию " + index);
            synchronized (notes) {
                notes.add(index, note);
            }
            System.out.println("Уже добавлена заметка [" + note + "]");
        }

        public static void removeNote(int index) {
            System.out.println("Сейчас будет удалена заметка с позиции " + index);
            String note = "";
            synchronized (notes) {
                note = notes.remove(index);
            }
            System.out.println("Уже удалена заметка [" + note + "] с позиции " + index);
        }
    }

    public static class NoteThread extends Thread {
        @Override
        public void run() {
            for (int i = 0; i < 20; i++) {
                Solution.Note.addNote(i, "-Note" + i);
//                try {
//                    Thread.sleep(1);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//                Solution.Note.removeNote(i - 1);
            }
            for (int i = 0; i < 20; i++) {
//                Solution.Note.addNote(i, "-Note" + i);
//                try {
//                    Thread.sleep(1);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
////                throw new RuntimeException(e);
//                }
                Solution.Note.removeNote(i);
            }

        }
    }

}
