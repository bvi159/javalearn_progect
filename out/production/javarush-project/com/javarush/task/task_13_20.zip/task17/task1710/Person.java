package com.javarush.task.task17.task1710;

import java.util.Date;

public class Person {
    private String name;
    private Sex sex;
    private Date birthDate;

    private Person(String name, Sex sex, Date birthDate) {
        this.name = name;
        this.sex = sex;
        this.birthDate = birthDate;
    }

    public static Person createMale(String name, Date birthDate) {
        return new Person(name, Sex.MALE, birthDate);
    }

    public static Person createFemale(String name, Date birthDate) {
        return new Person(name, Sex.FEMALE, birthDate);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Sex getSex() {
        return sex;
    }

    public void setSex(Sex sex) {
        this.sex = sex;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }
}
/*
iПопулярные шаблоны для SimpleDateFormat:
Шаблон	Описание	Пример вывода

dd	День месяца (2 цифры)	05, 25

MM	Месяц (2 цифры)	01, 12

yyyy	Год (4 цифры)	2023, 1999

HH	Часы (24-часовой формат)	00, 23

mm	Минуты	00, 59

ss	Секунды	00, 59

EEE	День недели (коротко)	Пн, Вт

EEEE	День недели (полностью)	Понедельник

 */