package com.javarush.task.task17.task1721;

import java.io.IOException;

public class CorruptedDataException extends IOException {
//    static String str1 = "По вашему приказанию";
//    static String str2 = "Очистил allLines и выбросил исключение!";

    public CorruptedDataException (String message) {
        super(message);
    }
    public CorruptedDataException () {
        System.out.println("По вашему приказанию");
        System.out.println("Очистил allLines и выбросил исключение!");
    }
//        System.out.println("Очистил allLines и выбросил исключение!");
//    public CorruptedDataException() {
//
//    }
//    public CorruptedDataException(String myString) {
//    }

    //    @Override
//    public static void printMyExeption() {
//        System.out.println("По вашему приказанию");
//        System.out.println("Очистил allLines и выбросил исключение!");
//    }
}
