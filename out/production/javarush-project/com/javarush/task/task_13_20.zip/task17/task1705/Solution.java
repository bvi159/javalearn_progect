package com.javarush.task.task17.task1705;

import java.util.ArrayList;
import java.util.List;

/* 
Сад-огород
mutual exclusion
взаимное исключение
*/

public class Solution {


    public static void main(String[] args) {
        Garden myFruits = new Garden();
        Garden myVegetable = new Garden();
        myFruits.start();
        myVegetable.start();
        myFruits.addFruit(0,"Яблоко");
        myFruits.addFruit(1,"Груша");
        myFruits.addFruit(2,"Слива");
        myFruits.addFruit(3,"Вишня");
        myFruits.addFruit(4,"Абрикоса");

        myVegetable.addVegetable(0, "Помидор");
        myVegetable.addVegetable(1, "Капуста");
        myVegetable.addVegetable(2, "Картошка");
        myVegetable.addVegetable(3, "Огурец");
        myVegetable.addVegetable(4, "Чеснок");
//        synchronized (this) {
        int myIndFruit = 0;
        int myIndVeget = 0;
            for (int i = 0; i < 4; i++) {
//                myIndFruit = myFruits.fruits.size() - 1;
//                myIndVeget = myVegetable.vegetables.size() - 1;
                myFruits.removeFruit(myIndFruit);
                myVegetable.removeVegetable(myIndVeget);
            }
//        }
//        myFruits.fruits.add("Груша");
//        myFruits.fruits.add("Слива");

    }

    public static class Garden extends Thread {
        public final List<String> fruits = new ArrayList<String>(5);
        public final List<String> vegetables = new ArrayList<String>(5);

        public synchronized void addFruit(int index, String fruit){
                System.out.println("Будет добавлен [" + fruit + "] с индексом " + index);
                fruits.add(index, fruit);
                System.out.println("Добавлен [" + fruit + "] с индексом " + index);
        }
        public synchronized void removeFruit(int index){
            System.out.println("Будет Удалён [" +  fruits.get(index) + "] с индексом " + index);
                fruits.remove(index);
            System.out.println("Удалён [" + fruits.get(index) + "] с индексом " + index);
        }

        public synchronized  void addVegetable(int index, String vegetable){
            System.out.println("Будет добавлен [" + vegetable + "] с индексом " + index);
            vegetables.add(index, vegetable);
            System.out.println("Добавлен [" + vegetable + "] с индексом " + index);
        }
        public synchronized void removeVegetable(int index){
            System.out.println("Будет Удалён [" +  vegetables.get(index) + "] с индексом " + index);
            vegetables.remove(index);
            System.out.println("Удалён [" + vegetables.get(index) + "] с индексом " + index);

        }

    }



}
