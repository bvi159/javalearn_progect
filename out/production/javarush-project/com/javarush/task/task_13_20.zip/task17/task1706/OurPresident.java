package com.javarush.task.task17.task1706;

import com.javarush.task.task17.task1707.IMF;

public class OurPresident {
    private static OurPresident president;

    static {
        synchronized (OurPresident.class) {

            president = new OurPresident();
        }
    }

    OurPresident() {
    }

    public static OurPresident getOurPresident() {

        if (president == null) {
            president = new OurPresident();
        }
        return president;
    }
}

/*

public class OurPresident {
    private static OurPresident president;

    static {
        synchronized (OurPresident.class) {
            president = new OurPresident();
        }
    }

    private OurPresident() {
    }

    public static OurPresident getOurPresident() {
        return president;
    }
}
---------------------------------------
//    static {
//        synchronized (president){

    public static void setPresident(OurPresident president) {
        this.president = "Владимир Путин";
    }

    ////            OurPresident president = new OurPresident("Владимир Владимирович Путин");
//            president = new OurPresident(); //"Владимир Владимирович Путин";
//
//        }
//
 */