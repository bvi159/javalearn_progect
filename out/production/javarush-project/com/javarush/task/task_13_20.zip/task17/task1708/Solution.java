package com.javarush.task.task17.task1708;

import java.util.ArrayList;
import java.util.List;

/* 
Заметки для всех
*/

public class Solution {

    public static void main(String[] args) {
        Note myNote1 = new Note();
        Note myNote2 = new Note();
//        Thread thr1 = new Thread((new Note());
//        Thread thr2 = new Thread((Runnable) myNote2);
        Thread thr1 = new Thread((Runnable) myNote1);
        Thread thr2 = new Thread((Runnable) myNote2);
        thr1.start();
        thr2.start();

    }

    public static class Note implements Runnable {
        public static List<String> notes = new ArrayList<String>();

        static {
            String str = "цифра ";
            for (int i = 0; i < 10; i++) {
                notes.add(str + i);
            }
        }


        public void addNote(int index, String note) {
            System.out.println("Сейчас будет добавлена заметка [" + note + "] На позицию " + index);
            notes.add(index, note);
            System.out.println("Уже добавлена заметка [" + note + "]");
        }

        public void removeNote(int index) {
//            System.out.println("Сейчас будет удалена заметка " + notes.get(index) + " с позиции "  + index);
            System.out.println("Сейчас будет удалена заметка " + notes.get(index) + " с позиции "  + index);
            String note = notes.remove(index);
            System.out.println("Уже удалена заметка [" + note + "] с позиции " + index);
        }

        @Override
        public void run() {
            String str = "цифра ";
            for (int i = 0; i < 10; i++) {
//                notes.add(str + i);
               addNote(i, this.notes.get(i) + i);
//                addNote(i, Thread.currentThread().getName() + i);
               removeNote(i);
            }
        }
    }
}
