package com.javarush.task.task18.task1817;

import java.io.*;

/* 
Пробелы
public class Solution {
    public static void main(String[] args) throws IOException {
        int total = 0;
        int spaces = 0;
        try (FileReader fileReader = new FileReader(args[0])) {
            while (fileReader.ready()) {
                int readedChar = fileReader.read();
                total++;
                if (readedChar == (int) ' ') spaces++;
            }
        }
        if (total != 0) {
            double result = (double) spaces / total * 100;
            System.out.printf("%.2f", result);
        }
    }
}

В метод main первым параметром приходит путь к файлу.
Вывести на экран соотношение количества пробелов к количеству всех символов. Например, 10.45.
1. Посчитать количество всех символов.
2. Посчитать количество пробелов.
3. Вывести на экран п2/п1*100, округлив до 2 знаков после запятой до ближайшего.
4. Закрыть потоки.

Требования:
•	Считывать с консоли ничего не нужно.
•	Создай поток чтения из файла, который приходит первым параметром в main.
•	Посчитай отношение пробелов ко всем символам в файле и выведи в консоль это число.
•	Выведенное значение необходимо округлить до 2 знаков после запятой до ближайшего.
•	Поток чтения из файла должен быть закрыт.




*/

public class Solution {
    public static void main(String[] args) throws IOException {
        String finename = args[0];

        FileInputStream fileInputStream = new FileInputStream(finename); //"C:\\Users\\Username\\Desktop\\test.txt"

        BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);

        int i;
        int count = 0; // всего cимволов
        int space = 0; // всего пробелов
        while ((i = bufferedInputStream.read()) != -1) {
            if ((char) i == ' ') space++;
            count++;
        }
        double result = (double) space / count * 100;
        double rounded = Math.round(result * 100.0) / 100.0;
        System.out.println(rounded);
        fileInputStream.close();
        bufferedInputStream.close();
    }
}
/*
          for (char c = 'A'; c <= 'z'; c++) {
                if (c == ((char) i)) count++;
//                    System.out.println(c + " → " + (int) c);
            }
 */