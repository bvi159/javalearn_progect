package com.javarush.task.task18.task1824;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/* 
Файлы и исключения

public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        while (true) {
            String fileName = reader.readLine();
            try (FileInputStream fileInputStream = new FileInputStream(fileName)) {

            } catch (FileNotFoundException e) {
                System.out.println(fileName);
                break;
            }
        }
    }
}

Читайте с консоли имена файлов.
Если файла не существует (передано неправильное имя файла), то перехватить исключение FileNotFoundException, вывести в консоль переданное неправильное имя файла и завершить работу программы.
Закрыть потоки.
Не используй System.exit();

Требования:
•	Программа должна считывать имена файлов с консоли.
•	Для каждого файла нужно создавать поток для чтения.
•	Если файл не существует, программа должна перехватывать исключение FileNotFoundException.
•	После перехвата исключения, программа должна вывести имя файла в консоль и завершить работу.
•	Потоки для чтения из файла должны быть закрыты.
•	Команду "System.exit();" использовать нельзя.
    }
}



Input data
HARD



*/

public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        List<Thread> threads = new ArrayList<>(); // Храним потоки для управления
        String filename = reader.readLine();
        while (true) {
            Thread mythread = new ReadThread(filename);
            mythread.start();
            threads.add(mythread);
            if (!Files.exists(Paths.get(filename))) {
                break;
            }
            filename = reader.readLine();
        }
        // Ожидаем завершения всех потоков (опционально)
        for (Thread thread : threads) {
            try {
                thread.join(); // Ждём завершения потока
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
    public static class ReadThread extends Thread {
        private String filePath;

        public ReadThread(String fileName) {
            //implement constructor body
            this.filePath = fileName;
        }

        @Override
        public void run() {

            try (FileInputStream fileInputStream = new FileInputStream(filePath)) {

            } catch (FileNotFoundException e){
                System.out.println(filePath);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}
