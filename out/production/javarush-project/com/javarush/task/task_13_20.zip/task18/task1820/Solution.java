package com.javarush.task.task18.task1820;

import java.io.*;
import java.util.Scanner;

/*
Округление чисел



public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName1 = reader.readLine();
        String fileName2 = reader.readLine();

        try (BufferedReader bufferedFileReader = new BufferedReader(new FileReader(fileName1));
             PrintWriter printWriter = new PrintWriter(new FileWriter(fileName2))) {

            while (bufferedFileReader.ready()) {
                String[] splittedLine = bufferedFileReader.readLine().split(" ");
                for (String numberInString : splittedLine) {
                    double number = Double.parseDouble(numberInString);
                    long roundedNumber = Math.round(number);
                    printWriter.print(roundedNumber + " ");
                }
            }
        }
    }
}
Считать с консоли 2 имени файла.
Первый файл содержит вещественные(дробные) числа, разделенные пробелом. Например, 3.1415.
Округлить числа до целых и записать через пробел во второй файл.
Закрыть потоки.

Принцип округления:
3.49 => 3
3.50 => 4
3.51 => 4
-3.49 => -3
-3.50 => -3
-3.51 => -4

Требования:
•	Программа должна два раза считать имена файлов с консоли.
•	Для первого файла создай поток для чтения. Для второго - поток для записи.
•	Считать числа из первого файла, округлить их и записать через пробел во второй.
•	Должны соблюдаться принципы округления, указанные в задании.
•	Созданные для файлов потоки должны быть закрыты.

*/


public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String file1 = reader.readLine();
        String file2 = reader.readLine();
//        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();


        try (FileInputStream fis = new FileInputStream(file1);
             FileOutputStream fos = new FileOutputStream(file2, true);
             DataOutputStream ops = new DataOutputStream(fos)) {

            Scanner scanner = new Scanner(fis);
            // Устанавливаем разделитель - запятая (можно добавить пробелы: "\\s*,\\s*")
//            scanner.useDelimiter(" ");   //.useDelimiter(" ");

            while (scanner.hasNext()) {
                if (scanner.hasNextDouble()) {
                    double number = scanner.nextDouble();
//                    number = Math.round(number * 100.0) / 100.0;  // Округление до 2 знаков
                    // Ошибочка вышла, оказывается в условии окрлять до целых
                    number = Math.round(number);
                    // Записываем как текст с пробелом
                    String str = String.format("%.2f ", number);
                    ops.writeBytes(str);  // Альтернатива: ops.write(str.getBytes());
                } else {
                    scanner.next();  // Пропускаем некорректные данные
                }
            }
            scanner.close();
//            System.out.println("Данные успешно записаны в doubles.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}



/*
            while (scanner.hasNextDouble()) {
                    double number = scanner.nextDouble();
                    number = Math.round(number * 100.0) / 100.0;
                    ops.writeDouble(number);
                    ops.writeByte(' ');
                    System.out.println("Прочитано число: " + number);
            }

 */
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

