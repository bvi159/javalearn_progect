package com.javarush.task.task18.task1815;

import java.util.List;

/* 
Таблица
@Override
        public void setModel(List rows) {
            System.out.println(rows.size());
            tableInterface.setModel(rows);
        }

        @Override
        public String getHeaderText() {
            return tableInterface.getHeaderText().toUpperCase();
        }

        @Override
        public void setHeaderText(String newHeaderText) {
            tableInterface.setHeaderText(newHeaderText);
        }
    }

Измени класс TableInterfaceWrapper так, чтобы он стал Wrapper-ом для TableInterface.
Метод setModel должен вывести в консоль количество элементов в списке перед обновлением модели (вызовом метода setModel у объекта типа TableInterface).
Метод getHeaderText должен возвращать текст в верхнем регистре - используй метод toUpperCase().

Требования:
•	Класс TableInterfaceWrapper должен реализовывать интерфейс TableInterface.
•	Класс TableInterfaceWrapper должен инициализировать в конструкторе поле типа TableInterface.
•	Метод setModel() должен вывести в консоль количество элементов в новом листе перед обновлением модели.
•	Метод getHeaderText() должен возвращать текст в верхнем регистре.
•	Метод setHeaderText() должен устанавливать текст для заголовка без изменений.


*/

public class Solution {
    public class TableInterfaceWrapper implements TableInterface {
        TableInterface newTable;
//        private String header;
//        private List somelist;

        public TableInterfaceWrapper(TableInterface table) {
            this.newTable = table;
        }

        @Override
        public void setModel(List rows) {
            System.out.println(rows.size());
            newTable.setModel(rows);
//            this.somelist = rows;
//            int elements;
//            elements = rows.size();
//            System.out.println(elements);

        }

        @Override
        public String getHeaderText() {
            return newTable.getHeaderText().toUpperCase();
        }

        @Override
        public void setHeaderText(String newHeaderText) {
            newTable.setHeaderText(newHeaderText);
//            this.header = newHeaderText;
        }
    }

    public interface TableInterface {
        void setModel(List rows);

        String getHeaderText();

        void setHeaderText(String newHeaderText);
    }

    public static void main(String[] args) {

    }
}
/*




Мусор
   String fileExtension = getFileExtension(fileName);
            if (fileExtension != "txt") {
                super.close();
                throw new UnsupportedFileNameException();
            }

//        this.fis = new TxtInputStream(fileName);
            fis = new FileInputStream(fileName);

 */