package com.javarush.task.task18.task1818;

import java.io.*;
import java.util.Scanner;

/* 
Два в одном
public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName1 = reader.readLine();
        String fileName2 = reader.readLine();
        String fileName3 = reader.readLine();

        try (FileOutputStream fileOutputStream = new FileOutputStream(fileName1);
             FileInputStream fileInputStream1 = new FileInputStream(fileName2);
             FileInputStream fileInputStream2 = new FileInputStream(fileName3)) {
            while (fileInputStream1.available() > 0) {
                fileOutputStream.write(fileInputStream1.read());
            }
            while (fileInputStream2.available() > 0) {
                fileOutputStream.write(fileInputStream2.read());
            }
        }
    }
}

Считать с консоли 3 имени файла.
Записать в первый файл содержимого второго файла, а потом дописать в первый файл содержимое третьего файла.
Закрыть потоки.

Требования:
•	Программа должна три раза считать имена файлов с консоли.
•	Для первого файла создай поток для записи. Для двух других - потоки для чтения.
•	Содержимое второго файла нужно переписать в первый файл.
•	Содержимое третьего файла нужно дописать в первый файл (в который уже записан второй файл).
•	Созданные для файлов потоки должны быть закрыты.

*/

public class Solution {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        String fileOut = console.nextLine();
        String fileIn1 = console.nextLine();
        String fileIn2 = console.nextLine();

        try (FileOutputStream ops = new FileOutputStream(fileOut);
             FileInputStream fis1 = new FileInputStream(fileIn1)) {
            // А это вроде так.
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis1.read(buffer)) != -1) {
                ops.write(buffer, 0, bytesRead);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        try (FileOutputStream ops = new FileOutputStream(fileOut, true);
             FileInputStream fis2 = new FileInputStream(fileIn2)) {

            // А это вроде так.
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis2.read(buffer)) != -1) {
                ops.write(buffer, 0, bytesRead);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
/*

     BufferedInputStream buffInputStream1 = new BufferedInputStream(fis1);


           // Ето должно читать с буфером по умолчанию 8926
            while (buffInputStream1.read() != -1) {
                ops.write(buffInputStream1.read());
            }

//            while (buffInputStream2.read() != -1) {
//                ops.write(buffInputStream2.read(), true);
//            }


            BufferedInputStream buffInputStream2 = new BufferedInputStream(fis2);


            // Ето должно читать с буфером по умолчанию 8926
//            while (buffInputStream1.read() != -1) {
//                ops.write(buffInputStream1.read());
//            }

            while (buffInputStream2.read() != -1) {
                ops.write(buffInputStream2.read());
            }





 if (inputStream.available() > 0) {
            //читаем весь файл одним куском
            byte[] buffer = new byte[inputStream.available()];
            int count = inputStream.read(buffer);
            outputStream.write(buffer, 0, count);
        }

        inputStream.close();
        outputStream.close();

    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String filename1 = reader.readLine();
        String filename2 = reader.readLine();

        try (FileInputStream fis = new FileInputStream(filename1);
             FileOutputStream ops = new FileOutputStream(filename2)) {

            int fileLength = fis.available();
            byte[] b = new byte[fis.available()];
//            int b = 0;
            int i = 1;
            while (fis.available() > 0) {
                fis.read(b, fileLength - i, 1);
//                fis.read(b, i, 0);
//                ops.write(b, 0, 1 );
//                ops.write(b, 0, 1);

                i++;
//                if (numberOfByte < fileLength /2) {
//                    fileOutputStream1.write(fileInputStream.read());
//                    numberOfByte++;
//                } else fileOutputStream2.write(fileInputStream.read());
            }
            ops.write(b);

        }

 */