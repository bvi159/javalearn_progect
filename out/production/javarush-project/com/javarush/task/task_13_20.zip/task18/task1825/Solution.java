package com.javarush.task.task18.task1825;

import java.io.*;
import java.util.*;

/* 
Собираем файл
public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Set<String> files = new TreeSet<>(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                String[] parts1 = o1.split(".part");
                String[] parts2 = o2.split(".part");
                int number1 = Integer.parseInt(parts1[parts1.length - 1]);
                int number2 = Integer.parseInt(parts2[parts2.length - 1]);
                return number1 - number2;
            }
        });
        String outputFile = null;
        String readString;
        while (!(readString = reader.readLine()).equals("end")) {
            files.add(readString);
            if (outputFile == null) {
                int indexOfSuffix = readString.lastIndexOf(".part");
                outputFile = readString.substring(0, indexOfSuffix);
            }
        }
        if (outputFile == null) return;
        try (FileOutputStream fileOutputStream = new FileOutputStream(outputFile)) {
            for (String file : files) {
                try (FileInputStream fileInputStream = new FileInputStream(file)) {
                    byte[] buffer = new byte[fileInputStream.available()];
                    while (fileInputStream.available() > 0) {
                        int bytesRead = fileInputStream.read(buffer);
                        fileOutputStream.write(buffer, 0, bytesRead);
                    }
                }
            }
        }
    }
}

Собираем файл из кусочков.
Считывать с консоли имена файлов.
Каждый файл имеет имя: [someName].partN.

Например, Lion.avi.part1, Lion.avi.part2, ..., Lion.avi.part37.

Имена файлов подаются в произвольном порядке. Ввод заканчивается словом "end".
В папке, где находятся все прочтенные файлы, создать файл без суффикса [.partN].

Например, Lion.avi.

В него переписать все байты из файлов-частей используя буфер.
Файлы переписывать в строгой последовательности, сначала первую часть, потом вторую, ..., в конце - последнюю.
Закрыть потоки.

Требования:
•	Программа должна считывать имена файлов с консоли, пока не будет введено слово "end".
•	Создай поток для записи в файл без суффикса [.partN] в папке, где находятся все считанные файлы.
•	В новый файл перепиши все байты из файлов-частей *.partN.
•	Чтение и запись должны происходить с использованием буфера.
•	Созданные для файлов потоки должны быть закрыты.
•	Не используй статические переменные.

*/

public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        // Определяем имя файла без расщирения и расширение
        String filename = reader.readLine();
        int lastDotIndex = filename.lastIndexOf('.');
        String nameWithoutExtension = filename.substring(0, lastDotIndex);
        String extensionName = filename.substring(lastDotIndex);

        // Складываем введённые файлы в список
        List<String> fileNames = new ArrayList<>();
        while (true) {
            if (filename.equals("end")) {
                break;
            }
            fileNames.add(filename);
            filename = reader.readLine();
        }

        // Сортируем Лист с именами файлов
        // лябда s.substring(lastDotIndex+5 - это значит подстрока с цифры после part и до конца - номер части
        fileNames.sort(Comparator.comparingInt(s -> Integer.parseInt(s.substring(lastDotIndex + 5))));

        // Эта пара строк для контроля что происходит после первой части выполнения программы
        System.out.println(extensionName);
        System.out.println(fileNames);

        for (String currentfilename : fileNames) {
            // Открываем потоки с буферизацией
            try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(currentfilename));
                 BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(nameWithoutExtension, true)))
            {
                byte[] buffer = new byte[1024]; // Буфер размером 1 КБ
                int bytesRead;

                // Читаем данные из исходного файла и записываем в новый
                while((bytesRead = bis.read(buffer))!=-1) {
                            bos.write(buffer, 0, bytesRead);
                }
                    System.out.println("Данные успешно добавлены в файл!");
            } catch(IOException e) {
                    System.err.println("Ошибка: " + e.getMessage());
            }

        }

    }
}

/*
  fileNames.sort(Comparator.comparingInt(s -> s.charAt(s.length() - 1)));
 if (lastDotIndex > 0) {
            nameWithoutExtension = filename.substring(0, lastDotIndex);
            extensionName = filename.substring(lastDotIndex);
        } else {
            nameWithoutExtension = filename;
        }
 */