package com.javarush.task.task18.task1803;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;

/* 
Самые частые байты
*/
public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName = reader.readLine();

        int[] byteCountArray = new int[256];
        try (FileInputStream fileInputStream = new FileInputStream(fileName)) {
            while (fileInputStream.available() > 0) {

                byteCountArray[fileInputStream.read()] += 1;
//                System.out.print(fileInputStream.read() + " ");
            }
        }
        int maxCount = 0;
        for (int byteCount : byteCountArray) {
            if (byteCount > maxCount) maxCount = byteCount;
        }
        ArrayList<Integer> resultList = new ArrayList<>();
        for (int i = 0; i < byteCountArray.length; i++) {
            if (byteCountArray[i] == maxCount) resultList.add(i);
        }
        for (Integer resultItem : resultList) System.out.print(resultItem + " ");
    }
}

/*
Диапазон byte в Java:
Описание	        Десятичное	    Шестнадцатеричное	      Двоичное (8 бит)
Минимальное	        -128	           0x80	                    10000000
Максимальное	     127	           0x7F	                    01111111
Кол-во значений	     256	           0x00 – 0xFF	            00000000 – 11111111


public class Solution {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        String filePath = scanner.nextLine();

        try {
            findMostFrequentByte(filePath);
//            byte[] result = findMostFrequentByte(filePath);
//            System.out.printf("Самый частый байт: 0x%02X (%d), встречается %d раз%n",
//                    result[0] & 0xFF, result[0] & 0xFF, result[1]);
        } catch (IOException e) {
            System.err.println("Ошибка при чтении файла: " + e.getMessage());
        }

    }

    public static void findMostFrequentByte(String filePath) throws IOException {   //static byte[] findMostFrequentByte(String filePath)
        // Массив для подсчета количества каждого байта (0-255)
        int[] byteCounts = new int[256];

        try (FileInputStream fis = new FileInputStream(filePath)) {
            int currentByte;
            while ((currentByte = fis.read()) != -1) {
                // Увеличиваем счетчик для прочитанного байта
                byteCounts[currentByte] = byteCounts[currentByte] + 1;
//                    byteCounts[currentByte]++;
            }
        }

        // Находим байт с максимальным количеством повторов
        int maxCount = -1;
        byte mostFrequentByte = 0;

        for (int i = 0; i < byteCounts.length; i++) {
            if (byteCounts[i] > maxCount) {
                maxCount = byteCounts[i];
                mostFrequentByte = (byte) i;
            }
        }

        //
//        int[] byteCounts = new int[256];
        try (FileInputStream fis = new FileInputStream(filePath)) {
            int byteRead;
            while ((byteRead = fis.read()) != -1) {
                // Обработка байта
                byte b = (byte) byteRead;
//                for (byte i = -128; i < 128; i++) {
                    if (b == mostFrequentByte) {   //& 0xFF
                        System.out.print(b + " ");
                    }
//                }
            }
        }

        //

        // тута отсюда передаётся сам байта от 0 до 255 - mostFrequentByte byte[0]
        // и maxCount
//        return new byte[]{mostFrequentByte, (byte) maxCount};
    }
}

*/
/*
       int currentByte1;
//            try (FileInputStream fis = new FileInputStream(filePath)) {
                FileInputStream fis1 = new FileInputStream(filePath);
                while ((currentByte1 = fis1.read()) != -1) {
                    // Увеличиваем счетчик для прочитанного байта
                    if ((currentByte1 = fis1.read()) == mostFrequentByte) {
                        System.out.printf("%d ", mostFrequentByte & 0xFF);
//                        System.out.print(" " + mostFrequentByte);
                    }
                    currentByte1++;
//                byteCounts[currentByte1]++;
                }
//            }
//            for (int i = 0; i < maxCount; i++) {
//                System.out.print((byte) mostFrequentByte + " ");
//            }

 */