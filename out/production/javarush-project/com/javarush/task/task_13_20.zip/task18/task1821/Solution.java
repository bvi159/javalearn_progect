package com.javarush.task.task18.task1821;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/* 
Встречаемость символов
Почти как у меня
public class Solution {
    public static void main(String[] args) throws IOException {
        int[] aSCII = new int[128];
        try (FileReader reader = new FileReader(args[0])) {
            while (reader.ready()) {
                aSCII[reader.read()]++;
            }
        }
        for (int i = 0; i < aSCII.length; i++) {
            if (aSCII[i] != 0) {
                System.out.println((char) i + " " + aSCII[i]);
            }
        }
    }

В метод main первым параметром приходит путь к файлу.
Посчитать количество символов в файле, которые соответствуют буквам английского алфавита.
Вывести на экран число (количество символов).
Закрыть потоки.

Требования:
•	Считывать с консоли ничего не нужно.
•	Создай поток чтения из файла, который приходит первым параметром в main.
•	В файле необходимо посчитать количество символов, которые соответствуют буквам английского алфавита, и вывести это число в консоль.
•	Нужно учитывать заглавные и строчные буквы.
•	Поток чтения из файла должен быть закрыт.


*/

public class Solution {
    public static void main(String[] args) throws IOException {
        String fileName = args[0];

        // тут посчитается сколько раз повстречался каждый символ
        int[] byteCountArray = new int[256];
        try (FileInputStream fileInputStream = new FileInputStream(fileName)) {
            while (fileInputStream.available() > 0) {
                byteCountArray[fileInputStream.read()] += 1;
            }
        }
        for (int i = 0; i < 256; i++) {
            if (byteCountArray[i] > 0) {
                System.out.println((char) i + " " + byteCountArray[i]);
            }
        }

    }
}

//BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
//        FileInputStream fileInputStream = new FileInputStream(finename); //"C:\\Users\\Username\\Desktop\\test.txt"
//(fileInputStream, 200);
// ставим по умолчанию - это буфер в 8927 байта

// сделать массив для англ символов


//        ArrayList<Integer> resultList = new ArrayList<>();
//        for (int i = 0; i < byteCountArray.length; i++) {
//            if (byteCountArray[i] == maxCount) resultList.add(i);
//        }
//
//        int i;
//        int count = 0;
//
//        while ((i = bufferedInputStream.read()) != -1) {
//            for (char c = 'A'; c <= 'z'; c++) {
//                if (c == ((char) i)) count++;
////                    System.out.println(c + " → " + (int) c);
//            }
//        }
//        System.out.println(count);
//        fileInputStream.close();
//        bufferedInputStream.close();

/*
// байты с макс повтором
public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName = reader.readLine();

        int[] byteCountArray = new int[256];
        try (FileInputStream fileInputStream = new FileInputStream(fileName)) {
            while (fileInputStream.available() > 0) {

                byteCountArray[fileInputStream.read()] += 1;
//                System.out.print(fileInputStream.read() + " ");
            }
        }
        int maxCount = 0;
        for (int byteCount : byteCountArray) {
            if (byteCount > maxCount) maxCount = byteCount;
        }
        ArrayList<Integer> resultList = new ArrayList<>();
        for (int i = 0; i < byteCountArray.length; i++) {
            if (byteCountArray[i] == maxCount) resultList.add(i);
        }
        for (Integer resultItem : resultList) System.out.print(resultItem + " ");
    }
}
 */