package com.javarush.task.task18.task1819;

import java.io.*;

/*
Объединение файлов
public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName1 = reader.readLine();
        String fileName2 = reader.readLine();

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try (FileInputStream fileInputStream1 = new FileInputStream(fileName1);
             FileInputStream fileInputStream2 = new FileInputStream(fileName2)) {

            while (fileInputStream2.available() > 0) {
                byteArrayOutputStream.write(fileInputStream2.read());
            }
            while (fileInputStream1.available() > 0) {
                byteArrayOutputStream.write(fileInputStream1.read());
            }
        }
        try (FileOutputStream fileOutputStream = new FileOutputStream(fileName1)) {
            byteArrayOutputStream.writeTo(fileOutputStream);
        }
    }
}


public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName1 = reader.readLine();
        String fileName2 = reader.readLine();

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        FileInputStream fileInputStream1 = new FileInputStream(fileName1);
        FileInputStream fileInputStream2 = new FileInputStream(fileName2);

            while (fileInputStream2.available() > 0) {
                byteArrayOutputStream.write(fileInputStream2.read());
            }
            while (fileInputStream1.available() > 0) {
                byteArrayOutputStream.write(fileInputStream1.read());
            }

        FileOutputStream fileOutputStream = new FileOutputStream(fileName1);
            byteArrayOutputStream.writeTo(fileOutputStream);


        fileInputStream1.close();
        fileInputStream2.close();
    }
}

*/


public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName1 = reader.readLine();
        String fileName2 = reader.readLine();


        FileInputStream fis1 = new FileInputStream(fileName1);
        FileInputStream fis2 = new FileInputStream(fileName2);

//        BufferedReader bytefis1 = new BufferedReader(fileName1);

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        while (fis2.available() > 0) {
            byteArrayOutputStream.write(fis2.read());
        }
        while (fis1.available() > 0) {
            byteArrayOutputStream.write(fis1.read());
        }

        FileOutputStream ops = new FileOutputStream(fileName1);

        byteArrayOutputStream.writeTo(ops);

        ops.close();
        fis1.close();
        fis2.close();

    }
}
