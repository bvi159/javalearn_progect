package com.javarush.task.task18.task1810;

import java.io.*;

/* 
DownloadException
public class Solution {
    public static void main(String[] args) throws DownloadException, IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        while (true) {
            String fileName = reader.readLine();

            try (FileInputStream fileInputStream = new FileInputStream(fileName)) {
                if (fileInputStream.available() < 1000) throw new DownloadException();
            }
        }
    }

    public static class DownloadException extends Exception {

    }
}


*/

public class Solution {
    public static void main(String[] args) throws DownloadException, IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String filename1 = reader.readLine();
        FileInputStream fis = new FileInputStream(filename1);
        int fileLength = fis.available();

        while (fileLength > 0) {
            if (fileLength >= 1000) {
                fis.close();
                filename1 = reader.readLine();
                fis = new FileInputStream(filename1);
                fileLength = fis.available();
            } else {
                fis.close();
                throw new DownloadException("Попытка загрузить файл размером меньше 1000 bait");
            }
        }
        fis.close();

    }

    public static class DownloadException extends Exception {
        public DownloadException(String message) {
            super(message);
        }
    }
}
/*
   byte[] b = new byte[fis.available()];
   //                if (numberOfByte < fileLength /2) {
//                    fileOutputStream1.write(fileInputStream.read());
//                    numberOfByte++;
//                } else fileOutputStream2.write(fileInputStream.read());
while (fis.available() > 0) {
                    fis.read(b, fileLength - i, 1);
                    i++;
                }

 */