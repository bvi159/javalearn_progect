package com.javarush.task.task18.task1808;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

/* 
Разделение файла
public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String inputFile = reader.readLine();
        String outputFile1 = reader.readLine();
        String outputFile2 = reader.readLine();

        try (FileInputStream fileInputStream = new FileInputStream(inputFile);
             FileOutputStream fileOutputStream1 = new FileOutputStream(outputFile1);
             FileOutputStream fileOutputStream2 = new FileOutputStream(outputFile2)) {

            int halfOfFile = (fileInputStream.available() + 1) / 2;
            int numberOfByte = 0;
            while (fileInputStream.available() > 0) {
                if (numberOfByte < halfOfFile) {
                    fileOutputStream1.write(fileInputStream.read());
                    numberOfByte++;
                } else fileOutputStream2.write(fileInputStream.read());
            }
        }
    }
}
Считать с консоли три имени файла: файл1, файл2, файл3.
Разделить файл1 по следующему критерию:
Первую половину байт записать в файл2, вторую половину байт записать в файл3.
Если в файл1 количество байт нечетное, то файл2 должен содержать большую часть.
Закрыть потоки.

Требования:
•	Программа должна три раза считать имена файлов с консоли.
•	Для чтения из файла используй поток FileInputStream, для записи в файлы - FileOutputStream
•	Первую половину байт из первого файла нужно записать во второй файл.
•	Вторую половину байт из первого файла нужно записать в третий файл.
•	Потоки FileInputStream и FileOutputStream должны быть закрыты.
*/

public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName1 = reader.readLine();
        String fileName2 = reader.readLine();
        String fileName3 = reader.readLine();
        FileInputStream fis1 = new FileInputStream(fileName1);
        FileOutputStream ops2 = new FileOutputStream(fileName2);
        FileOutputStream ops3 = new FileOutputStream(fileName3);

        long fileSizeInBytes = Files.size(Paths.get(fileName1));
//        int halfOfFile = (fis1.available() + 1) / 2;
//        int fileSizeInBytes = (fis1.available() + 1) / 2;

        int i = 0;
        while (fis1.available() > 0) {
            if (i < (fileSizeInBytes + 1) / 2) {
//            if (i < fileSizeInBytes) {
                ops2.write(fis1.read());
            } else {
                ops3.write(fis1.read());
            }
            i++;
        }
        fis1.close();
        ops2.close();
        ops3.close();
    }
}
