package com.javarush.task.task18.task1822;

//import javafx.css.ParsedValue;
//
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.io.IOException;
//import java.io.InputStreamReader;
//
///*
//Поиск данных внутри файла
//*/
//
//public class Solution {
//    public static void main(String[] args) throws IOException {
//       BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
//       String filePath = reader.readLine();
//        int id = Integer.parseInt(args[0]);
////        id = ParsedValue(args[0]);
//
//        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
//            String line;
//
//            int firstSpaceIndex; // Находим индекс первого пробела
//            while ((line = br.readLine()) != null) {
//                firstSpaceIndex = line.indexOf(' ');
//                String substring = line.substring(0, firstSpaceIndex);
//                if (id == Integer.parseInt(substring) ) {
////                    if (id == Integer.parseInt(line) ) {
//                    System.out.println(line); // Выведет "Hello"
//                    break;
//                }
////                else
////                {
////                    System.out.println("Такова нету!!!");
////                }
//
////                System.out.println(line); // или обрабатываем строку
//
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
////       FileReader myLine = new FileReader(filename);
////       while(String tekline : myLine){
////           tekline = myLine.read();
////        }
//
//    }
//}
