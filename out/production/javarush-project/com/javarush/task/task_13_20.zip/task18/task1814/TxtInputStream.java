package com.javarush.task.task18.task1814;

import java.io.*;

/* 
UnsupportedFileName
public class TxtInputStream extends FileInputStream {

    public TxtInputStream(String fileName) throws IOException, UnsupportedFileNameException {
        super(fileName);
        if (!fileName.endsWith(".txt")) {
            super.close();
            throw new UnsupportedFileNameException();
        }
    }

    public static void main(String[] args) {
    }
Измени класс TxtInputStream так, чтобы он работал только с txt-файлами (*.txt).
Например, first.txt или name.1.part3.txt.
Если передан не txt-файл, например, file.txt.exe, то конструктор должен выбрасывать исключение UnsupportedFileNameException.
Подумай, что еще нужно сделать, в случае выброшенного исключения.

Требования:
•	Класс TxtInputStream должен наследоваться от класса FileInputStream.
•	Если в конструктор передан txt-файл, TxtInputStream должен вести себя, как обычный FileInputStream.
•	Если в конструктор передан не txt-файл, должно быть выброшено исключение UnsupportedFileNameException.
•	В случае выброшенного исключения, так же должен быть вызван super.close().

*/

public class TxtInputStream extends FileInputStream {
//    private TxtInputStream fis;
    private FileInputStream fis;
//    public static String fileName = "D:/ASProject/Java_learning/25_02_2025.txt";
//    private String filename;
//    private FileInputStream wrapped;
    // Это конструктор - тоже имя и нет возвращаемого значения
//    private TxtInputStream fis;

    public TxtInputStream(String fileName) throws IOException, UnsupportedFileNameException {
        super(fileName);

        String fileExtension = getFileExtension(fileName);
        if (fileExtension != "txt") {
            super.close();
            throw new UnsupportedFileNameException();
        }

//        this.fis = new TxtInputStream(fileName);
       fis = new FileInputStream(fileName);

    }

    // Делегируем все основные методы FileInputStream
    @Override
    public int read() throws IOException {
        return fis.read();
    }

    public int read(byte[] b) throws IOException {
        return fis.read(b);
    }

    public int read(byte[] b, int off, int len) throws IOException {
        return fis.read(b, off, len);
    }

    public long skip(long n) throws IOException {
        return fis.skip(n);
    }

    public int available() throws IOException {
        return fis.available();
    }

    public void close() throws IOException {
        fis.close();
    }


    public static void main(String[] args) {
    }

    public static String getFileExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex == -1 || dotIndex == fileName.length() - 1) {
            return "";
        }
        return fileName.substring(dotIndex + 1);
    }
}

/*
public class TxtInputStream extends FileInputStream {

    public TxtInputStream(String fileName) {
    }

    public static void main(String[] args) {
    }
}
 */