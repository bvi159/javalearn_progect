package com.javarush.task.task18.task1813;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;

/*
public class AmigoOutputStream extends FileOutputStream {
    public static String fileName = "C:/tmp/result.txt";

    FileOutputStream fileOutputStream;

    public AmigoOutputStream(FileOutputStream fileOutputStream) throws FileNotFoundException {
        super(fileName);
        this.fileOutputStream = fileOutputStream;
    }

    public static void main(String[] args) throws FileNotFoundException {
        new AmigoOutputStream(new FileOutputStream(fileName));
    }

    @Override
    public void write(int b) throws IOException {
        fileOutputStream.write(b);
    }

    @Override
    public void write(byte[] b) throws IOException {
        fileOutputStream.write(b);
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        fileOutputStream.write(b, off, len);
    }

    @Override
    public void flush() throws IOException {
        fileOutputStream.flush();
    }

    @Override
    public void close() throws IOException {
        flush();
        write("JavaRush © All rights reserved.".getBytes());
        fileOutputStream.close();
    }
}


AmigoOutputStream
1 Измени класс AmigoOutputStream так, чтобы он стал Wrapper-ом для класса FileOutputStream. Используй наследование.
2 При вызове метода close() должны выполняться следующая последовательность действий:
2.1 Вызвать метод flush().
2.2 Записать в конец файла фразу "JavaRush © All rights reserved.", используй метод getBytes().
2.3 Закрыть поток методом close().

Требования:
•	Метод main изменять нельзя.
•	Класс AmigoOutputStream должен наследоваться от класса FileOutputStream.
•	Класс AmigoOutputStream должен принимать в конструкторе объект типа FileOutputStream.
•	Все методы write(), flush(), close() в классе AmigoOutputStream должны делегировать свое выполнение объекту FileOutputStream.
•	Метод close() должен сначала вызвать метод flush(), затем записать в конец файла текст, затем закрыть поток.


*/

public class AmigoOutputStream extends FileOutputStream {
//    public static String fileName = "C:/tmp/result.txt";
    public static String fileName = "D:/ASProject/Java_learning/25_02_2025.txt";
    private FileOutputStream wrapped;

    public AmigoOutputStream(FileOutputStream name) throws FileNotFoundException {
        super(fileName);
        wrapped = name;
//        this.wrapped = wrapped;
//        super(fileName);
//        this.name = name;
    }

    @Override
    public void flush() throws IOException {
        wrapped.flush();
    }

    @Override
    public void write(int b) throws IOException {
        wrapped.write(b);
    }

    @Override
    public void write(byte[] b) throws IOException {
        wrapped.write(b);
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        wrapped.write(b, off, len);
    }

    @Override
    public void close() throws IOException {
        wrapped.flush();
        String textToAppend = "JavaRush © All rights reserved.";
        wrapped.write(textToAppend.getBytes());
        wrapped.close();
    }
// Ихний main ничего не делает - пустой файл
//    public static void main(String[] args) throws FileNotFoundException {
//        new AmigoOutputStream(new FileOutputStream(fileName));
//    }

    // мой мэйн записывает что надо
        public static void main(String[] args) throws IOException, FileNotFoundException {
        AmigoOutputStream maxMyFactor = new AmigoOutputStream(new FileOutputStream(fileName));
        maxMyFactor.flush();
        maxMyFactor.close();
    }


}
/*
исходный код
public class AmigoOutputStream {
    public static String fileName = "C:/tmp/result.txt";

    public static void main(String[] args) throws FileNotFoundException {
        new AmigoOutputStream(new FileOutputStream(fileName));
    }

}


//    public static void main(String[] args) throws IOException, FileNotFoundException {
//        AmigoOutputStream maxMyFactor = new AmigoOutputStream(new FileOutputStream(fileName));
//        maxMyFactor.flush();
//        maxMyFactor.close();
//    }



//        try (FileOutputStream fos = new FileOutputStream(fileName, true)) {
//            // Преобразуем строку в байты и записываем в конец файла
//            fos.write(textToAppend.getBytes());
//        } catch (IOException e) {
//            System.err.println("Ошибка при записи в файл: " + e.getMessage());
//        }


//        this.write("JavaRush © All rights reserved.", g ));

//        System.out.println("Вы действительно хотите закрыть поток? Д/Н");
//        if (bufferedReader.readLine().equals("Д")) wrapped.close();
 */