package com.javarush.task.task18.task1802;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

/* 
Минимальный байт
*/

public class Solution {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        String fileName1 = scanner.nextLine();
        FileInputStream inputStream = new FileInputStream(fileName1);
        int minBite = Integer.MAX_VALUE;
        int data = 0;
        while (inputStream.available() > 0) //пока остались непрочитанные байты
        {
            data = inputStream.read(); //прочитать очередной байт
            if (data < minBite) {
                minBite = data;
            }
        }
        inputStream.close(); // закрываем поток

        System.out.println(minBite); //выводим на экран минимальный байт.

    }
}
