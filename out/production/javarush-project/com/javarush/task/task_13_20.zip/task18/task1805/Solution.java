package com.javarush.task.task18.task1805;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

/* 
Сортировка байт
*/

public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName = reader.readLine();

        int[] byteCountArray = new int[256];
        ArrayList<Integer> resultList1 = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(fileName)) {
            int byteRead;
            Integer integerByteRead = 0;
            while ((byteRead = fis.read()) != -1) {
                byte b = (byte) byteRead;
                // Обработка байта
                // Здесь выводится содержимое фойла ANSII по умолчанию
                char chr = (char) byteRead;
                System.out.print(b + " ");
//                System.out.print(chr);
                // Т.к выставить нужную кодировку - целая проблема
                if (!resultList1.contains((int) b)){
                    resultList1.add((int) b);
                }
            }
//                byteCountArray[fileInputStream.read()] += 1;
        }
        Collections.sort(resultList1);
//        int maxCount = 0;
//        for (int byteCount : byteCountArray) {
//            if (byteCount > maxCount) maxCount = byteCount;
//        }
//        ArrayList<Integer> resultList = new ArrayList<>();
//        for (int i = 0; i < byteCountArray.length; i++) {
//            if (byteCountArray[i] == maxCount) resultList.add(i);
//        }
        for (Integer resultItem : resultList1) System.out.print(resultItem + " ");
    }
}
