package com.javarush.task.task18.task1816;

import java.io.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/* 
Английские буквы
*/

public class Solution {


        public static void main(String[] args) throws IOException {

            String finename = args[0];

            FileInputStream fileInputStream = new FileInputStream(finename); //"C:\\Users\\Username\\Desktop\\test.txt"
            //(fileInputStream, 200);
            // ставим по умолчанию - это буфер в 8927 байта
            BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);

            int i;
            int count = 0;

            while ((i = bufferedInputStream.read()) != -1) {
                for (char c = 'A'; c <= 'z'; c++) {
                    if (c == ((char) i)) count++;
//                    System.out.println(c + " → " + (int) c);
                }
            }
            System.out.println(count);
            fileInputStream.close();
            bufferedInputStream.close();
        }

}
/*

public class com.javarush.examples.Lesson_10_7.Main {

   public static void main(String[] args) throws IOException {

       FileInputStream fileInputStream = new FileInputStream("C:\\Users\\Username\\Desktop\\test.txt");

       BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream, 200);

       int i;

       while((i = bufferedInputStream.read())!= -1){

           System.out.print((char)i);
       }
   }
}

 FileOutputStream ops = new FileOutputStream(filename2)
 */