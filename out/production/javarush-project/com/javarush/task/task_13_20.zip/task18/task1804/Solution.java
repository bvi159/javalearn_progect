package com.javarush.task.task18.task1804;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/* 
Самые редкие байты
public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName = reader.readLine();

        int[] byteCountArray = new int[256];
        try (FileInputStream fileInputStream = new FileInputStream(fileName)) {
            while (fileInputStream.available() > 0) {
                byteCountArray[fileInputStream.read()] += 1;
            }
        }
        int minCount = Integer.MAX_VALUE;
        for (int byteCount : byteCountArray) {
            if (byteCount > 0 && byteCount < minCount) minCount = byteCount;
        }
        ArrayList<Integer> resultList = new ArrayList<>();
        for (int i = 0; i < byteCountArray.length; i++) {
            if (byteCountArray[i] == minCount) resultList.add(i);
        }
        for (Integer resultItem : resultList) System.out.print(resultItem + " ");
    }
}

Ввести с консоли имя файла.
Найти байт или байты с минимальным количеством повторов.
Вывести их на экран через пробел.
Закрыть поток ввода-вывода.

Требования:
•	Программа должна считывать имя файла с консоли.
•	Для чтения из файла используй поток FileInputStream.
•	В консоль через пробел должны выводиться все байты из файла с минимальным количеством повторов.
•	Данные в консоль должны выводится в одну строку.
•	Поток чтения из файла должен быть закрыт.

*/

public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName = reader.readLine();

        int[] byteCountArray = new int[256];
        for (int i = 0; i < byteCountArray.length; i++) {
            byteCountArray[i] = Integer.MAX_VALUE;
        }
        try (FileInputStream fis = new FileInputStream(fileName)) {
            while (fis.available() > 0) {

                // в квадр скобках - это и байт и номер ячейки в массиве - может быть от 0 до 255
                // дальше берём число из этой ячейки увеличиваем на 1 и помещаем обратно
                // и так пока файл (байты - значения от 0 до 255) не кончатся
//                                byteCountArray[fis.read()]++ += 1;
                byteCountArray[fis.read()]++;
//                String str = new String(byteCountArray[fis.read()], StandardCharsets.UTF_8);
//                char c = str.charAt(0);

//                char c = (char)(byteCountArray[fis.read()] & 0xFF);
                System.out.print((char) fis.read() + " ");
//                System.out.print(c + " ");
//                byteCountArray[fis.read()] = byteCountArray[fis.read()] + 1;

            }
        }
        int minCount = Integer.MAX_VALUE;
        for (int byteCount : byteCountArray) {
            if (minCount > byteCount) minCount = byteCount;
        }
        ArrayList<Integer> resultList = new ArrayList<>();
        for (int i = 0; i < byteCountArray.length; i++) {
            if (byteCountArray[i] == minCount) resultList.add(i);
        }
        for (Integer resultItem : resultList) System.out.print(resultItem + " ");
    }
}
