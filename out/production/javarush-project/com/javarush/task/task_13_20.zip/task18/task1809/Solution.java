package com.javarush.task.task18.task1809;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* 
Реверс файла
*/

public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String filename1 = reader.readLine();
        String filename2 = reader.readLine();

        try (FileInputStream fis = new FileInputStream(filename1);
             FileOutputStream ops = new FileOutputStream(filename2)) {

            int fileLength = fis.available();
            byte[] b = new byte[fis.available()];
//            int b = 0;
            int i = 1;
            while (fis.available() > 0) {
                fis.read(b, fileLength - i, 1);
//                fis.read(b, i, 0);
//                ops.write(b, 0, 1 );
//                ops.write(b, 0, 1);

                i++;
//                if (numberOfByte < fileLength /2) {
//                    fileOutputStream1.write(fileInputStream.read());
//                    numberOfByte++;
//                } else fileOutputStream2.write(fileInputStream.read());
            }
            ops.write(b);

        }

    }
}
/*
  byte[] buffer = new byte[inputStream.available()];
            int count = inputStream.read(buffer);
            outputStream.write(buffer, 0, count);
 */