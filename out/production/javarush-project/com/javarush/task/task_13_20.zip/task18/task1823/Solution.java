package com.javarush.task.task18.task1823;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* 
Нити и байты
public class Solution {
    public static Map<String, Integer> resultMap = new HashMap<String, Integer>();

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String readString;
        while (!(readString = reader.readLine()).equals("exit")) {
            new ReadThread(readString).start();
        }
    }

    public static class ReadThread extends Thread {
        private String fileName;

        public ReadThread(String fileName) {
            this.fileName = fileName;
        }

        @Override
        public void run() {
            byte[] bytesCount = new byte[256];
            try (FileInputStream fileInputStream = new FileInputStream(fileName)) {
                while (fileInputStream.available() > 0) {
                    int aByte = fileInputStream.read();
                    bytesCount[aByte]++;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            int maxCount = 0;
            int maxCountByte = 0;
            for (int i = 0; i < bytesCount.length; i++) {
                if (bytesCount[i] > maxCount) {
                    maxCount = bytesCount[i];
                    maxCountByte = i;
                }
            }
            resultMap.put(fileName, maxCountByte);
        }
    }
}

Читайте с консоли имена файлов, пока не будет введено слово "exit".
Передайте имя файла в нить ReadThread.
Нить ReadThread должна найти байт, который встречается в файле максимальное число раз (если таких байтов несколько, выбрать наименьший), и добавить его в словарь resultMap,
где параметр String - это имя файла, параметр Integer - это искомый байт.
Закрыть потоки.

Требования:
•	Программа должна считывать имена файлов с консоли, пока не будет введено слово "exit".
•	Для каждого файла создай нить ReadThread и запусти ее.
•	После запуска каждая нить ReadThread должна создать свой поток для чтения из файла.
•	Затем нити должны найти максимально встречающийся байт в своем файле и добавить его в словарь resultMap.
•	Поток для чтения из файла в каждой нити должен быть закрыт.

*/

public class Solution {
    public static volatile Map<String, Integer> resultMap = new HashMap<String, Integer>();

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        List<Thread> threads = new ArrayList<>(); // Храним потоки для управления
        String filename = reader.readLine();

        while (true) {
            if (filename.equals("exit")) {
                break;
            }
            Thread mythread = new ReadThread(filename);
            mythread.start();
            threads.add(mythread);
            filename = reader.readLine();
        }
        // Ожидаем завершения всех потоков (опционально)
        for (Thread thread : threads) {
            try {
                thread.join(); // Ждём завершения потока
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        for (String key : resultMap.keySet()) {
            System.out.println("Key: " + key + ", Value: " + (char) resultMap.get(key).intValue());
//            System.out.println("Key: " + key + ", Value: " + resultMap.get(key));
        }
//        for (Integer resultItem : resultMap.values())
//            System.out.print(resultItem + " ");

    }

    public static class ReadThread extends Thread {
        private String filePath;

        public ReadThread(String fileName) {
            //implement constructor body
            this.filePath = fileName;
        }

        @Override
        public void run() {
            int[] byteCountArray = new int[256];
            try (FileInputStream fileInputStream = new FileInputStream(filePath)) {
                while (fileInputStream.available() > 0) {
                    byteCountArray[fileInputStream.read()] += 1;
//                System.out.print(fileInputStream.read() + " ");
                }
            } catch (IOException e) {
                e.printStackTrace();
//                throw new RuntimeException(e);
            }
            int maxCount = 0;
//            for (int byteCount : byteCountArray) {
            // Вот здесь уже учтено условие -- выбрать наименьший -- , и добавить его в словарь resultMap(идёт в следующем fori),
            for (int byteCount : byteCountArray) {
                if (byteCount > maxCount) {
                    maxCount = byteCount;
                }
            }

            for (int i = 0; i < byteCountArray.length; i++) {
//                if (byteCountArray[i] == maxCount) resultList.add(i);
                if (byteCountArray[i] == maxCount) {
//                    resultMap.put(String.valueOf(i), maxCount);
                    resultMap.put(filePath, byteCountArray[i]);
                    resultMap.put(filePath, i);
                }
            }
//            for (Integer resultItem : resultMap.values()) System.out.print(resultItem + " ");
//                    for (Integer resultItem : resultList) System.out.print(resultItem + " ");
        }

        // implement file reading here - реализуйте чтение из файла тут

    }
}

/*
  Thread mythread = new ReadThread(filename);
                mythread.start();
                mythread.stop();
                filename = reader.readLine();
            } else {
 */