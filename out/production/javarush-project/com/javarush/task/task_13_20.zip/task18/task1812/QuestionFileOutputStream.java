package com.javarush.task.task18.task1812;

import java.io.*;
import java.util.Scanner;

/* 
Расширяем AmigoOutputStream
Используя шаблон проектирования Wrapper (Decorator) расширь функциональность AmigoOutputStream.
В классе QuestionFileOutputStream при вызове метода close() должна быть реализована следующая функциональность:
1. Вывести в консоль фразу "Вы действительно хотите закрыть поток? Д/Н".
2. Считай строку.
3. Если считанная строка равна "Д", то закрыть поток.
4. Если считанная строка не равна "Д", то не закрывать поток.

Требования:
•	Интерфейс AmigoOutputStream изменять нельзя.
•	Класс QuestionFileOutputStream должен реализовывать интерфейс AmigoOutputStream.
•	Класс QuestionFileOutputStream должен инициализировать в конструкторе поле типа AmigoOutputStream.
•	Все методы QuestionFileOutputStream должны делегировать свое выполнение объекту AmigoOutputStream.
•	Метод close() должен спрашивать у пользователя "Вы действительно хотите закрыть поток? Д/Н".
•	Метод close() должен закрывать поток только в случае, если считает с консоли ответ "Д".



*/
public class QuestionFileOutputStream implements AmigoOutputStream {
    private FileOutputStream wrapped;
//    private AmigoOutputStream wrapped;
    private BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

    //public class QuestionFileOutputStream implements AmigoOutputStream {
// КОНСТРУКТОР
//    public QuestionFileOutputStream(AmigoOutputStream outputStream) {
//          this.wrapped = outputStream;
////        this.wrapped = myQunWrap; //new QuestionFileOutputStream();
//    }
    public QuestionFileOutputStream(FileOutputStream wrapped) {
        this.wrapped = wrapped;
//        this.wrapped = myQunWrap; //new QuestionFileOutputStream();
    }


    @Override
    public void flush() throws IOException {
        wrapped.flush();
    }

    @Override
    public void write(int b) throws IOException {
        wrapped.write(b);
    }

    @Override
    public void write(byte[] b) throws IOException {
        wrapped.write(b);
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        wrapped.write(b, off, len);
    }

    @Override
    public void close() throws IOException {
        System.out.println("Вы действительно хотите закрыть поток? Д/Н");
        if (bufferedReader.readLine().equals("Д")) wrapped.close();
    }
    public static void main(String[] args) throws IOException {

        FileOutputStream original = new FileOutputStream(
           "D:\\ASProject\\Java_learning\\25_02_2025_1.txt");
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        bufferedReader.readLine();
        original.close();
    }
//    public static void main(String[] args) throws IOException {
//        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
//            FileOutputStream original = new FileOutputStream(
//           "D:\\ASProject\\Java_learning\\25_02_2025_1.txt");
//        this.myFileOut = myFileOut;
//
//        QuestionFileOutputStream myOut = new QuestionFileOutputStream("D:\\ASProject\\Java_learning\\25_02_2025_1.txt")
//            original.close();
//            WrapperImplementation wrapper = new WrapperImplementation(original);
//            wrapper.close(); // Вызовет оригинальный метод с доп. функциональностью
//    }

}

/*
public void close() throws IOException {
        System.out.println("Вы действительно хотите закрыть поток? Д/Н");
        Scanner scanner = new Scanner(System.in);
        String str = scanner.nextLine();
        while (true) {
            if (str != "Д") {
                wrapped.close();
            }
        }
    }

 private AmigoOutputStream amigoOutputStream;
    private BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

    public QuestionFileOutputStream(AmigoOutputStream outputStream) {
        this.amigoOutputStream = outputStream;
    }

    @Override
    public void flush() throws IOException {
        amigoOutputStream.flush();
    }

    @Override
    public void write(int b) throws IOException {
        amigoOutputStream.write(b);
    }

    @Override
    public void write(byte[] b) throws IOException {
        amigoOutputStream.write(b);
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        amigoOutputStream.write(b, off, len);
    }

    @Override
    public void close() throws IOException {
        System.out.println("Вы действительно хотите закрыть поток? Д/Н");
        if (bufferedReader.readLine().equals("Д")) amigoOutputStream.close();
    }
}



class WrapperImplementation implements AmigoOutputStream {
    private AmigoOutputStream wrapped;

//public class QuestionFileOutputStream implements AmigoOutputStream {
// КОНСТРУКТОР
    public WrapperImplementation(AmigoOutputStream wrapped) {
        this.wrapped = wrapped; //new QuestionFileOutputStream();
    }

    public void flush() throws IOException{
        wrapped.flush();
    }

    public void write(int b) throws IOException{
        wrapped.write(b);
    }

    public void write(byte[] b) throws IOException{
        wrapped.write(b);
    }

    public void write(byte[] b, int off, int len) throws IOException{
        wrapped.write(b);
    }

    public void close() throws IOException{
        System.out.println("Вы действительно хотите закрыть поток? Д/Н");
        Scanner scanner = new Scanner(System.in);
        String str = scanner.nextLine();
        while (true){
            if(str != "Д"){
                wrapped.close();
            }
        }
    }

    // Использование
    // Использование

        public static void main(String[] args) throws IOException {
//            QuestionFileOutputStream original = new QuestionFileOutputStream(myQunWrap);
//            WrapperImplementation wrapper = new WrapperImplementation(original);

//            wrapper.close(); // Вызовет оригинальный метод с доп. функциональностью

        }


}

 */

/*
DownloadException
public class Solution {
    public static void main(String[] args) throws DownloadException, IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        while (true) {
            String fileName = reader.readLine();

            try (FileInputStream fileInputStream = new FileInputStream(fileName)) {
                if (fileInputStream.available() < 1000) throw new DownloadException();
            }
        }
    }

    public static class DownloadException extends Exception {

    }
}


*/
