package com.javarush.task.task18.task1807;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;

/* 
Подсчет запятых


*/
public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName = reader.readLine();

        int commaCount = 0;
        try (FileInputStream fileInputStream = new FileInputStream(fileName)) {
            while (fileInputStream.available() > 0) {
                if (fileInputStream.read() == 44) commaCount++;
            }
        }
        System.out.println(commaCount);
    }
}


/*
public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String fileName = reader.readLine();

//        int[] byteCountArray = new int[256];
        int count = 0;
//        ArrayList<Integer> resultList = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(fileName)) {
            int byteRead;
            while ((byteRead = fis.read()) != -1) {
                byte b = (byte) byteRead;
                char chr = (char) byteRead;
                if (chr == 44) {
//                    if (chr == (int) ',') {
                    count++;
                }
            }
        }
        System.out.println(count);
    }
}
 */