package com.javarush.task.task18.task1801;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

/* 
Максимальный байт
*/

public class Solution {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        String fileName1 = scanner.nextLine();
        FileInputStream inputStream = new FileInputStream(fileName1);
        int maxBite = 0;
        int data = 0;
        while (inputStream.available() > 0) //пока остались непрочитанные байты
        {
            data = inputStream.read(); //прочитать очередной байт
            if (data > maxBite) {
                maxBite = data;
            }
//            sum += data; //добавить его к общей сумме
        }
        inputStream.close(); // закрываем поток

        System.out.println(maxBite); //выводим на экран максимальный байт.

//        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));


    }
}

/*
public class Solution {
    public static void main(String[] args) throws Exception {
        //Создаем поток-чтения-байт-из-файла
        FileInputStream inputStream = new FileInputStream("C:\\Users\\Vic_host.BIG\\Downloads\\ТЗ на ИГИ линейные объекты_compressed.pdf");
        // Создаем поток-записи-байт-в-файл
        FileOutputStream outputStream = new FileOutputStream("C:\\Users\\Vic_host.BIG\\Downloads\\ТЗ на ИГИ линейные объекты_3.pdf");

        while (inputStream.available() > 0) //пока есть еще непрочитанные байты
        {
            int data = inputStream.read(); // прочитать очередной байт в переменную data
            outputStream.write(data); // и записать его во второй поток
        }

        inputStream.close(); //закрываем оба потока. Они больше не нужны.
        outputStream.close();
    }
}

 */