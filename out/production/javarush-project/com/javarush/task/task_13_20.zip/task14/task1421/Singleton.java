package com.javarush.task.task14.task1421;

public class Singleton {  //Пусть это будет овца Долли
    private static Singleton instance;
    private static String name;

    public static Singleton getInstance(String str) {
        if (instance == null) {
            instance = new Singleton();
        }
        setName(str);
        return instance;
    }
    public static void setName(String strName) {
        name = strName;
//        return name;
    }

    public String getName() {
        name = this.name;
        return name;
    }
    // Конструкторы
    private Singleton() {
    }
//    private Singleton(String name) {
//    }
}
/*
//
//        return (instance != null ? instance : null);
 */