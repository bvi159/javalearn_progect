package com.javarush.task.task14.task1419;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.EmptyStackException;
import java.util.List;

/* 
Нашествие исключений

package com.javarush.task.task14.task1419;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.ArrayList;
import java.util.List;

public class Solution {
    public static List<Exception> exceptions = new ArrayList<Exception>();

    public static void main(String[] args) {
        initExceptions();

        for (Exception exception : exceptions) {
            System.out.println(exception);
        }
    }

    private static void initExceptions() {   //it's first exception
        try {
            float i = 1 / 0;

        } catch (Exception e) {
            exceptions.add(e);
        }

        //Add your code here

        exceptions.add(new ArrayIndexOutOfBoundsException());
        exceptions.add(new IllegalArgumentException());
        exceptions.add(new IllegalAccessException());
        exceptions.add(new NumberFormatException());
        exceptions.add(new ClassCastException());
        exceptions.add(new IOException());
        exceptions.add(new InterruptedIOException());
        exceptions.add(new InterruptedException());
        exceptions.add(new SecurityException());
    }
}
Заполни список exceptions десятью различными исключениями.
Первое исключение уже реализовано в методе initExceptions.

Требования:
Список exceptions должен содержать 10 элементов.
Все элементы списка exceptions должны быть исключениями (потомками класса Throwable).
Все элементы списка exceptions должны быть уникальны.
Метод initExceptions должен быть статическим.


*/

public class Solution {
    public static List<Exception> exceptions = new ArrayList<Exception>();

    public static void main(String[] args) {
        initExceptions();

        for (Exception exception : exceptions) {
            System.out.println(exception);
        }
    }

    private static void initExceptions() {   //the first exception
        try {
            float i = 1 / 0;

        } catch (ArithmeticException e) {
            exceptions.add(e);
            Exception c = new IllegalArgumentException();
            exceptions.add(c);
            c = new SecurityException();
            exceptions.add(c);
            c = new EmptyStackException();
            exceptions.add(c);
            c = new ArrayIndexOutOfBoundsException();
            exceptions.add(c);
            c = new ClassCastException();
            exceptions.add(c);
            c = new StringIndexOutOfBoundsException();
            exceptions.add(c);
            c = new IndexOutOfBoundsException();
            exceptions.add(c);
            c = new ConcurrentModificationException();
            exceptions.add(c);
            c = new IllegalThreadStateException();
            exceptions.add(c);
        } catch (IllegalArgumentException a) {
            exceptions.add(a);
        } catch (SecurityException b) {
            exceptions.add(b);
        } catch (NullPointerException c) {
            exceptions.add(c);
        } catch (EmptyStackException d) {
            exceptions.add(d);
        } catch (ArrayIndexOutOfBoundsException f) {
            exceptions.add(f);
        } catch (ClassCastException j) {
            exceptions.add(j);
        } catch (StringIndexOutOfBoundsException h) {
            exceptions.add(h);
        } catch (UndeclaredThrowableException k) {
            exceptions.add(k);
        } catch (ConcurrentModificationException l) {
            exceptions.add(l);
        }

        //напишите тут ваш код
//        exceptions.add(new Exception("ArithmeticException();
//        exceptions.add(new Exception("IllegalArgumentException();
//        exceptions.add(new Exception("SecurityException();
//        exceptions.add(new Exception("NullPointerException();
//        exceptions.add(new Exception("EmptyStackException();
//        exceptions.add(new Exception("ArrayIndexOutOfBoundsException();
//        exceptions.add(new Exception("ClassCastException();
//        exceptions.add(new Exception("StringIndexOutOfBoundsException();
//        exceptions.add(new Exception("UndeclaredThrowableException();
//        exceptions.add(new Exception("ConcurrentModificationException();
    }
}
//        exceptions.add(new Exception("SecurityException();
//        exceptions.add(new Exception("IOException();
//        exceptions.add(new Exception("NullPointerException();
//        exceptions.add(new Exception("ArithmeticException();
//        exceptions.add(new Exception("ArrayIndexOutOfBoundsException();
//        exceptions.add(new Exception("ClassCastException();
//        exceptions.add(new Exception("ConcurrentModificationException();
//        exceptions.add(new Exception("EmptyStackException();
//        exceptions.add(new Exception("IllegalArgumentException();