package com.javarush.task.task14.task1408;

/* 
Куриная фабрика
файл RussianHen.java
package com.javarush.task.task14.task1408;

public class RussianHen extends Hen {
    @Override
    String getDescription() {
        return super.getDescription() + String.format(" Моя страна - %s. Я несу %d яиц в месяц.", Country.RUSSIA, getCountOfEggsPerMonth());
    }

    @Override
    int getCountOfEggsPerMonth() {
        return 5;
    }
}
файл UkrainianHen.java
package com.javarush.task.task14.task1408;

public class UkrainianHen extends Hen {
    @Override
    String getDescription() {
        return super.getDescription() + String.format(" Моя страна - %s. Я несу %d яиц в месяц.", Country.UKRAINE, getCountOfEggsPerMonth());
    }

    @Override
    int getCountOfEggsPerMonth() {
        return 10;
    }
}
файл MoldovanHen.java
package com.javarush.task.task14.task1408;

public class MoldovanHen extends Hen {
    @Override
    String getDescription() {
        return super.getDescription() + String.format(" Моя страна - %s. Я несу %d яиц в месяц.", Country.MOLDOVA, getCountOfEggsPerMonth());
    }

    @Override
    int getCountOfEggsPerMonth() {
        return 9;
    }
}
файл BelarusiaHen.java
package com.javarush.task.task14.task1408;

public class BelarusianHen extends Hen {
    @Override
    String getDescription() {
        return super.getDescription() + String.format(" Моя страна - %s. Я несу %d яиц в месяц.", Country.BELARUS, getCountOfEggsPerMonth());
    }

    @Override
    int getCountOfEggsPerMonth() {
        return 11;
    }
}
файл Hen.java
package com.javarush.task.task14.task1408;

public abstract class Hen {
    abstract int getCountOfEggsPerMonth();

    String getDescription() {
        return "Я - курица.";
    }
}

файл Solution
public class Solution {
    public static void main(String[] args) {
        Hen hen = HenFactory.getHen(Country.BELARUS);
        hen.getCountOfEggsPerMonth();
    }

    static class HenFactory {

        static Hen getHen(String country) {
            Hen hen = null;

            switch (country) {
                case Country.BELARUS:
                    hen = new BelarusianHen();
                    break;
                case Country.RUSSIA:
                    hen = new RussianHen();
                    break;
                case Country.UKRAINE:
                    hen = new UkrainianHen();
                    break;
                case Country.MOLDOVA:
                    hen = new MoldovanHen();
                    break;
            }
            return hen;
        }
    }
}
Давай напишем Фабрику (Factory) по производству кур (Hen):
Создай класс Hen.
Сделай его абстрактным.
Добавь в класс абстрактный метод int getCountOfEggsPerMonth().
Добавь в класс метод String getDescription(), который возвращает строку "Я - курица.".
Создай класс RussianHen, который наследуется от Hen.
Создай класс UkrainianHen, который наследуется от Hen.
Создай класс MoldovanHen, который наследуется от Hen.
Создай класс BelarusianHen, который наследуется от Hen.
В каждом из четырех последних классов напиши свою реализацию метода getCountOfEggsPerMonth.
Методы должны возвращать количество яиц в месяц от данного типа куриц.
В каждом из четырех последних классов напиши свою реализацию метода getDescription.
Методы должны возвращать строку вида:
<getDescription() родительского класса> + <" Моя страна - Sssss. Я несу N яиц в месяц.">
где Sssss - название страны
где N - количество яиц в месяц

В классе HenFactory реализуй метод getHen, который возвращает соответствующую стране породу кур.
Все созданные классы должны быть в отдельных файлах.
Требования:
•	Класс Hen должен быть абстрактным.
•	Класс Hen должен содержать абстрактный метод int getCountOfEggsPerMonth().
•	В классе Hen должен быть реализован метод String getDescription(), который возвращает строку "Я - курица.".
•	Классы RussianHen, UkrainianHen, MoldovanHen и BelarusianHen должны наследоваться от класса Hen и быть созданы в отдельных файлах.
•	Классы RussianHen, UkrainianHen, MoldovanHen и BelarusianHen должны реализовывать метод getCountOfEggsPerMonth, который должен возвращать количество яиц в месяц от данного типа куриц.
•	Классы RussianHen, UkrainianHen, MoldovanHen и BelarusianHen должны переопределять метод getDescription родительского класса таким образом, чтобы возвращаемая ими строка имела вид: <getDescription() родительского класса> + < Моя страна - Sssss. Я несу N яиц в месяц.> где Sssss - название страны, а N - количество яиц в месяц.
•	Метод getHen должен быть реализован в классе HenFactory и возвращать тип кур для переданной в него страны.

*/

public class Solution {
    public static void main(String[] args) {
//        System.out.println(BelarussianHen.getCountOfEggsPerMonth());
//        System.out.println(BelarussianHen.getDescription());
        Hen hen = HenFactory.getHen(Country.BELARUS);
        hen.getCountOfEggsPerMonth();
        System.out.println(hen.getCountOfEggsPerMonth());
        System.out.println(hen.getDescription());
    }

    static class HenFactory {

        static Hen getHen(String country) {
            Hen hen = null;

            if (country.equals(Country.RUSSIA)) {
                return new RussianHen();
            } else if (country.equals(Country.BELARUS)) {
                return new BelarusianHen();
            } else if (country.equals(Country.MOLDOVA)) {
                return new MoldovanHen();
            } else if (country.equals(Country.UKRAINE)) {
                return new UkrainianHen();
            }else{
            return hen;}
        }
    }


}
/*
         RussianHen henRus = null;
            BelarusianHen henBel = null;
            MoldovanHen henMol = null;
            UkrainianHen henUk = null;

//            String UKRAINE = "Ukraine";
//            String RUSSIA = "Russia";
//            String MOLDOVA = "Moldova";
//            String BELARUS = "Belarus";

//            switch (country) {
//                case 1:
//                    String russia = "Russia";
//                    return new RussianHen();
//                case 1:
//                    String russia = "Russia";
//                    return new RussianHen();
//
//            }
 */