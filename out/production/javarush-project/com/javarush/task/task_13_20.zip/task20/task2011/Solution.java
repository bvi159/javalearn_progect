package com.javarush.task.task20.task2011;

import java.io.*;

/* 
Externalizable для апартаментов
*/

//Java написать main для программы:

public class Solution {

    public static class Apartment implements Externalizable {

        private String address;
        private int year;

        /**
         * Mandatory public no-arg constructor.
         */
        public Apartment() {
            super();
        }

        public Apartment(String addr, int y) {
            address = addr;
            year = y;
        }

        /**
         * Prints out the fields used for testing!
         */
        public String toString() {
            return ("Address: " + address + "\n" + "Year: " + year);
        }

        @Override
        public void writeExternal(ObjectOutput out) throws IOException {
//            Apartment myNewaprtment = new Apartment();
            out.writeObject(address);
            out.writeInt(year);

        }

        @Override
        public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
//            Apartment myNewaprtment = new Apartment();
//            FileReader myFile = new FileReader(in);
            address = (String) in.readObject();
//            year = Integer.parseInt(in.readLine());
            year = in.readInt();
//            myNewaprtment.address = in.readLine();
//            myNewaprtment.year = Integer.parseInt(in.readLine());
        }
    }

    public static void main(String[] args) {
        // Создаем объект Apartment
        Apartment myNewaprtment = new Apartment(); //("Mira 237", 1937);
        myNewaprtment.address = "Mira 237";
        myNewaprtment.year = 1937;
        //ИЛИ МОЖНО ТАК: Apartment myNewaprtment = new Apartment("Mira 237", 1937);
        // Сериализуем объект в файл

        File directory = new File("D:\\ASProject\\Java_learning");
        File your_file_name = null;
        try {
            your_file_name = File.createTempFile("your_file_name", ".tmp", directory);
            ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(your_file_name));
//            InputStream inputStream = new FileInputStream(your_file_name);
//
            myNewaprtment.writeExternal(outputStream);
            System.out.println("\nApartment serialized successfully.");
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Десериализуем объект из файла
        Apartment deserializedApartment = new Apartment();

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(your_file_name))) {
            deserializedApartment.readExternal(in);
            System.out.println("\nApartment deserialized successfully.");
            System.out.println("\nDeserialized Apartment:");
            System.out.println(deserializedApartment.toString());
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}
//}
/*

 // Создаем объект Apartment
        Apartment originalApartment = new Apartment("123 com.javarush.examples.Lesson_10_7.Main St", 2020);
        System.out.println("Original Apartment:");
        System.out.println(originalApartment);

        // Сериализуем объект в файл
        String filename = "apartment.ser";
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            originalApartment.writeExternal(out);
            System.out.println("\nApartment serialized successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Десериализуем объект из файла
        Apartment deserializedApartment = new Apartment();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            deserializedApartment.readExternal(in);
            System.out.println("\nApartment deserialized successfully.");
            System.out.println("\nDeserialized Apartment:");
            System.out.println(deserializedApartment);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        // Проверяем, что объекты эквивалентны
        System.out.println("\nOriginal and deserialized apartments are equal: " +
                originalApartment.toString().equals(deserializedApartment.toString()));


     Apartment myNewaprtment = new Apartment("Mira 237", 1937);
//        myNewaprtment.address = "Mira 237";
//        myNewaprtment.year = 1937;
        // Сериализуем объект в файл
//        String filename = "apartment.ser";
//        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
//            myNewaprtment.writeExternal(out);
//            System.out.println("\nApartment serialized successfully.");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        File directory = new File("D:\\ASProject\\Java_learning");
        File your_file_name = null;
        try {
            your_file_name = File.createTempFile("your_file_name", ".tmp", directory);
            ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(your_file_name));
//            InputStream inputStream = new FileInputStream(your_file_name);
//
            myNewaprtment.writeExternal(outputStream);
            System.out.println("\nApartment serialized successfully.");
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Десериализуем объект из файла
        Apartment deserializedApartment = new Apartment();

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(your_file_name))) {
            deserializedApartment.readExternal(in);
            System.out.println("\nApartment deserialized successfully.");
            System.out.println("\nDeserialized Apartment:");
            System.out.println(deserializedApartment.toString());
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
 */