package com.javarush.task.task20.task2020;

import java.io.*;
import java.util.logging.Logger;

/* 
Сериализация человека
public class Solution {

    public static class Person implements Serializable {
        String firstName;
        String lastName;
        transient String fullName;
        final transient String greeting = "Hello, ";
        String country;
        Sex sex;
        transient PrintStream outputStream = System.out;
        transient Logger logger;

        Person(String firstName, String lastName, String country, Sex sex) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.fullName = String.format("%s, %s", lastName, firstName);
            this.country = country;
            this.sex = sex;
            this.logger = Logger.getLogger(String.valueOf(Person.class));
        }
    }

    enum Sex {
        MALE,
        FEMALE
    }

    public static void main(String[] args) {

    }
}
Сериализуй класс Person стандартным способом. При необходимости добавь некоторым полям модификатор transient.
Подсказка: cериализоваться должны только те поля, которые имеют уникальные значения.

Требования:
•	Класс Person должен поддерживать нужный интерфейс.
•	Некоторые поля должны быть отмечены модификатором transient.

*/

public class Solution {

    public static class Person implements Serializable {
        String firstName;
        String lastName;
        transient   String fullName;
        transient   final String greeting;
        String country;
        Sex sex;
        transient PrintStream outputStream;
        transient Logger logger;

        Person(String firstName, String lastName, String country, Sex sex) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.fullName = String.format("%s, %s", lastName, firstName);
            this.greeting = "Hello, ";
            this.country = country;
            this.sex = sex;
            this.outputStream = System.out;
            this.logger = Logger.getLogger(String.valueOf(Person.class));
        }
    }

    enum Sex {
        MALE,
        FEMALE
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        FileOutputStream fileOutput = new FileOutputStream("your.person.ser");
        ObjectOutputStream outputStream = new ObjectOutputStream(fileOutput);

        Person myPerson = new Person("Виктор", "Бакши","Россия",
                Sex.MALE);
        System.out.println(myPerson);
        System.out.println(myPerson.fullName);
        outputStream.writeObject(myPerson);

        fileOutput.close();
        outputStream.close();

        //load
        FileInputStream fiStream = new FileInputStream("your.person.ser");
        ObjectInputStream objectStream = new ObjectInputStream(fiStream);

        Person loadedObjectmyPerson = (Person) objectStream.readObject();

        fiStream.close();
        objectStream.close();

        //Attention!!
        System.out.println(loadedObjectmyPerson);
        System.out.println(loadedObjectmyPerson.firstName);
        System.out.println(loadedObjectmyPerson.lastName);
    }
}
/*
public class Solution {

    public static class Person {
        String firstName;
        String lastName;
        String fullName;
        final String greeting;
        String country;
        Sex sex;
        PrintStream outputStream;
        Logger logger;

        Person(String firstName, String lastName, String country, Sex sex) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.fullName = String.format("%s, %s", lastName, firstName);
            this.greeting = "Hello, ";
            this.country = country;
            this.sex = sex;
            this.outputStream = System.out;
            this.logger = Logger.getLogger(String.valueOf(Person.class));
        }
    }

    enum Sex {
        MALE,
        FEMALE
    }

    public static void main(String[] args) {

    }
}
 */