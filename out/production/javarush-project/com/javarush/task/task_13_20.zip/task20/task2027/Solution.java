package com.javarush.task.task20.task2027;

import java.util.ArrayList;
import java.util.List;

/* 
Кроссворд
1. Дан двумерный массив, который содержит буквы английского алфавита в нижнем регистре.
2. Метод detectAllWords должен найти все слова из words в массиве crossword.
3. Элемент(startX, startY) должен соответствовать первой букве слова, элемент(endX, endY) - последней.
text - это само слово, располагается между начальным и конечным элементами
4. Все слова есть в массиве.
5. Слова могут быть расположены горизонтально, вертикально и по диагонали как в нормальном, так и в обратном порядке.
6. Метод main не участвует в тестировании.

Требования:
•	В классе Solution должен существовать метод detectAllWords.
•	В классе Solution должен существовать статический класс Word.
•	Класс Solution не должен содержать статические поля.
•	Метод detectAllWords должен быть статическим.
•	Метод detectAllWords должен быть публичным.
•	Метод detectAllWords должен возвращать список всех слов в кроссворде (согласно условию задачи).

public class Solution {
    public static void main(String[] args) {
        int[][] crossword = new int[][]{
                {'f', 'd', 'e', 'r', 'l', 'k'},
                {'u', 's', 'a', 'm', 'e', 'o'},
                {'l', 'n', 'g', 'r', 'o', 'v'},
                {'m', 'l', 'p', 'r', 'r', 'h'},
                {'p', 'o', 'e', 'e', 'j', 'j'}
        };
        detectAllWords(crossword, "home", "same");
        /*
Ожидаемый результат
home - (5, 3) - (2, 0)
same - (1, 1) - (4, 1)

    }

public static List<Word> detectAllWords(int[][] crossword, String... words) {

    ArrayList<Word> result = new ArrayList<>();
    int hor = crossword[0].length;
    int ver = crossword.length;

    outer:
    for (String s : words) {
        //по горизонтали
        for (int i = 0; i < ver; i++) {
            StringBuilder sb = new StringBuilder();
            for (int j = 0; j < hor; j++)
                sb.append((char) crossword[i][j]);

            String horLine = sb.toString();
            if (horLine.contains(s)) {
                Word word = new Word(s);
                word.setStartPoint(horLine.indexOf(s), i);
                word.setEndPoint(horLine.indexOf(s) + s.length() - 1, i);

                result.add(word);
                continue outer;
            }
            String horReverse = sb.reverse().toString();
            if (horReverse.contains(s)) {
                Word word = new Word(s);
                word.setStartPoint(hor - horReverse.indexOf(s) - 1, i);
                word.setEndPoint(hor - horReverse.indexOf(s) - s.length(), i);

                result.add(word);
                continue outer;
            }
        }
        //по вертикали
        for (int i = 0; i < hor; i++) {
            StringBuilder sb = new StringBuilder();
            for (int[] aCrossword : crossword)
                sb.append((char) aCrossword[i]);

            String horLine = sb.toString();
            if (horLine.contains(s)) {
                Word word = new Word(s);
                word.setStartPoint(i, horLine.indexOf(s));
                word.setEndPoint(i, horLine.indexOf(s) + s.length() - 1);

                result.add(word);
                continue outer;
            }
            String horReverse = sb.reverse().toString();
            if (horReverse.contains(s)) {
                Word word = new Word(s);
                word.setStartPoint(i, ver - horReverse.indexOf(s) - 1);
                word.setEndPoint(i, ver - s.length() - horReverse.indexOf(s));

                result.add(word);
                continue outer;
            }
        }

        //по диагонали вправо
        for (int i = 0; i < ver; i++) {
            for (int j = 0; j < hor; j++) {
                int iTemp = i;
                int jTemp = j;
                StringBuilder sb = new StringBuilder();
                while (iTemp < ver && jTemp < hor) {
                    sb.append((char) crossword[iTemp][jTemp]);
                    iTemp++;
                    jTemp++;
                }
                String horLine = sb.toString();
                if (horLine.contains(s)) {
                    Word word = new Word(s);
                    word.setStartPoint(j + horLine.indexOf(s), i + horLine.indexOf(s));
                    word.setEndPoint(j + horLine.indexOf(s) + s.length() - 1, i + horLine.indexOf(s) + s.length() - 1);

                    result.add(word);
                    continue outer;
                }
                String horReverse = sb.reverse().toString();
                if (horReverse.contains(s)) {
                    Word word = new Word(s);
                    word.setStartPoint(jTemp - 1 - horReverse.indexOf(s), iTemp - 1 - horReverse.indexOf(s));
                    word.setEndPoint(jTemp - horReverse.indexOf(s) - s.length(), iTemp - horReverse.indexOf(s) - s.length());

                    result.add(word);
                    continue outer;
                }
            }
        }

        //по диагонали влево
        for (int i = 0; i < ver; i++) {
            for (int j = hor - 1; j >= 0; j--) {
                int iTemp = i;
                int jTemp = j;
                StringBuilder sb = new StringBuilder();
                while (iTemp < ver && jTemp >= 0) {
                    sb.append((char) crossword[iTemp][jTemp]);
                    iTemp++;
                    jTemp--;
                }

                String horLine = sb.toString();
                if (horLine.contains(s)) {
                    Word word = new Word(s);
                    word.setStartPoint(j - horLine.indexOf(s), i + horLine.indexOf(s));
                    word.setEndPoint(j - horLine.indexOf(s) - s.length() + 1, i + horLine.indexOf(s) + s.length() - 1);

                    result.add(word);
                    continue outer;
                }
                String horReverse = sb.reverse().toString();
                if (horReverse.contains(s)) {
                    Word word = new Word(s);
                    word.setStartPoint(jTemp + 1 + horReverse.indexOf(s), iTemp - 1 - horReverse.indexOf(s));
                    word.setEndPoint(jTemp + horReverse.indexOf(s) + s.length(), iTemp - horReverse.indexOf(s) - s.length());

                    result.add(word);
                    continue outer;
                }
            }
        }
    }

    System.out.println(result);

    return result;
}

public static class Word {
    private String text;
    private int startX;
    private int startY;
    private int endX;
    private int endY;

    public Word(String text) {
        this.text = text;
    }

    public void setStartPoint(int i, int j) {
        startX = i;
        startY = j;
    }

    public void setEndPoint(int i, int j) {
        endX = i;
        endY = j;
    }

    @Override
    public String toString() {
        return String.format("%s - (%d, %d) - (%d, %d)", text, startX, startY, endX, endY);
    }
}
}

*/

//java написать метод detectAllWords(crossword, "home", "same") для поиска слов в массиве crossword.
//Слова могут быть расположены горизонтально, вертикально и по диагонали как в нормальном, так и в обратном порядке.
public class Solution {
    public static void main(String[] args) {
        int[][] crossword = new int[][]{
                {'f', 'd', 'e', 'r', 'l', 'k'},
                {'u', 's', 'a', 'm', 'e', 'o'},
                {'l', 'n', 'g', 'r', 'o', 'v'},
                {'m', 'l', 'p', 'r', 'r', 'h'},
                {'p', 'o', 'e', 'e', 'j', 'j'}
        };
        detectAllWords(crossword, "home", "same");


        /*
Ожидаемый результат
home - (5, 3) - (2, 0)
same - (1, 1) - (4, 1)
         */
    }

    public static List<Word> detectAllWords(int[][] crossword, String... words) {
        List<Word> result = new ArrayList<>();
        for (String word : words) {
            result.addAll(findWord(crossword, word));
            System.out.println(findWord(crossword, word).toString());
        }
        return result;
    }

    private static List<Word> findWord(int[][] crossword, String word) {
        List<Word> foundWords = new ArrayList<>();
        int rows = crossword.length;
//        System.out.println(crossword.length);
        if (rows == 0) return foundWords;
        int cols = crossword[0].length;
        int wordLength = word.length();
        char firstChar = word.charAt(0);

        // Направления: вверх, вниз, влево, вправо и по диагоналям
        int[][] directions = {
                {-1, 0},  // вверх
                {1, 0},    // вниз
                {0, -1},   // влево
                {0, 1},    // вправо
                {-1, -1},  // вверх-влево
                {-1, 1},   // вверх-вправо
                {1, -1},   // вниз-влево
                {1, 1}     // вниз-вправо
        };

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (crossword[i][j] == firstChar) {
                    for (int[] dir : directions) {
                        int dx = dir[0];
                        int dy = dir[1];
                        int x = i + dx * (wordLength - 1);
                        int y = j + dy * (wordLength - 1);
                        if (x >= 0 && x < rows && y >= 0 && y < cols) {
                            boolean match = true;
                            for (int k = 1; k < wordLength; k++) {
                                int currentX = i + dx * k;
                                int currentY = j + dy * k;
                                if (crossword[currentX][currentY] != word.charAt(k)) {
                                    match = false;
                                    break;
                                }
                            }
                            if (match) {
                                Word foundWord = new Word(word);
                                // Координаты в задании выводятся как (y, x)
                                foundWord.setStartPoint(j, i);
                                foundWord.setEndPoint(y, x);
                                foundWords.add(foundWord);
//                                System.out.println(foundWord.toString());
                            }
                        }
                    }
                }
            }
        }
        return foundWords;
    }

    public static class Word {
        private String text;
        private int startX;
        private int startY;
        private int endX;
        private int endY;

        public Word(String text) {
            this.text = text;
        }

        public void setStartPoint(int i, int j) {
            startX = i;
            startY = j;
        }

        public void setEndPoint(int i, int j) {
            endX = i;
            endY = j;
        }

        @Override
        public String toString() {
            return String.format("%s - (%d, %d) - (%d, %d)", text, startX, startY, endX, endY);
        }
    }
}

/*
//java написать метод detectAllWords(crossword, "home", "same") для поиска слов в массиве crossword.
//Слова могут быть расположены горизонтально, вертикально и по диагонали как в нормальном, так и в обратном порядке.
public class Solution {
    public static void main(String[] args) {
        int[][] crossword = new int[][]{
                {'f', 'd', 'e', 'r', 'l', 'k'},
                {'u', 's', 'a', 'm', 'e', 'o'},
                {'l', 'n', 'g', 'r', 'o', 'v'},
                {'m', 'l', 'p', 'r', 'r', 'h'},
                {'p', 'o', 'e', 'e', 'j', 'j'}
        };
        detectAllWords(crossword, "home", "same");
        /*
Ожидаемый результат
home - (5, 3) - (2, 0)
same - (1, 1) - (4, 1)

    }

        public static List<Word> detectAllWords(int[][] crossword, String... words) {

            return null;
        }

        public static class Word {
            private String text;
            private int startX;
            private int startY;
            private int endX;
            private int endY;

            public Word(String text) {
                this.text = text;
            }

            public void setStartPoint(int i, int j) {
                startX = i;
                startY = j;
            }

            public void setEndPoint(int i, int j) {
                endX = i;
                endY = j;
            }

            @Override
            public String toString() {
                return String.format("%s - (%d, %d) - (%d, %d)", text, startX, startY, endX, endY);
            }
        }
}
 */
