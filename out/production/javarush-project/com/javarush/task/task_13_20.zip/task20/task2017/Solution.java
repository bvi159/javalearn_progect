package com.javarush.task.task20.task2017;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

/* 
Десериализация
public class Solution {
    public A getOriginalObject(ObjectInputStream objectStream) {
        try {
            return (Solution.A) objectStream.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public class A implements Serializable {
    }

    public class B extends A {
        public B() {
            System.out.println("inside B");
        }
    }

    public static void main(String[] args) {

    }
}
На вход подается поток, в который записан сериализованный объект класса A либо класса B.
Десериализуй объект в методе getOriginalObject так, чтобы в случае возникновения исключения было выведено сообщение на экран и возвращен null.
Реализуй интерфейс Serializable где необходимо.

Требования:
•	Класс B должен быть потомком класса A.
•	Класс A должен поддерживать интерфейс Serializable.
•	Класс B не должен явно поддерживать интерфейс Serializable.
•	Метод getOriginalObject должен возвращать объект типа A полученный из потока ObjectInputStream.
•	Метод getOriginalObject должен возвращать null, если при попытке десериализации не был получен объект типа A.
•	Метод getOriginalObject должен возвращать null, если при попытке десериализации возникло исключение.


*/
//java Метод getOriginalObject должен возвращать объект типа A полученный из потока ObjectInputStream.

import java.io.ObjectInputStream;
import java.io.Serializable;

/*
Десериализация
*/

public class Solution {
    public A getOriginalObject(ObjectInputStream objectStream) {
        try {
            return (Solution.A) objectStream.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public class A implements Serializable {
    }

    public class B extends A {
        public B() {
            System.out.println("inside B");
        }
    }

    public static void main(String[] args) {

    }
}
/*
public class Solution {
    public A getOriginalObject(ObjectInputStream objectStream){
//        private static Object deserializeObject(String fileName) {
        try {
//            Object obj = objectStream.readObject(); // Чтение объекта
//            if (obj instanceof A) {               // Проверка типа
//                return (A) obj;                    // Безопасное приведение типа
//            }
//            return (obj instanceof A) ? (A) obj : null;
            return (Solution.A) objectStream.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
//            return null;
        }
        return null;
    }

    public class A implements Serializable {
    }

    public class B extends A {
        public B() {
            System.out.println("inside B");
        }
    }

    public static void main(String[] args) {

    }
}

import java.io.ObjectInputStream;
import java.io.Serializable;

/*
Десериализация


public class Solution {
    public A getOriginalObject(ObjectInputStream objectStream) {
        return null;
    }

    public class A {
    }

    public class B extends A {
        public B() {
            System.out.println("inside B");
        }
    }

    public static void main(String[] args) {

    }
}
*/