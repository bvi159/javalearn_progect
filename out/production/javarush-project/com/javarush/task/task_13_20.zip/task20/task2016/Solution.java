package com.javarush.task.task20.task2016;

import java.io.*;

/* 
Минимум изменений
public class Solution {

    public class A implements Serializable {
        String name = "A";

        public A(String name) {
            this.name += name;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public class B extends A {
        String name = "B";

        public B(String name) {
            super(name);
            this.name += name;
        }
    }

    public class C extends B {
        String name = "C";

        public C(String name) {
            super(name);
            this.name = name;
        }
    }

    public static void main(String[] args) {

    }
}
Используя минимум изменений кода сделайте так, чтобы сериализация класса C стала возможной.

Требования:
•	В классе Solution должен существовать класс A.
•	В классе Solution должен существовать класс B.
•	В классе Solution должен существовать класс C.
•	Класс B должен быть потомком класса A.
•	Класс C должен быть потомком класса B.
•	Класс A должен поддерживать интерфейс Serializable.
•	Класс B не должен явно поддерживать интерфейс Serializable.
•	Класс C не должен явно поддерживать интерфейс Serializable.

*/
//Java Надо написать main для примера сериализации для этой программы:

public class Solution {
    public static class A implements Serializable {
        String name = "A";
        public A() {
        }

        public A(String name) {
            this.name += name;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public static class B extends A {
        String name = "B";

        public B() {
        }

        public B(String name) {
            super(name);
            this.name += name;
        }
    }

    public static class C extends B {
        String name = "C";
        public C() {
        }
        public C(String name) {
            super(name);
            this.name = name;
        }
    }

    public static void main(String[] args) {
        // Создаем объекты для сериализации
        A a = new A("1");
        B b = new B("2");
        C c = new C("3");

        // Сериализуем объекты в файлы
        serializeObject(a, "a.ser");
        serializeObject(b, "b.ser");
        serializeObject(c, "c.ser");

        // Десериализуем объекты из файлов
        A deserializedA = (A) deserializeObject("a.ser");
        B deserializedB = (B) deserializeObject("b.ser");
        C deserializedC = (C) deserializeObject("c.ser");

        // Выводим результаты
        System.out.println("Original A: " + a);
        System.out.println("Deserialized A: " + deserializedA);

        System.out.println("Original B: " + b);
        System.out.println("Deserialized B: " + deserializedB);

        System.out.println("Original C: " + c);
        System.out.println("Deserialized C: " + deserializedC);
    }

    private static void serializeObject(Object obj, String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(obj);
            System.out.println("Object serialized to " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static Object deserializeObject(String fileName) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            Object obj = ois.readObject();
            System.out.println("Object deserialized from " + fileName);
            return obj;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}
/*
тут мои файлы создаются по умолчанию, если просто задать имя файла.
C:\Users\Vic_host.BIG\javarush\3536038\javarush-project\*.*
или отсюда делаем три шага вверх (есть в быстром доступе Ctrl + D в Total.)
C:\Users\Vic_host.BIG\javarush\3536038\javarush-project\src\com\javarush

Файл family.ser создаётся в рабочей директории вашего Java-проекта (обычно это корневая папка проекта или папка, из которой запускается программа).

Где именно создаётся файл?
Если запуск из IDE (IntelliJ IDEA, Eclipse и др.)

Файл появится в корневой папке проекта (там, где лежат src/, pom.xml и т. д.).

Пример пути:

text
C:\Users\ВашеИмя\IdeaProjects\YourProject\family.ser
Если запуск из командной строки

Файл создастся в текущей директории, откуда запускается java Solution.

Пример:

text
C:\Users\ВашеИмя\> java Solution  → файл появится в C:\Users\ВашеИмя\family.ser
Если указан абсолютный путь

java
String filename = "C:\\data\\family.ser";  // Windows
// или
String filename = "/home/user/family.ser"; // Linux/Mac
→ тогда файл сохранится точно по указанному пути.
*/
