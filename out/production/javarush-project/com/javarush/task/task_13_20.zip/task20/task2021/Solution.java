package com.javarush.task.task20.task2021;

import java.io.*;

/* 
Сериализация под запретом
public class Solution implements Serializable {
    public static class SubSolution extends Solution {
        private void writeObject(ObjectOutputStream out) throws IOException {
            throw new NotSerializableException("Не сегодня!");
        }

        private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
            throw new NotSerializableException("Не сегодня!");
        }
    }

    public static void main(String[] args) {

    }
}

Запрети сериализацию класса SubSolution используя NotSerializableException.
Сигнатуры классов менять нельзя.

Требования:
•	Класс Solution должен поддерживать интерфейс Serializable.
•	Класс SubSolution должен быть создан внутри класса Solution.
•	Класс SubSolution должен быть потомком класса Solution.
•	При попытке сериализовать объект типа SubSolution должно возникать исключение NotSerializableException.
•	При попытке десериализовать объект типа SubSolution должно возникать исключение NotSerializableException.
*/

public class Solution implements Serializable {

    public static class SubSolution extends Solution {
        private String firstName;
        private String lastName;

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }
        private void writeObject(ObjectOutputStream outputStream) throws NotSerializableException {
            throw new NotSerializableException("Ни Фига!");
        }
        private void readObject(ObjectInputStream inputStream) throws NotSerializableException {
            throw new NotSerializableException("Ни Фига!");
        }
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        FileOutputStream fileOutput = new FileOutputStream("person_2021.ser");
        ObjectOutputStream outputStream = new ObjectOutputStream(fileOutput);

        SubSolution myPerson = new SubSolution();
        myPerson.setFirstName("Виктор");
        myPerson.setLastName("Бакши");
        System.out.println(myPerson);
        System.out.println(myPerson.firstName);
        System.out.println(myPerson.lastName);

        outputStream.writeObject(myPerson);

        fileOutput.close();
        outputStream.close();

        //load
        FileInputStream fiStream = new FileInputStream("person_2021.ser");
        ObjectInputStream objectStream = new ObjectInputStream(fiStream);

        SubSolution loadedObjectmyPerson = (SubSolution) objectStream.readObject();

        fiStream.close();
        objectStream.close();

        //Attention!!
        System.out.println(loadedObjectmyPerson);
        System.out.println(loadedObjectmyPerson.firstName);
        System.out.println(loadedObjectmyPerson.lastName);
    }
}
