package com.javarush.task.task20.task2003;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/* 
Знакомство с properties
public class Solution {

    public static Map<String, String> runtimeStorage = new HashMap<>();

    public static void save(OutputStream outputStream) throws Exception {
        Properties prop = new Properties();

        for (Map.Entry<String, String> pair : runtimeStorage.entrySet()) {
            prop.setProperty(pair.getKey(), pair.getValue());
        }

        prop.store(outputStream, null);
    }

    public static void load(InputStream inputStream) throws IOException {
        Properties prop = new Properties();
        prop.load(inputStream);

        for (Map.Entry<Object, Object> pair : prop.entrySet()) {
            runtimeStorage.put(pair.getKey().toString(), pair.getValue().toString());
        }
    }

    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
             FileInputStream fos = new FileInputStream(reader.readLine())) {
            load(fos);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println(runtimeStorage);
    }
}


*/

public class Solution {

    public static Map<String, String> runtimeStorage = new HashMap<>();

    public static void save(OutputStream outputStream) throws Exception {
        //напишите тут ваш код
        Properties prop = new Properties();

//        PrintWriter printWriter = new PrintWriter(outputStream);

        if (runtimeStorage.size() > 0) {
            String line;
            String myKey;
            String myValue;
            for (Map.Entry<String, String> entry : runtimeStorage.entrySet()) {
                prop.setProperty(entry.getKey(), entry.getValue());

//                myKey = entry.getKey();
//                myValue = entry.getValue();
//                printWriter.println(myKey + "=" + myValue);
//                System.out.println("Key: " + key + ", Value: " + value);
            }
            prop.store(outputStream, null);


        }
//        printWriter.close();
    }

    public static void load(InputStream inputStream) throws IOException {
        //напишите тут ваш код
        Properties prop = new Properties();
        prop.load(inputStream);

//        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String line;
        String myKey;
        String myValue;
        for (Map.Entry<Object, Object> pair : prop.entrySet()) {
            runtimeStorage.put(pair.getKey().toString(), pair.getValue().toString());
        }

//        while ((line = reader.readLine()) != null) {
////            User user = new User();
////            if (line.matches(".[^#]")) {
//                String[] lineArray = line.split("=");
////            if (lineArray.length < 5) {
////                break;
////            }
//                myKey = lineArray[0];
//                myValue = lineArray[1];
//                runtimeStorage.put(myKey, myValue);
////            }
//        }
//        reader.close();
    }

    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
             FileInputStream fos = new FileInputStream(reader.readLine());
             FileOutputStream outputStream = new FileOutputStream(reader.readLine())) {
            load(fos);
            Properties systemProps = new Properties();
            systemProps.putAll(System.getProperties());
            systemProps.store(outputStream, "Something properties - author Victor Bakshee");
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println(runtimeStorage);


//        System.out.println(systemProps);

    }
}

/*
D:\ASProject\Java_learning\25_02_2025_2003.properties
D:\ASProject\Java_learning\25_02_2025_2003_System.properties


    for (User current : this.users) {
                StringBuilder sb = new StringBuilder();
                sb.append(current.getFirstName());
                sb.append("/");
                sb.append(current.getLastName());
                sb.append("/");
                sb.append(current.getBirthDate().getTime());
                sb.append("/");
                sb.append(current.isMale());
                sb.append("/");
                sb.append(current.getCountry());
                printWriter.println(sb.toString());
            }

 user.setFirstName(lineArray[0]);
            user.setLastName(lineArray[1]);
            user.setBirthDate(new Date(Long.parseLong(lineArray[2])));
        user.setMale(Boolean.parseBoolean(lineArray[3]));
        switch (lineArray[4]) {
        case "UKRAINE":
        user.setCountry(User.Country.UKRAINE);
                    break;
                            case "RUSSIA":
                            user.setCountry(User.Country.RUSSIA);
                    break;
default:
        user.setCountry(User.Country.OTHER);
                    break;
                            }
                            this.users.add(user);

 */