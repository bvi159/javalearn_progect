package com.javarush.task.task20.task2004;

import java.io.*;

/* 
Читаем и пишем в файл статики
public class Solution {
    public static void main(String[] args) {
        //you can find your_file_name.tmp in your TMP directory or adjust outputStream/inputStream according to your file's actual location
        //вы можете найти your_file_name.tmp в папке TMP или исправьте outputStream/inputStream в соответствии с путем к вашему реальному файлу
        try {

            File yourFile = File.createTempFile("your_file_name", null);
            OutputStream outputStream = new FileOutputStream(yourFile);
            InputStream inputStream = new FileInputStream(yourFile);

            ClassWithStatic classWithStatic = new ClassWithStatic();
            classWithStatic.i = 3;
            classWithStatic.j = 4;
            classWithStatic.save(outputStream);
            outputStream.flush();

            ClassWithStatic loadedObject = new ClassWithStatic();
            ClassWithStatic.staticString = "something";
            loadedObject.i = 6;
            loadedObject.j = 7;

            loadedObject.load(inputStream);
            //here check that the classWithStatic object is equal to the loadedObject object - проверьте тут, что classWithStatic и loadedObject равны
            System.out.println(loadedObject.equals(classWithStatic));

            outputStream.close();
            inputStream.close();

        } catch (IOException e) {
            //e.printStackTrace();
            System.out.println("Oops, something is wrong with my file");
        } catch (Exception e) {
            //e.printStackTrace();
            System.out.println("Oops, something is wrong with the save/load method");
        }
    }

    public static class ClassWithStatic {
        public static String staticString = "This is a static test string";
        public int i;
        public int j;

        public void save(OutputStream outputStream) throws Exception {
            //implement this method - реализуйте этот метод
            PrintWriter printWriter = new PrintWriter(outputStream);
            printWriter.println(staticString);
            printWriter.println(this.i);
            printWriter.println(this.j);
            printWriter.close();
        }

        public void load(InputStream inputStream) throws Exception {
            //implement this method - реализуйте этот метод
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            staticString = bufferedReader.readLine();
            this.i = Integer.parseInt(bufferedReader.readLine());
            this.j = Integer.parseInt(bufferedReader.readLine());
            bufferedReader.close();
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            ClassWithStatic that = (ClassWithStatic) o;

            if (i != that.i) return false;
            return j == that.j;

        }

        @Override
        public int hashCode() {
            int result = i;
            result = 31 * result + j;
            return result;
        }
    }
}

*/

public class Solution {
    public static void main(String[] args) {
        //you can find your_file_name.tmp in your TMP directory or adjust outputStream/inputStream according to your file's actual location
        //вы можете найти your_file_name.tmp в папке TMP или исправьте outputStream/inputStream в соответствии с путем к вашему реальному файлу
        try {
//            File yourFile = File.createTempFile("your_file_name", null);
            File directory = new File("D:\\ASProject\\Java_learning");
            File yourFile = File.createTempFile("your_file_name", ".tmp", directory);
            OutputStream outputStream = new FileOutputStream(yourFile);
            InputStream inputStream = new FileInputStream(yourFile);

            ClassWithStatic classWithStatic = new ClassWithStatic();
            classWithStatic.i = 3;
            classWithStatic.j = 4;
            classWithStatic.save(outputStream);
            outputStream.flush();

            ClassWithStatic loadedObject = new ClassWithStatic();
            loadedObject.staticString = "something";
            loadedObject.i = 6;
            loadedObject.j = 7;

            loadedObject.load(inputStream);
            //here check that the classWithStatic object is equal to the loadedObject object
            // - проверьте тут, что classWithStatic и loadedObject равны
            System.out.println(classWithStatic.equals(loadedObject));


            outputStream.close();
            inputStream.close();

        } catch (IOException e) {
            //e.printStackTrace();
            System.out.println("Oops, something is wrong with my file");
        } catch (Exception e) {
            //e.printStackTrace();
            System.out.println("Oops, something is wrong with the save/load method");
        }
    }


    public static class ClassWithStatic {
        public static String staticString = "This is a static test string";
        public int i;
        public int j;

//        public void save(OutputStream outputStream) throws Exception {
//            //implement this method - реализуйте этот метод
//            PrintWriter printWriter = new PrintWriter(outputStream);
//            printWriter.println(staticString);
//            printWriter.println(this.i);
//            printWriter.println(this.j);
//            printWriter.close();
//        }
//
//        public void load(InputStream inputStream) throws Exception {
//            //implement this method - реализуйте этот метод
//            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
//            staticString = bufferedReader.readLine();
//            this.i = Integer.parseInt(bufferedReader.readLine());
//            this.j = Integer.parseInt(bufferedReader.readLine());
//            bufferedReader.close();
//        }
public void save(OutputStream outputStream) throws Exception {
    //implement this method - реализуйте этот метод
    PrintWriter myPrint = new PrintWriter(outputStream);
    myPrint.println(staticString + "/" + i + "/" + j);
    myPrint.close();

}

        public void load(InputStream inputStream) throws Exception {
            //implement this method - реализуйте этот метод
//            BufferedReader reader = new BufferedReader(new FileReader(inputStream));
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String myStr = reader.readLine();
            System.out.println(myStr);
            String[] myWords = myStr.split("/");
//            ClassWithStatic newO = new ClassWithStatic();
            System.out.println(myWords[0]);
            System.out.println(myWords[1]);
            System.out.println(myWords[2]);
            this.staticString = myWords[0];
            this.i = Integer.parseInt(myWords[1]);
            this.j = Integer.parseInt(myWords[2]);
            reader.close();
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            ClassWithStatic that = (ClassWithStatic) o;

            if (i != that.i) return false;
            return j == that.j;

        }

        @Override
        public int hashCode() {
            int result = i;
            result = 31 * result + j;
            return result;
        }
    }
}
/*
public void save(OutputStream outputStream) throws Exception {
            //implement this method - реализуйте этот метод
            PrintWriter myPrint = new PrintWriter(outputStream);
//            String line;
                           myPrint.println(staticString + "/" + i + "/" + j);
//            }
              myPrint.close();

        }

        public void load(InputStream inputStream) throws Exception {
            //implement this method - реализуйте этот метод
//            BufferedReader reader = new BufferedReader(new FileReader(inputStream));
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String myStr = reader.readLine();
            String[] myWords = myStr.split("/");
            ClassWithStatic newO = new ClassWithStatic();
            this.staticString = myWords[0];
            this.i = Integer.parseInt(myWords[1]);
            this.j = Integer.parseInt(myWords[2]);
            reader.close()
        }
 */