package com.javarush.task.task20.task2024;

import java.io.*;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/* 
Знакомство с графами
Прочитать в дополнительных материалах о сериализации графов.
Дан ориентированный плоский граф Solution, содержащий циклы и петли.

Пример, http://edu.nstu.ru/courses/saod/images/graph1.gif

Сериализовать Solution.
Все данные должны сохранить порядок следования.

Требования:
•	В классе Solution должно существовать поле edges.
•	В классе Solution должно существовать поле node.
•	Тип поля node должен быть int.
•	Класс Solution должен поддерживать интерфейс Serializable.

*/

public class Solution implements Serializable {
    private static final long serialVersionUID = 1L; // Уникальный идентификатор версии
    int node;
    List<Solution> edges = new LinkedList<>();


    // Конструкторы, геттеры и сеттеры (по желанию)
    public Solution(int node) {
        this.node = node;
    }

    // Метод для добавления ребра
    public void addEdge(Solution edge) {
        edges.add(edge);
    }

    // Геттеры и сеттеры
    public int getNode() {
        return node;
    }

    public void setNode(int node) {
        this.node = node;
    }

    public List<Solution> getEdges() {
        return edges;
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("ser_2024.ser"));
        ObjectInputStream inStream = new ObjectInputStream(new FileInputStream("ser_2024.ser"));

        Solution root = new Solution(1);
        Solution child1 = new Solution(2);
        Solution child2 = new Solution(3);

        root.addEdge(child1);
        root.addEdge(child2);

////        а если ещё есть рёбра
//        child1.addEdge(child2);
//        child2.addEdge(root);
////        как их серарилизовать и десериализовать

        // Сериализация
            out.writeObject(root);
//            out.writeObject(child1);
//            out.writeObject(child2);
            System.out.println("Объект успешно сериализован.");

// Десериализация
//        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("solution.ser"))) {
            Solution deserialized = (Solution) inStream.readObject();
            System.out.println("Объект успешно десериализован.");
            System.out.println("Узел: " + deserialized.getNode());
            System.out.println("Рёбер: " + deserialized.getEdges().size());
//            System.out.println("Ребра: " + deserialized.getEdges().toString());
//        } catch (IOException | ClassNotFoundException e) {
//            e.printStackTrace();
//        }

    }
}


/*
java Сериализовать Solution. Все данные должны сохранить порядок следования.:
public class Solution implements Serializable {
    int node;
    List<Solution> edges = new LinkedList<>();

    public static void main(String[] args) {

    }
}

 */