package com.javarush.task.task20.task2014;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/* 
Serializable Solution

public class Solution implements Serializable {
    public static void main(String[] args) {
        System.out.println(new Solution(4));
    }

    private transient final String pattern = "dd MMMM yyyy, EEEE";
    private transient Date currentDate;
    private transient int temperature;
    String string;

    public Solution(int temperature) {
        this.currentDate = new Date();
        this.temperature = temperature;

        string = "Today is %s, and the current temperature is %s C";
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        this.string = String.format(string, format.format(currentDate), temperature);
    }

    @Override
    public String toString() {
        return this.string;
    }

*/
//java в чём ошибка? :
public class Solution implements Externalizable {
    public static void main(String[] args) {
        System.out.println(new Solution(4));
        // Сериализация
        String filename = "temperature.ser";
        Solution savedObject = new Solution(28);
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            savedObject.writeExternal(out);
            System.out.println("Объект успешно сериализован");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Десериализация
        Solution loadObject = new Solution(); // используем конструктор без параметров
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            loadObject.readExternal(in);
            System.out.println("Объект успешно десериализован");
            System.out.println(loadObject);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
    //------------------------------------------------

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeInt(temperature); // записываем как int
        out.writeObject(string); // сохраняем также строку для корректного toString()
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        temperature = in.readInt();
        string = (String) in.readObject();
    }
    //-----------------------------------------------

    transient private final String pattern = "dd MMMM yyyy, EEEE";
    transient private Date currentDate;
    transient private int temperature;

    String string;
    // Добавляем конструктор без параметров
    public Solution() {
    }
    public Solution(int temperature) {
        this.currentDate = new Date();
        this.temperature = temperature;

        string = "Today is %s, and the current temperature is %s C";
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        this.string = String.format(string, format.format(currentDate), temperature);
    }

    @Override
    public String toString() {
        return this.string;
    }
}
/*

C:\Users\Vic_host.BIG\javarush\3536038\javarush-project


Файл family.ser создаётся в рабочей директории вашего Java-проекта (обычно это корневая папка проекта или папка, из которой запускается программа).

Где именно создаётся файл?
Если запуск из IDE (IntelliJ IDEA, Eclipse и др.)

Файл появится в корневой папке проекта (там, где лежат src/, pom.xml и т. д.).

Пример пути:

text
C:\Users\ВашеИмя\IdeaProjects\YourProject\family.ser
Если запуск из командной строки

Файл создастся в текущей директории, откуда запускается java Solution.

Пример:

text
C:\Users\ВашеИмя\> java Solution  → файл появится в C:\Users\ВашеИмя\family.ser
Если указан абсолютный путь

java
String filename = "C:\\data\\family.ser";  // Windows
// или
String filename = "/home/user/family.ser"; // Linux/Mac
→ тогда файл сохранится точно по указанному пути.

Как найти файл?
 */


/*
public class Solution {
    public static void main(String[] args) {
        System.out.println(new Solution(4));
    }

    private final String pattern = "dd MMMM yyyy, EEEE";
    private Date currentDate;
    private int temperature;

    String string;

    public Solution(int temperature) {
        this.currentDate = new Date();
        this.temperature = temperature;

        string = "Today is %s, and the current temperature is %s C";
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        this.string = String.format(string, format.format(currentDate), temperature);
    }

    @Override
    public String toString() {
        return this.string;
    }
}

что означает this() в данном контексте:
public Person(String firstName, String lastName, int age) {
    this();
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
}

 */