package com.javarush.task.task20.task2013;

import java.io.*;
import java.util.*;

/* 
Externalizable Person

public class Solution {
    public static class Person implements Externalizable {
        private String firstName;
        private String lastName;
        private int age;
        private Person mother;
        private Person father;
        private List<Person> children;

        public Person(String firstName, String lastName, int age) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.age = age;
        }

        public void setMother(Person mother) {
            this.mother = mother;
        }

        public void setFather(Person father) {
            this.father = father;
        }

        public void setChildren(List<Person> children) {
            this.children = children;
        }

        @Override
        public void writeExternal(ObjectOutput out) throws IOException {
            out.writeObject(firstName);
            out.writeObject(mother);
            out.writeObject(lastName);
            out.writeObject(father);
            out.writeObject(age);
            out.writeObject(children);
        }

        @Override
        public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
            firstName = (String) in.readObject();
            mother = (Person) in.readObject();
            lastName = (String) in.readObject();
            father = (Person) in.readObject();
            age = (int) in.readObject();
            children = (List<Person>) in.readObject();
        }

        public Person() {
        }
    }

    public static void main(String[] args) {

    }
}


*/

public class Solution {
    public static class Person implements Externalizable {
        private String firstName;
        private String lastName;
        private int age;
        private Person mother;
        private Person father;
        private List<Person> children;

        public Person(){
//            this.children = new ArrayList<Person>();
            this.children = new ArrayList<>();
        }
        public Person(String firstName, String lastName, int age) {
            this();
            this.firstName = firstName;
            this.lastName = lastName;
            this.age = age;
//            this.mother = new Person();
//            this.father = new Person();
//            this.children = new ArrayList<Person>();
        }

        public void setMother(Person mother) {
            this.mother = mother;
        }

        public void setFather(Person father) {
            this.father = father;
        }

        public void setChildren(List<Person> children) {
            this.children = children;
        }

        @Override
        public void writeExternal(ObjectOutput out) throws IOException {
//            out.writeChars(firstName);
//            out.writeChars(lastName);
            out.writeObject(firstName);
            out.writeObject(lastName);
            out.writeInt(age);
            out.writeObject(mother);
            out.writeObject(father);
            out.writeObject(children);
        }

        @Override
        public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
//            firstName = in.readLine();
//            lastName = in.readLine();
            firstName = (String) in.readObject();
            lastName = (String) in.readObject();
            age = in.readInt();
            mother = (Person) in.readObject();
            father = (Person) in.readObject();
            children = (List<Person>) in.readObject();
        }
        @Override
        public String toString() {
            return "Person{" +
                    "firstName='" + firstName + '\'' +
                    ", lastName='" + lastName + '\'' +
                    ", age=" + age +
                    ", mother=" + (mother != null ? mother.firstName + " " + mother.lastName : "null") +
                    ", father=" + (father != null ? father.firstName + " " + father.lastName : "null") +
                    ", children=" + children.size() +
                    '}';
        }

    }

    public static void main(String[] args) {
        // Создаем семью
        Person john = new Person("John", "Doe", 45);
        Person jane = new Person("Jane", "Doe", 42);
        Person mike = new Person("Mike", "Doe", 15);

        // Устанавливаем родственные связи
        mike.setFather(john);
        mike.setMother(jane);

        List<Person> children = new ArrayList<>();
        children.add(mike);
        john.setChildren(children);
        jane.setChildren(children);

        // Сериализация
        String filename = "family.ser";
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            john.writeExternal(out);
            System.out.println("Объект успешно сериализован");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Десериализация
        Person deserializedJohn = new Person();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            deserializedJohn.readExternal(in);
            System.out.println("Объект успешно десериализован");
            System.out.println(deserializedJohn);
            if (deserializedJohn.children != null && !deserializedJohn.children.isEmpty()) {
                System.out.println("Первый ребенок: " + deserializedJohn.children.get(0));
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}
/*
public class Solution {
    public static class Person {
        private String firstName;
        private String lastName;
        private int age;
        private Person mother;
        private Person father;
        private List<Person> children;

       public Person(String firstName, String lastName, int age) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.age = age;
        }

        public void setMother(Person mother) {
            this.mother = mother;
        }

        public void setFather(Person father) {
            this.father = father;
        }

        public void setChildren(List<Person> children) {
            this.children = children;
        }

        @Override
        public void writeExternal(ObjectOutput out) throws IOException {
            out.writeObject(mother);
            out.writeObject(father);
            out.writeChars(firstName);
            out.writeChars(lastName);
            out.writeInt(age);
            out.writeObject(children);
        }

        @Override
        public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
            firstName = in.readLine();
            lastName = in.readLine();
            father = (Person) in.readObject();
            mother = (Person) in.readObject();
            age = in.readInt();
            children = (List) in.readObject();
        }
    }

    public static void main(String[] args) {

    }
}
 */