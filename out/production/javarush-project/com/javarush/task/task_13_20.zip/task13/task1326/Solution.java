package com.javarush.task.task13.task1326;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

/* 
Сортировка четных чисел из файла
public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String sourceFileName = reader.readLine();
        Scanner scanner = new Scanner(new FileInputStream(sourceFileName));

        List<Integer> data = new ArrayList<>();
        while (scanner.hasNext()) {
            int value = scanner.nextInt();
            if (value % 2 == 0) data.add(value);
        }

        Collections.sort(data);
        for (Integer value : data) {
            System.out.println(value);
        }

        scanner.close();
    }
}
В этой задаче тебе нужно:
Ввести имя файла с консоли.
Прочитать из него набор чисел.
Вывести в консоли только четные, отсортированные по возрастанию.
Пример ввода:
5
8
-2
11
3
-5
2
10

Пример вывода:
-2
2
8
10

Требования:
•	Программа должна считывать данные с консоли.
•	Программа должна создавать FileInputStream для введенной с консоли строки.
•	Программа должна выводить данные на экран.
•	Программа должна вывести на экран все четные числа, считанные из файла, отсортированные по возрастанию.
•	Программа должна закрывать поток чтения из файла — FileInputStream.

*/

public class Solution {
    public static void main(String[] args) {
        // напишите тут ваш код
        Scanner console = new Scanner(System.in);
        String fileName = console.nextLine();
        try (FileInputStream fis = new FileInputStream(fileName);
             InputStreamReader isr = new InputStreamReader(fis);
             BufferedReader br = new BufferedReader(isr)) {
            String  line;
            List<Integer> myFigures = new ArrayList<>();
            // Создаём лист Integer из файла
            while ((line = br.readLine()) != null) {
               myFigures.add(Integer.parseInt(line));
            }
            console.close();
            // Сортируем по возрастанию
            Collections.sort(myFigures);
            //Удаляем нечётные элементы с использованием Stream API
            List<Integer> evenNumbers = myFigures
                    .stream().filter(n -> n % 2 == 0)
                    .collect(Collectors.toList());
            for(Integer fig : evenNumbers) {
                System.out.println(fig);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
            /*
Один из наиболее простых и распространенных — использование встроенного метода Collections.sort().
Это статический метод, который принимает список в качестве аргумента и сортирует его в порядке возрастания:
1 Collections.sort(myList);
Однако, если требуется сортировка в порядке убывания, придется немного модифицировать вызов
этого метода, добавив в аргументы объект Comparator, который определит порядок сортировки:
1 Collections.sort(myList, Collections.reverseOrder());
Теперь список myList отсортирован в порядке убывания:
            */



/*
try (FileOutputStream fos = new FileOutputStream(filePath);
             OutputStreamWriter osr = new OutputStreamWriter(fos);
             BufferedWriter bw = new BufferedWriter(osr)) {
            String line;

            while(true) {
                line = console.nextLine();
                bw.write(line);
                if (line.equals("exit")) {
                    break;
                }
                bw.newLine();
            }

        } catch(IOException e){
            e.printStackTrace();
        }


ublic class Solution {
    public static void main(String[] args) {
        // напишите тут ваш код

    }
}

*/
