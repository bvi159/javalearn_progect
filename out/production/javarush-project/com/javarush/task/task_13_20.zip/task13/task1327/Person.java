package com.javarush.task.task13.task1327;

public class Person implements RepkaItem {
    private String name;
    private String namePadezh;

    public Person(String name, String namePadezh) {
        this.name = name;
        this.namePadezh = namePadezh;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNamePadezh() {
        return namePadezh;
    }

    public void setNamePadezh(String namePadezh) {
        this.namePadezh = namePadezh;
    }

    public void pull(Person first) {
//        Person second;
//        second = Person.this;
//        System.out.println(second.getName() + " за " + first.getNamePadezh());
        System.out.println(name + " за " + first.getNamePadezh());
    }
}
//    public interface RepkaItem{
//
//    }
//    public String pull(Person person){
//        return
//    }

