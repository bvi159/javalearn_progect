package com.javarush.task.task13.task1315;

/* 
Том, Джерри и Спайк
*/

public class Solution {
    public static void main(String[] args) {
        Dog myDog = new Dog();
        Mouse myMouse = new Mouse();
        Cat myCat = new Cat();
        System.out.println("Dog says:");
        myDog.move();
        myDog.eat();
        System.out.println("Mouse says:");
        myMouse.move();
        myMouse.beEaten();
        System.out.println("Cat says:");
        myCat.move();
        myCat.eat();
        myCat.beEaten();
    }

    //может двигаться
    public interface Movable {
        void move();
    }

    //может быть съеден
    public interface Edible {
        void beEaten();
    }

    //может кого-нибудь съесть
    public interface Eat {
        void eat();
    }
    public static class Dog implements Movable, Eat {
        public void move () {
            System.out.println("I can run and catch you!!!");
        }
        public void eat(){
            System.out.println("I can eat you all with your guts");
        }

    }
    public static class Mouse implements Movable, Edible {
        public void move () {
            System.out.println("I can run out from you!!!");
        }
        public void beEaten(){
            System.out.println("Don't eat me I'm good!!!");
        }

    }
    public static class Cat implements Movable, Eat, Edible {
        public void move () {
            System.out.println("I can run and catch you!!!");
        }
        public void eat(){
            System.out.println("I can eat mouse");
        }
        public void beEaten(){
            System.out.println("Don't eat me plz, I'm not very clean!!!");
        }

    }

}