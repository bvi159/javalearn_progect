package com.javarush.task.task16.task1621;

/* 
Thread.currentThread - всегда возвращает текущую нить
*/

public class Solution {
    static int count = 5;

    public static void main(String[] args) {
        ThreadNamePrinter tnp = new ThreadNamePrinter();
        tnp.start();
        for (int i = 0; i < count; i++) {
            try {
                tnp.printMsg();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static class ThreadNamePrinter extends Thread {
        public void run() {
            for (int i = 0; i < count; i++) {
                try {
                    printMsg();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }

        public void printMsg() throws InterruptedException {
            Thread t = null;//присвой переменной t текущую нить
            t = Thread.currentThread();
            String name = t.getName();
            System.out.println("Name=" + name);
            //add sleep here - добавь sleep ту
            t.sleep(1);

        }
    }
}
