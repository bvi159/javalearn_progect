package com.javarush.task.task16.task1620;

public class Account {
    private long balance;
    public Account() {
        this(0L);
    }
    public Account(long balance){
        this.balance = balance;
    }
    public long getBalance(){
        return balance;
    }
    public void deposit(long amount) throws IllegalAccessException {
        checkAmontNonNegative(amount);
        synchronized(this) {
            balance += amount;
        }
    }

    public void withdraw(long amount) throws IllegalAccessException {
        checkAmontNonNegative(amount);

        synchronized(this) {
            if (balance < amount) {
                throw new IllegalAccessException("not enough moneq!");
            }
            balance -= amount;
        }
    }

    private static void checkAmontNonNegative(long amount) throws IllegalAccessException {
        if(amount < 0){
            throw new IllegalAccessException("negative amount");
        }
    }
}
