package com.javarush.task.task16.task1618;

/* 
Снова interrupt
public class Solution {
    public static void main(String[] args) throws InterruptedException {
        //Add your code here - добавь код тут
        TestThread t = new TestThread();
        t.start();
        t.interrupt();
    }

    //Add your code below - добавь код ниже
    public static class TestThread extends Thread {
        public void run() {
        }
    }
}

Создай нить TestThread.
В методе main создай экземпляр нити, запусти, а потом прерви ее используя метод interrupt().

Требования:
•	Класс TestThread должен быть унаследован от Thread.
•	Класс TestThread должен иметь public void метод run.
•	Метод main должен создавать объект типа TestThread.
•	Метод main должен вызывать метод start у объекта типа TestThread.
•	Метод main должен вызывать метод interrupt у объекта типа TestThread.

*/


public class Solution {
    public static void main(String[] args) throws InterruptedException {
        //Add your code here - добавь код тут
        Thread TestThread = new TestThread();
        TestThread.start();
        Thread.sleep(2000);
        TestThread.interrupt();
    }

    //Add your code below - добавь код ниже
    public static class TestThread extends Thread {
        @Override
        public void run() {
            try {
            while(true) {
                Thread.sleep(100);
                System.out.println(Thread.currentThread().getName());
                System.out.println(Thread.currentThread().getState());
            }
            } catch (InterruptedException e) {
                System.out.print(" Прервано!");
            }
        }
    }
}