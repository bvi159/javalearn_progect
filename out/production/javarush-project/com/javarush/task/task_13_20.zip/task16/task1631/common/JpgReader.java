package com.javarush.task.task16.task1631.common;

public class JpgReader implements ImageReader{
    public void jpgPrint(){
        System.out.println("I'm JPG_READER");
    }

}
