package com.javarush.task.task16.task1631.common;

public class PngReader implements ImageReader{
    public void jpgPrint(){
        System.out.println("I'm PNG_READER");
    }
}
