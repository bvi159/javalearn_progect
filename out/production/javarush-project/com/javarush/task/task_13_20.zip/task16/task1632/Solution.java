package com.javarush.task.task16.task1632;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/* 
Клубок
*/
public class Solution {
    public static List<Thread> threads = new ArrayList<>(5);

    static {
        threads.add(new Thread1());
        threads.add(new Thread2());
        threads.add(new Thread3());
        threads.add(new Thread4());
        threads.add(new Thread5());
    }

    public static void main(String[] args) {
    }

    public static class Thread1 extends Thread {
        public void run() {
            while (true) {
            }
        }
    }

    public static class Thread2 extends Thread {
        public void run() {
            try {
                throw new InterruptedException();
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }

    public static class Thread3 extends Thread {
        public void run() {
            while (true) {
                System.out.println("Ура");
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static class Thread4 extends Thread implements Message {
        public void run() {
            while (!isInterrupted()) {
            }
        }

        public void showWarning() {
            this.interrupt();
        }
    }

    public static class Thread5 extends Thread {
        public void run() {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            int sum = 0;
            while (true) {
                try {
                    String str = reader.readLine();
                    if (str.equals("N"))
                        break;
                    sum += Integer.parseInt(str);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            System.out.print(sum);
        }
    }
}

//public class Solution {
/*    public static List<Thread> threads = new ArrayList<>(5);
//    public static volatile BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) throws InterruptedException {
        Thread1 myThr1 = new Thread1();
        myThr1.start();
        Thread2 myThr2 = new Thread2();
        myThr2.start();
        Thread3 myThr3 = new Thread3();
        myThr3.start();
        Thread4 myThr4 = new Thread4();
        myThr4.start();
        Thread5 myThr5 = new Thread5();
        myThr5.start();

    }

    public static class Thread1 extends Thread {
        @Override
        public void run() {
            while (true) {

            }
        }
    }

    public static class Thread2 extends Thread {
        @Override
        public void run() {
            if (this.isInterrupted()) {
                System.out.println("InterruptedExeption");
            }
        }
    }

    public static class Thread3 extends Thread {
        @Override
        public void run() {
            while (true) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("Ура");
            }
        }
    }


    public static class Thread4 extends Thread implements Message {
        @Override
        public void showWarning() {
            System.out.println("Потомок класса Thread4 остановлен!");
            this.interrupt();
        }
//    public void run() {
//        showWarning();
//    }
    }

    public static class Thread5 extends Thread {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        public void run() {
            Integer mySumm = 0;
            int myfig = 0;
            String inputString = "";
            while (!inputString.equals("N")) {
                try {
                    inputString = reader.readLine();
                    if (!inputString.equals("N")) {
                        mySumm += Integer.parseInt(inputString);
                    }  else break; //throw new NumberFormatException("Да ведь это не число!!!");
                } catch (IOException e) {
                    e.printStackTrace();
//                throw new RuntimeException(e);
                }
            }
            try {
                reader.close();
            } catch (IOException e) {
//                throw new RuntimeException(e);
                throw new NumberFormatException("Да ведь это не число!!!");
            }
            System.out.println(mySumm);
        }
    }

}
*/

/*
 public static class Thread1 extends Thread {
            @Override
            public void run() {
                while (true) {

                }
            }
        }

        public static class Thread2 extends Thread {
            @Override
            public void run() {
                if (this.isInterrupted()) {
                    System.out.println("InterruptedExeption");
                }
            }
        }

        public static class Thread3 extends Thread {
            @Override
            public void run() {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("Ура");
            }
        }


    public static class Thread4 extends Thread implements Message {
        @Override
        public void showWarning() {
            System.out.println("Потомок класса Thread4 остановлен!");
            this.interrupt();
        }
//    public void run() {
//        showWarning();
//    }
    }

    public static class Thread5 extends Thread {
        private BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Integer mySumm = 0;
        int myfig = 0;
        String inputString;
        if(!inputString.equals("N"))

        {
            mySumm += Integer.parseInt(inputString);
//                    System.out.println(mySumm);
        } // else throw new NumberFormatException("Да ведь это не число!!!");

            System.out.println(mySumm);


        public void run() {
        }
    }
    Thread myThr1 = new Thread();
        threads.add(myThr1);                // = threads.add(new Thread("myThr1"));

}
//            for (int i = 0; i < 5; i++) {
//                threads.add(new Thread("Thread" + i));
//            }


//            Thread myThr2 = threads.get(1);
//            Thread myThr3 = threads.get(2);
//            Thread myThr4 = threads.get(3);
//            Thread myThr5 = threads.get(4);
//            Thread myThr6 = new Thread() im

    }


public static void main(String[] args) {
    Thread5 myThr5 = new Thread5();
    myThr5.start();
    Thread1 myThr1 = new Thread1();
    myThr1.start();
    Thread2 myThr2 = new Thread2();
    myThr1.start();
//        myThr2.start();
//        if(myThr2.isInterrupted()){
//            System.out.println("InterruptedException");
//        }
//        myThr3.start();
//        try {
//            myThr3.sleep(500);
//            System.out.println("Ура");
//        } catch (InterruptedException e) {
//            throw new RuntimeException(e);
//        }
//        myThr4.start();

}
 */