package com.javarush.task.task16.task1620_a.task1620;

/*
Один для всех, все - для одного
*/
public class Solution {

    public static void main(String[] args) throws Exception {
//        for (int i = 0; i < 10; i++) {
////            new Thread(new HelloRunnable()).start();
//            new Thread(() -> System.out.println("Hello from " + Thread.currentThread().getName())).start();
//        }
//        System.out.println("Hello from main thread");
        Thread worker = new WorkerThread();
        worker.setDaemon(true);
        Thread sleeper = new SleepThread();
        sleeper.setDaemon(true);

        System.out.println("Starting thereads");
        worker.start();
        sleeper.start();

        Thread.sleep(100L);

        System.out.println("Interrupting threads");
        worker.interrupt();
        sleeper.interrupt();

        System.out.println("Joining threads");
        worker.join();
        sleeper.join();

        System.out.println("All done!");

    }

    private static class HelloRunnable implements Runnable {
        @Override
        public void run() {
            System.out.println("Hello from " + Thread.currentThread().getName());
        }
    }

    private static class WorkerThread extends Thread {
        long sum = 0;
        @Override
        public void run(){
            for (int i = 0; i < 1_000_000_000; i++) {
                sum += i;
                if(i%100 ==0 && isInterrupted()){
                    System.out.println("Loop interrupted at i = " + i);
                    break;
                }
            }
        }
    }

    private static class SleepThread extends Thread {
        @Override
        public void run() {
            try {
                Thread.sleep(10000L);
            } catch (InterruptedException e) {
                System.out.println("Sleep interrupted");;
            }
        }
    }
}

/*
public class Solution {

    public static void main(String[] args){
        for (int i = 0; i < 10; i++) {
            new HelloThread().start();
        }
        System.out.println("Hello from main thread");
    }
    private static class HelloThread extends Thread{
        @Override
        public void run() {
            System.out.println("Hello from " + getName());
        }
    }
}
*/


/*
public class Solution {
    public static byte threadCount = 3;
    static List<Thread> threads = new ArrayList<Thread>(threadCount);

    public static void main(String[] args) throws InterruptedException {
        initThreadsAndStart();
        Thread.sleep(3000);
        ourInterruptMethod();
    }

    public static void ourInterruptMethod() {
        //add your code here - добавь код тут
        for(Thread myThred : threads){
            myThred.interrupt();
        }

    }

    private static void initThreadsAndStart() {
        Water water = new Water("water");
        for (int i = 0; i < threadCount; i++) {
            threads.add(new Thread(water, "#" + i));
        }

        for (int i = 0; i < threadCount; i++) {
            threads.get(i).start();
        }
    }

    public static class Water implements Runnable {
        private String sharedResource;

        public Water(String sharedResource) {
            this.sharedResource = sharedResource;
        }

        public void run() {
            //fix 2 variables - исправь 2 переменных
            boolean isCurrentThreadInterrupted = false;
            String threadName = "";
            threadName = Thread.currentThread().getName();

            try {
                while (!isCurrentThreadInterrupted) {
                    System.out.println("Объект " + sharedResource + ", нить " + threadName);
                    Thread.sleep(1000);
                    if(Thread.currentThread().isInterrupted()){
                        isCurrentThreadInterrupted = true;
                    }
                }
            } catch (InterruptedException e) {
            }
        }
    }
}
*/