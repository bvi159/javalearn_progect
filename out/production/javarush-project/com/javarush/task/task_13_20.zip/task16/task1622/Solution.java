package com.javarush.task.task16.task1622;

/* 
Последовательные выполнения нитей Ӏ Java Core: 6 уровень, 13 лекция
*/

public class Solution {
    public volatile static int COUNT = 4;

    public static void main(String[] args) throws InterruptedException {
        for (int i = 0; i < COUNT; i++) {
            Thread myThread = new SleepingThread();
            //напишите тут ваш код
            myThread.join();
        }
    }

    public static class SleepingThread extends Thread {
        private static volatile int threadCount = 0;
        private volatile int countdownIndex = COUNT;

        public SleepingThread() {
            super(String.valueOf(++threadCount));
            start();
        }

        public void run() {
            while (true) {
                System.out.println(this);
                if (--countdownIndex == 0)
                    return;
                //напишите тут ваш код
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                    System.out.println("Нить прервана");
//                    throw new RuntimeException(e);
                }

            }
        }

        public String toString() {
            return "#" + getName() + ": " + countdownIndex;
        }
    }
}
/*
public class Solution {
    static int count = 15;
    static volatile int createdThreadCount = 0;

    public static void main(String[] args) {
        for (int i = 0; i < count; i++) {
            System.out.println(new GenerateThread());
        }
    }

    public static class GenerateThread extends Thread {
        public GenerateThread() {
            super(String.valueOf(++createdThreadCount));
            start();
        }

        @Override
        public String toString() {
            return this.getName() + " created";
//            return super.toString();
        }
    }

    public void run() {
        if (Thread.activeCount() < count) {
            new GenerateThread();
//            --count;
        }
    }

//    public SleepingThread() {
//        super(String.valueOf(++threadCount));
//        start();
}
 */