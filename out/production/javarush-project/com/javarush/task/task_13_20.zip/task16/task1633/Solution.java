package com.javarush.task.task16.task1633;

/* 
Отдебажим все на свете
*/

public class Solution {
    public static Thread.UncaughtExceptionHandler handler = new OurUncaughtExceptionHandler();
//    public static Thread.UncaughtExceptionHandler handler =

    public static void main(String[] args){
        TestedThread commonThread = new TestedThread(handler);

        Thread threadA = new Thread(commonThread, "Нить 1");
        Thread threadB = new Thread(commonThread, "Нить 2");


        threadA.setUncaughtExceptionHandler(handler);
        threadB.setUncaughtExceptionHandler(handler);

//        threadA.setUncaughtExceptionHandler((t, e) -> {
//                    System.out.println("В потоке " + t.getName() +
//                            " произошло исключение: " + e);

        threadA.start();
        threadB.start();


        threadA.interrupt();
        threadB.interrupt();

    }
    // Экземпляр этого объекта выполняется в обеих нитях
    public static class TestedThread extends Thread {
        public TestedThread(Thread.UncaughtExceptionHandler handler) {
            setUncaughtExceptionHandler(handler);
            start();
        }



        public void run() {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
//                handler.uncaughtException(this, new Throwable("My exception message"));
                throw new RuntimeException("My exception message");
            }
        }
    }

    public static class OurUncaughtExceptionHandler implements Thread.UncaughtExceptionHandler {
        @Override
        public void uncaughtException(Thread t, Throwable e) {
            System.out.println(t.getName() + ": " + e.getMessage());
        }
    }
}
/*
public class Solution {
    public static Thread.UncaughtExceptionHandler handler = new OurUncaughtExceptionHandler();
//    public static Thread.UncaughtExceptionHandler handler =

    public static void main(String[] args){
        TestedThread commonThread = new TestedThread(handler);

        Thread threadA = new Thread(commonThread, "Нить 1");
        Thread threadB = new Thread(commonThread, "Нить 2");

//        threadA.setUncaughtExceptionHandler((t, e) -> {
//                    System.out.println("В потоке " + t.getName() +
//                            " произошло исключение: " + e);

        threadA.start();
        threadB.start();
//        threadB.join();

        threadA.interrupt();
        threadB.interrupt();
    }
    // Экземпляр этого объекта выполняется в обеих нитях
    public static class TestedThread extends Thread {
        public TestedThread(Thread.UncaughtExceptionHandler handler) {
            setUncaughtExceptionHandler(handler);
            start();
        }

        public void run() {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                throw new RuntimeException("My exception message");
            }
        }
    }

    public static class OurUncaughtExceptionHandler implements Thread.UncaughtExceptionHandler {
        @Override
        public void uncaughtException(Thread t, Throwable e) {
            System.out.println(t.getName() + ": " + e.getMessage());
        }
    }
}
 */