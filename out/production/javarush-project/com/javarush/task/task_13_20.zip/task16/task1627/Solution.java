package com.javarush.task.task16.task1627;

import javax.management.ObjectName;
import java.util.ArrayList;
import java.util.List;

/* 
Поиграем?

public void run() {
            //Add your code here - добавь код тут

            //Перебираем по одному шаги из steps, после каждого

            for (int i = 0; i < OnlineGame.steps.size() - 1; i++) {
                // Выводим steps стоклько раз, сколько рейтинг.
                for (int k = 0; k < this.rating - 1; k++) {
                    System.out.println(this.getName() + ": " + OnlineGame.steps.get(i));
                    i++;
                }
                // Замираем каждую секунду

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    System.out.println(this.getName() + ": проиграл");
                }

            }

            System.out.println(this.getName() + ":победитель!");
            OnlineGame.isWinnerFound = true;
        }

*/

public class Solution {
    public static void main(String[] args) throws InterruptedException {
        OnlineGame onlineGame = new OnlineGame();
        onlineGame.start();
    }

    public static class OnlineGame extends Thread {
        public static volatile boolean isWinnerFound = false;

        public static List<String> steps = new ArrayList<String>();

        static {
            steps.add("Начало игры");
            steps.add("Сбор ресурсов");
            steps.add("Рост экономики");
            steps.add("Убийство врагов");
        }

        protected Gamer gamer1 = new Gamer("Ivanov", 3);
        protected Gamer gamer2 = new Gamer("Petrov", 1);
        protected Gamer gamer3 = new Gamer("Sidorov", 5);

        public void run() {
            gamer1.start();
            gamer2.start();
            gamer3.start();


            while (!isWinnerFound) {
            }

            gamer1.interrupt();
            gamer2.interrupt();
            gamer3.interrupt();
        }
    }

    public static class Gamer extends Thread {
        private int rating;

        public Gamer(String name, int rating) {
            super(name);
            this.rating = rating;
        }

        public void run() {
            int i = 0;
            try {
                while (i < OnlineGame.steps.size()) {
                    System.out.println(getName() + ":" + OnlineGame.steps.get(i));
                    i++;
                    Thread.sleep(1000 / rating);
                }
                if (!OnlineGame.isWinnerFound) {
                    OnlineGame.isWinnerFound = true;
                    System.out.println(getName() + ":победитель!");
                }
            } catch (InterruptedException e) {
                System.out.println(getName() + ":проиграл");
            }
        }
    }
}
/*
public class Solution {
    public static void main(String[] args) throws InterruptedException {
        OnlineGame onlineGame = new OnlineGame();
        onlineGame.start();
    }

    public static class OnlineGame extends Thread {
        public static volatile boolean isWinnerFound = false;

        public static List<String> steps = new ArrayList<String>();

        static {
            steps.add("Начало игры");
            steps.add("Сбор ресурсов");
            steps.add("Рост экономики");
            steps.add("Убийство врагов");
        }

        protected Gamer gamer1 = new Gamer("Ivanov", 3);
        protected Gamer gamer2 = new Gamer("Petrov", 1);
        protected Gamer gamer3 = new Gamer("Sidorov", 5);

        public void run() {
            gamer1.start();
            gamer2.start();
            gamer3.start();

            while (!isWinnerFound) {
            }
            gamer1.interrupt();
            gamer2.interrupt();
            gamer3.interrupt();
        }
    }

    public static class Gamer extends Thread {
        private int rating;

        public Gamer(String name, int rating) {
            super(name);
            this.rating = rating;
        }

        @Override
        public void run() {
            //Add your code here - добавь код тут



        }
    }
}

 */