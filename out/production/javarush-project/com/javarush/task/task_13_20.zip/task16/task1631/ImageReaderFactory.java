package com.javarush.task.task16.task1631;

import com.javarush.task.task16.task1631.common.*;

/*
Factory method pattern
public class ImageReaderFactory {
    private ImageReaderFactory() {
    }

    public static ImageReader getImageReader(ImageTypes type) {
        if (type == null) {
            throw new IllegalArgumentException("Неизвестный тип картинки");
        }
        ImageReader imageReader;
        switch (type) {
            case BMP:
                imageReader = new BmpReader();
                break;
            case JPG:
                imageReader = new JpgReader();
                break;
            case PNG:
                imageReader = new PngReader();
                break;
            default:
                throw new IllegalArgumentException("Неизвестный тип картинки");
        }

*/


public class ImageReaderFactory {
    private ImageTypes curImg = null;
    public static ImageReader getImageReader(ImageTypes types) {
        if (types == null) {
            throw new IllegalArgumentException("Неизвестный тип картинки");
        }
        if(types.name().equals("JPG")){
            return new JpgReader();
        } else if(types.name().equals("PNG")) {
            return new PngReader();
        }else if(types.name().equals("BMP")) {
            return new BmpReader();
        }else throw new IllegalArgumentException("Неизвестный тип картинки");
    }

}
