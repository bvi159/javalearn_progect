package com.javarush.task.task16.task1620;

public class Demo3 {
    public static void main(String[] args) throws Exception {
        Account account = new Account(100_000);
        System.out.println("Begin balance = " + account.getBalance());

        Thread withdrawThread = new WithdrawThread(account);
        Thread depositThread = new DepositThread(account);
        withdrawThread.start();
        depositThread.start();

        withdrawThread.join();
        depositThread.join();

        System.out.println("End Balance = " + account.getBalance());
    }

    private static class WithdrawThread extends Thread{
        private final Account account;
        private WithdrawThread(Account account) {this.account = account;}

        @Override
        public void run(){
            for (int i = 0; i < 20_000; i++) {
                try {
                    account.withdraw(1);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    private static class DepositThread extends Thread {
        private final Account account;
        private DepositThread(Account account) {this.account = account;}

        @Override
        public void run() {
            for (int i = 0; i < 20_000; i++) {
                try {
                    account.deposit(1);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
